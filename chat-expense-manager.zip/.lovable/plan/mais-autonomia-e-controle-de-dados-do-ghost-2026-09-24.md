# Mais autonomia e controle de dados do GHoST

## Resultado
- Manter as ferramentas de dados disponíveis em toda conversa geral, sem condição intermediária; o próprio GHoST decide quando consultá-las.
- Adicionar `excluir_dados` para tabelas autorizadas, sempre restrita a um único registro e com confirmação explícita antes da exclusão.
- Ensinar ao GHoST a estrutura atual do app para orientar corretamente o usuário.

## Implementação
- Estender o catálogo seguro de tabelas com permissão explícita de exclusão; tabelas operacionais e de auditoria continuarão protegidas contra escrita.
- Reutilizar a busca isolada por usuário para exigir exatamente um registro antes de preparar a exclusão.
- Ampliar a ação pendente genérica para aceitar exclusão e executá-la somente depois de uma resposta afirmativa clara; cancelamento e expiração continuam sem alterar dados.
- Disponibilizar `consultar_dados`, `inserir_dados`, `atualizar_dados` e `excluir_dados` em todas as chamadas do chat geral.
- Atualizar as instruções do GHoST com os módulos Início, Dashboard de Gastos, Agenda, Parâmetros, Uso da IA e Configurações, incluindo a finalidade de cada um.

## Segurança e validação
- Toda operação continuará filtrada pela conta vinculada ao Telegram.
- Exclusões em massa, ambíguas ou em tabelas não autorizadas serão recusadas.
- Validar consulta direta sem ferramenta, consulta real com ferramenta, preparação/cancelamento/confirmação de exclusão e compilação do app.
