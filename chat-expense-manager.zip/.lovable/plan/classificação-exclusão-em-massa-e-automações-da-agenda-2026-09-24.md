# Classificação, exclusão em massa e automações da Agenda

## Resultado
- Separar claramente gastos, lembretes com data/hora, tarefas sem data e conversa geral no Telegram.
- Permitir exclusões em massa apenas após mostrar a quantidade afetada e receber confirmação explícita.
- Usar a data/hora real de São Paulo nas decisões do GHoST.
- Limpar compromissos vencidos diariamente e enviar um boletim às 6h com a agenda do dia e dos próximos 7 dias.
- Tornar configurável a antecedência de cada aviso.

## Implementação
- Atualizar `classifyMessageIntent` para retornar também `tarefa`; pedidos de criar tarefas irão ao chat geral, que usará as ferramentas genéricas da tabela `tasks`.
- Reforçar os prompts: Agenda/lembrete sempre exige data ou hora específica; tarefa nunca tem data; incluir a data/hora calculada no servidor em cada chamada do chat geral e da classificação.
- Adicionar `excluir_dados_em_massa` com filtros obrigatórios, contagem prévia limitada às tabelas autorizadas e confirmação persistida. Na confirmação, repetir os mesmos filtros e excluir somente os registros daquela conta, retornando a quantidade efetiva.
- Ampliar a ação pendente para armazenar filtros e contagem de uma exclusão em massa, sem permitir exclusão sem filtro nem em tabelas protegidas.
- Adicionar `aviso_antecedencia_minutos` em `reminders`, com padrão de 120 minutos para preservar os registros atuais, e atualizar a rotina de avisos para usar o valor de cada compromisso.
- No Telegram, extrair e guardar temporariamente o compromisso, perguntar a antecedência e só então salvar. Aceitar respostas como 30 min, 1h, 2h e 1 dia; se a mensagem inicial já informar a antecedência, salvá-la diretamente.
- Expor a antecedência também no formulário da Agenda para criação e edição manual.
- Criar uma rotina diária autenticada e limitada: apagar compromissos vencidos e gerar via Haiku um boletim curto por usuário com Telegram vinculado, contendo data, dia da semana, compromissos do dia e dos próximos 7 dias.
- Registrar execução, trava temporária, progresso por usuário e pausa em falhas de créditos/permissão, evitando duplicações e execuções simultâneas.
- Agendar a rotina diária para 06:00 no horário de São Paulo e manter a rotina de avisos a cada 5 minutos.

## Validação
- Testar classificação de tarefa sem data, lembrete com data/hora, gasto e conversa ambígua.
- Testar exclusão em massa com zero, um e vários registros, cancelamento, expiração e isolamento por conta.
- Testar criação de compromisso com escolha de antecedência e confirmar que o aviso usa esse valor uma única vez.
- Testar limpeza de vencidos e boletim diário sem duplicação, com chamada real mínima ao Haiku.
- Verificar Agenda em desktop/celular, compilação, erros de execução, segurança e tarefas agendadas ativas.

## Detalhes técnicos
- Alterações de estrutura serão aditivas e aplicadas pela Lovable Cloud, com políticas e permissões existentes preservadas.
- O boletim terá lote máximo por execução e uma única chamada curta ao Haiku por usuário processado.
- Datas e agendamentos usarão `America/Sao_Paulo`; o horário de verão será resolvido pelo fuso, não por offset fixo.
