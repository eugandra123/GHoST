# Ferramentas de gastos do JRVS

## Objetivo
Permitir que o JRVS localize, corrija e exclua gastos pelo Telegram, sem alterar o dashboard nem o fluxo atual de registro por texto ou imagem.

## Alterações
- Adicionar ferramentas do Claude para buscar gastos por descrição aproximada, valor e período/data.
- Permitir preparar correções de valor, categoria ou descrição e preparar exclusões somente para um lançamento identificado.
- Quando houver resultados parecidos, mostrar uma lista curta numerada com data, estabelecimento e valor para o usuário escolher.
- Antes de editar ou excluir, salvar uma ação pendente e pedir confirmação explícita, exibindo exatamente o lançamento e a mudança proposta.
- Executar a ação pendente apenas após uma resposta afirmativa clara; cancelar diante de negativa ou expiração.
- Manter a busca restrita aos gastos do usuário vinculado ao chat e validar categorias contra as categorias atuais da conta.
- Registrar as mensagens de confirmação e resultado no histórico recente do assistente.

## Segurança e dados
- Criar uma tabela pequena para ações pendentes, protegida por usuário, com expiração e apenas uma ação ativa por conta.
- As ferramentas rodarão somente no servidor; o modelo nunca receberá acesso direto ao banco nem poderá editar/excluir sem passar pela confirmação.
- Preservar o uso de Haiku por padrão e Sonnet apenas para pedidos complexos; nenhum modelo Opus será usado.

## Validação
- Testar busca com um resultado e com vários resultados semelhantes.
- Testar edição e exclusão com confirmação, cancelamento e ação expirada.
- Confirmar que pedidos sem confirmação não alteram dados.
- Verificar compilação e garantir que registro de novos gastos, imagens e dashboard permaneçam intactos.

## Detalhes técnicos
- Estender a chamada Anthropic existente para o protocolo nativo de `tool_use`/`tool_result`, com ciclo curto e limitado.
- Implementar ferramentas server-side de busca e preparação de ações; a mutação final será determinística no webhook após confirmação explícita.
