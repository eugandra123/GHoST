# Link do Google Agenda nos lembretes do Telegram

## Objetivo
Permitir que o JRVS confirme lembretes pelo Telegram e inclua um link público do Google Agenda, sem OAuth, credenciais ou chamadas à API do Google.

## Alterações
- Adicionar uma tabela simples de lembretes vinculada ao usuário, com título, data de início, data de fim, detalhes e horário de criação, mantendo isolamento e permissões por conta.
- Incluir lembretes no catálogo seguro de dados do JRVS, permitindo consulta, criação e atualização com a confirmação já obrigatória.
- Ao preparar um lembrete, exigir título e datas válidas; usar o fuso de São Paulo quando o usuário informar horários locais.
- Depois que o usuário confirmar a criação, responder no Telegram com os dados do lembrete e um link `calendar.google.com/calendar/render?action=TEMPLATE`, codificado corretamente, com datas em `AAAAMMDDTHHMMSS`.
- Não implementar OAuth, autenticação ou integração com a API do Google Calendar.

## Validação
- Confirmar que criar um lembrete exige confirmação e não grava nada antes do “sim”.
- Confirmar que, após o “sim”, o registro é salvo e a resposta contém um link clicável com título, datas e detalhes.
- Verificar cancelamento, datas inválidas e compilação, sem alterar o fluxo de gastos ou imagens do Telegram.

## Detalhes técnicos
- O link será produzido localmente no servidor usando `URLSearchParams`, sem requisição externa.
- Datas com horário serão convertidas para o formato exigido pelo Google Agenda e enviadas como um intervalo início/fim.
