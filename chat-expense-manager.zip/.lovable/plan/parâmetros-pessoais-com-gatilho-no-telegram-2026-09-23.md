# Parâmetros pessoais com gatilho no Telegram

## Objetivo
Permitir que mensagens terminadas em `*` salvem um parâmetro pessoal, sem interferir nos fluxos normais de gastos, lembretes ou conversa, e disponibilizar esses dados para edição manual no app.

## Implementação
- Criar uma tabela privada de parâmetros com chave única por usuário, valor em texto e datas de criação/atualização.
- Detectar o `*` no webhook antes da classificação atual; remover somente o marcador final e rejeitar conteúdo vazio.
- Usar o Claude Haiku com resposta curta e estruturada para extrair apenas `chave` e `valor`, sem enviar histórico nem ativar ferramentas.
- Salvar ou atualizar o parâmetro da conta vinculada ao Chat ID e responder no Telegram com `Salvo: chave = valor`.
- Sem `*`, manter exatamente o fluxo existente de confirmações, gastos, lembretes e chat geral.
- Criar a tela protegida “Parâmetros” para listar, adicionar, editar e excluir itens manualmente, seguindo o visual atual do GHoST.
- Adicionar a nova tela à navegação e manter o histórico do chat limitado às 8 mensagens atuais.

## Segurança e economia
- Isolar todos os parâmetros pelo usuário com regras de acesso no banco.
- Usar Haiku somente no gatilho explícito, com limite baixo de resposta e registro do consumo existente.
- Não expor identificadores de usuário nem aceitar operações em massa.

## Validação
- Testar mensagens com e sem `*`, incluindo espaços após o marcador e conteúdo inválido.
- Confirmar que uma chave repetida atualiza o valor existente.
- Validar criação, edição e exclusão manual na tela em desktop e celular.
- Conferir compilação e ausência de regressões nos fluxos atuais.
