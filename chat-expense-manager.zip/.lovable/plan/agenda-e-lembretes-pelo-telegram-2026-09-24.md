# Agenda e lembretes pelo Telegram

## Objetivo
Adicionar a página **Agenda** à navegação do GHoST e tornar a criação de lembretes pelo Telegram mais flexível, usando o Haiku para interpretar datas e horários escritos livremente.

## Alterações
- Criar a rota protegida `/agenda`, com a identidade visual atual, metadados próprios e lista dos registros de `reminders` em ordem cronológica.
- Mostrar data, hora, título e detalhes de cada compromisso, com formulário para criar ou editar e ação de exclusão.
- Validar título, início e fim na interface; usar duração padrão de 30 minutos quando um novo compromisso for criado sem ajuste manual do término.
- Adicionar **Agenda** à navegação lateral, substituindo o item futuro/inativo de lembretes.
- No Telegram, manter a classificação de intenção existente, mas substituir o parser manual de datas por uma chamada curta ao Haiku dedicada à extração estruturada.
- Enviar ao modelo a data/hora atual em São Paulo e exigir `title`, `starts_at`, `ends_at` e `details`, com datas ISO 8601 completas e fuso explícito.
- Validar no servidor o JSON e as datas retornadas; quando válidas, inserir imediatamente em `reminders` para o usuário vinculado e responder com uma confirmação curta contendo título, data e hora.
- Remover a geração e o envio de `.ics`, incluindo o suporte `sendDocument` que ficar sem uso.
- Preservar integralmente os módulos de gastos, chat geral, histórico recente e demais integrações.

## Validação
- Confirmar criação, edição, exclusão e ordenação da Agenda em desktop e celular.
- Testar a extração de: “hoje”, “amanhã”, dia da semana, `28/09` e `28/09/2025`, verificando ISO completo e horário de São Paulo.
- Confirmar que mensagens de gasto continuam no fluxo atual e que um lembrete válido é salvo sem etapa de confirmação nem arquivo `.ics`.
- Verificar compilação, erros de execução e metadados da nova página.

## Detalhes técnicos
- Reutilizar a tabela `reminders` e suas políticas existentes; nenhuma migração é necessária.
- Usar somente o modelo Haiku já configurado, com resposta JSON curta e limite reduzido de tokens.
- A validação final permanece determinística no servidor; a interpretação linguística da data/hora fica exclusivamente com o modelo, sem regex de calendário.
