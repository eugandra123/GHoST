# Arquivo de calendário no Telegram

## Objetivo
Substituir somente o link do Google Agenda enviado após a confirmação de um lembrete por um arquivo universal `.ics`, sem OAuth e sem chamadas adicionais de IA.

## Alterações
- Montar o conteúdo iCalendar localmente com título, início, fim e descrição do lembrete, usando o fuso de São Paulo e escape correto de texto.
- Adicionar ao serviço existente do Telegram o envio de documento via `sendDocument`.
- Após o usuário confirmar e o lembrete ser salvo, enviar uma confirmação curta e o arquivo `.ics`; remover o link do Google Calendar desse fluxo.
- Manter intactos a criação e confirmação de lembretes, gastos, histórico, banco e demais integrações.

## Validação
- Verificar o conteúdo do `.ics`, incluindo datas, título e descrição.
- Confirmar que o webhook envia o documento somente depois que o lembrete é salvo.
- Validar compilação sem realizar chamada à Anthropic.

## Detalhes técnicos
- O arquivo será montado manualmente no formato `VCALENDAR`/`VEVENT`, sem nova dependência.
- O documento será enviado pelo gateway do Telegram com `sendDocument`, usando upload multipart.
