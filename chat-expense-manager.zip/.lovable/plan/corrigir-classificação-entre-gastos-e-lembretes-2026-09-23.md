# Corrigir classificação entre gastos e lembretes

## Alteração
- Ajustar apenas o classificador existente para dar prioridade a gastos quando houver valor monetário junto de uma ação de compra ou pagamento.
- Encaminhar para lembretes somente pedidos explícitos de lembrar, marcar ou agendar que tenham data/horário e não tenham valor monetário de gasto.
- Preservar integralmente os módulos de gastos, lembretes, banco e Telegram.

## Validação
- Testar frases de gastos, lembretes e casos ambíguos, incluindo “paguei a conta de luz, R$120”.
- Confirmar a compilação e verificar que a decisão é local, sem consumir créditos de IA.
