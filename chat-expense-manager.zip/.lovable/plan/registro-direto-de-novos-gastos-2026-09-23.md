# Registro direto de novos gastos

## Alteração
- Encaminhar mensagens com valor e descrição de gasto diretamente para o registro existente, inclusive pedidos como “registre” ou “adicione”.
- Manter confirmação prévia somente para edição e exclusão de lançamentos existentes.
- Preservar a mensagem enviada depois que o novo gasto já estiver salvo.

## Validação e publicação
- Testar localmente novos gastos, edição, exclusão e lembretes sem gravar dados reais.
- Confirmar a compilação, verificar a segurança e publicar a versão atualizada.
