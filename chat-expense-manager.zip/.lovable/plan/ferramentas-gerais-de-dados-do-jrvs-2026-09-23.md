# Ferramentas gerais de dados do JRVS

## Objetivo
Dar ao JRVS ferramentas de consulta, inserção e atualização para os dados do próprio usuário, mantendo o Telegram como único canal de conversa e exigindo confirmação antes de qualquer escrita.

## Implementação
- Criar um catálogo seguro das tabelas públicas do app, com nomes, colunas consultáveis, colunas graváveis, campos obrigatórios e vínculo obrigatório ao usuário.
- Incluir as tabelas atuais de gastos, categorias, histórico de conversa, uso de IA, mensagens/canais e perfil; dados técnicos sensíveis e campos de identidade não serão expostos nem alteráveis.
- Estruturar o catálogo para que módulos futuros sejam adicionados em um único registro explícito; não será permitido SQL livre nem acesso a tabelas internas do sistema.
- Substituir as ferramentas específicas do assistente por três ferramentas genéricas: `consultar_dados`, `inserir_dados` e `atualizar_dados`.
- Permitir filtros seguros, ordenação, limite e contagens nas consultas; todas as operações receberão automaticamente o identificador da conta vinculada ao Chat ID.
- Antes de inserir ou atualizar, gravar uma ação pendente com validade curta e responder com uma confirmação clara, mostrando tabela, registro e valores antes/depois.
- Executar a escrita somente após uma resposta explícita de confirmação; cancelar, expirar e impedir alteração em massa ou seleção ambígua.
- Manter o fluxo atual de exclusão de gastos e suas confirmações sem regressão; nenhuma ferramenta genérica de exclusão será adicionada nesta etapa.
- Atualizar o system prompt para exigir consultas reais sempre que a resposta depender dos dados do sistema, sem inventar valores.

## Segurança
- O webhook continuará aceitando ferramentas somente depois de localizar uma conta pelo Chat ID autorizado.
- Toda consulta e escrita será filtrada no servidor pelo usuário vinculado, independentemente dos argumentos gerados pela IA.
- IDs de usuário, campos de autenticação, segredos, payloads brutos e campos calculados/auditáveis serão bloqueados para escrita.
- Atualizações exigirão um único registro identificado; operações em lote serão recusadas mesmo antes da confirmação.

## Validação
- Validar consultas por período, contagem, ordenação e limite nas tabelas atuais.
- Validar confirmação, cancelamento e expiração para inserções e atualizações.
- Confirmar que uma tentativa de acessar outra conta, tabela interna, coluna proibida ou vários registros é recusada.
- Rodar verificação de tipos e conferir a compilação do app sem alterar as telas existentes.
