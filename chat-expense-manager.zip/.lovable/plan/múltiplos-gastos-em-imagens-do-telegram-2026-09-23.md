# Múltiplos gastos em imagens do Telegram

## Objetivo
Ajustar apenas o fluxo de imagens do Telegram para reconhecer todas as transações visíveis, registrar cada uma separadamente e ignorar duplicatas.

## Implementação
- Manter a extração de texto como está e adicionar uma resposta em lista exclusiva para imagens.
- Incluir no pedido à IA o horário atual e o fuso de São Paulo, permitindo converter referências como “há 9 horas” e “ontem” em datas aproximadas.
- No webhook do Telegram, verificar cada item extraído contra os gastos existentes do usuário por estabelecimento, valor e uma janela de data aproximada.
- Inserir apenas os itens novos, associar o registro da mensagem ao primeiro gasto criado e responder com a quantidade e um resumo curto dos lançamentos.
- Se todos os itens já existirem, confirmar que nenhum novo gasto foi registrado por serem duplicados.

## Validação
- Verificar compilação e erros do app.
- Confirmar que o caminho de texto continua usando o comportamento atual e que somente o caminho de imagem aceita múltiplos itens.
