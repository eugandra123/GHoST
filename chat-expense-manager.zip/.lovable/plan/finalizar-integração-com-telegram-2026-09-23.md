# Finalizar integração com Telegram

## Objetivo
Deixar o bot pronto para vincular uma conta, receber gastos por texto ou imagem, registrar o lançamento e responder no mesmo chat.

## Entregas
- Completar a seção do Telegram em **Ajustes**, mostrando status, código de vinculação e ação para desvincular.
- Fortalecer o webhook: validar a mensagem recebida, evitar lançamentos duplicados, tratar comandos e falhas sem responder erro 500 ao Telegram.
- Manter o lançamento associado ao usuário vinculado e registrar o histórico do processamento.
- Registrar o webhook no bot usando o endereço público estável do projeto e conferir o status retornado pelo Telegram.
- Validar a tela em computador e celular, o endpoint público e os fluxos de texto e imagem sem criar gastos de teste permanentes.

## Detalhes técnicos
- Usar o conector Telegram já vinculado ao projeto e manter as credenciais somente no servidor.
- Reutilizar as tabelas existentes (`profiles`, `expenses`, `categories` e histórico de mensagens), aplicando apenas ajustes de banco indispensáveis.
- Preservar o fluxo e o visual atuais do módulo de gastos.
