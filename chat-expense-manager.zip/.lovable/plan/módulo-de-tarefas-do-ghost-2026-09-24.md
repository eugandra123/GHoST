# Módulo de Tarefas do GHoST

## Resultado
- Criar uma área **Tarefas** para itens simples sem data, separada da **Agenda**, que continuará dedicada a compromissos com data e hora.
- Permitir criar, editar, concluir/reabrir e excluir tarefas pelo site.
- Permitir que o GHoST consulte e gerencie tarefas no Telegram usando apenas as ferramentas genéricas já existentes e suas confirmações de segurança.

## Implementação
- Criar a tabela privada `tasks` com descrição, status (`pendente` ou `concluída`), data de criação, identificador e vínculo automático com o usuário.
- Aplicar permissões e regras de acesso para cada usuário ver e alterar somente as próprias tarefas.
- Adicionar `tasks` ao catálogo autorizado das ferramentas genéricas, com leitura, inserção, atualização e exclusão de um único registro.
- Criar a página **Tarefas** seguindo a identidade visual atual, com lista, inclusão, edição, alternância de status e exclusão confirmada.
- Adicionar **Tarefas** à navegação e atualizar as instruções do GHoST para explicar a diferença entre Tarefas e Agenda.
- Manter o Haiku, o histórico atual e os limites de resposta existentes, sem adicionar chamadas de IA.

## Validação
- Verificar criação, edição, conclusão/reabertura e exclusão pela página.
- Confirmar que o catálogo permite as quatro operações em `tasks` e mantém isolamento por usuário e confirmação antes de escritas no Telegram.
- Validar a compilação e a página em tela pequena e grande.
