# Mensagens agendadas da Agenda

## Implementação
- Adicionar ao compromisso os controles internos de aviso enviado e reserva de envio, preservando os registros atuais.
- Criar uma rotina protegida que, a cada execução, selecione um lote pequeno de compromissos que atingiram a janela de duas horas, encontre o Telegram vinculado e envie título e horário com `sendMessage`.
- Reservar cada compromisso de forma atômica antes do envio; marcar como avisado somente após sucesso e liberar a reserva se o Telegram falhar.
- Criar uma tarefa no Lovable Cloud a cada 5 minutos, autenticada com o segredo já configurado.
- Não usar IA nesse fluxo, portanto os avisos não consomem créditos de IA.

## Comportamento
- O aviso será enviado na primeira execução após faltar duas horas, com atraso máximo aproximado de 5 minutos.
- Compromissos já avisados não serão reenviados.
- Compromissos sem uma conta do Telegram vinculada permanecerão sem aviso enviado.

## Validação
- Confirmar banco, segurança da rotina e agendamento ativo.
- Simular um compromisso elegível e validar que o Telegram recebe uma única mensagem.
- Verificar compilação e erros de execução sem alterar Agenda, gastos ou chat.
