# Uso da IA no JRVS

## Resultado
Adicionar a aba **Uso da IA** à navegação existente, sem alterar os fluxos de Gastos ou Telegram. A tela mostrará estimativas em dólar baseadas nos tokens retornados pela Anthropic.

## Backend
- Criar a tabela de uso da IA vinculada ao usuário, com modelo, família do modelo, tokens de entrada e saída, custo estimado, origem e data da chamada.
- Proteger os registros para que cada usuário veja somente o próprio uso.
- Centralizar o registro no cliente Anthropic já existente, incluindo cada etapa de uma conversa com ferramentas.
- Identificar as origens como extração de gasto, chat geral ou gerenciamento de gasto.
- Calcular no servidor com os preços informados: Haiku 4.5 (US$ 1/M entrada e US$ 5/M saída) e Sonnet 5 (US$ 3/M entrada e US$ 15/M saída).
- Se o registro de uso falhar, registrar o erro técnico sem interromper a resposta principal do assistente.

## Interface
- Ativar **Uso da IA** na navegação do JRVS.
- Criar uma tela no mesmo visual premium escuro com filtro de **mês atual** ou **últimos 30 dias**.
- Exibir gasto estimado total, divisão Haiku/Sonnet, chamadas por tipo e gráfico diário de custo.
- Mostrar mensagens processadas no período, separando registros de gastos e conversas gerais a partir do histórico operacional existente.
- Informar claramente que os valores são estimativas e que a cobrança oficial permanece na Anthropic.

## Validação
- Confirmar que todas as chamadas Anthropic passam pelo registro central e que nenhum modelo fora de Haiku/Sonnet é usado.
- Validar cálculos de custo, filtros, estados vazios, navegação e visual em desktop e celular.
- Confirmar compilação e ausência de regressões nos módulos de Gastos e Telegram.

## Detalhes técnicos
- Cada chamada receberá `userId` e `origin`; a resposta da Anthropic fornecerá `usage.input_tokens` e `usage.output_tokens`.
- O custo será salvo em precisão suficiente para chamadas pequenas e também recalculável pelos tokens armazenados.
- Chamadas de confirmação local, sem Anthropic, não geram custo artificial.
