# Assistente pessoal pelo Telegram

## Objetivo
Remover o chat do site e fazer do Telegram o único canal de conversa com a IA, sem alterar a planilha, os filtros, os gráficos ou o fluxo de imagens de gastos.

## Alterações
- Remover a página e o item de navegação “Chat”. Após entrar, abrir diretamente a Planilha de Gastos.
- Manter o histórico já existente no banco, limitado às mensagens recentes da conta vinculada ao chat do Telegram.
- No webhook do Telegram, classificar cada texto como lançamento de gasto ou conversa/pergunta.
- Quando for gasto, preservar o registro e a confirmação atuais.
- Quando não for gasto, salvar a mensagem, enviar o histórico recente e os dados financeiros do usuário para o assistente, salvar a resposta e devolvê-la pelo Telegram.
- Instruir o assistente a responder em português como assistente pessoal geral e consultar os gastos fornecidos para perguntas financeiras, sem inventar dados.
- Manter comandos de ajuda, vinculação, imagens com múltiplas transações e proteção contra duplicidade como estão.

## Validação
- Confirmar que o site abre em Gastos e não oferece tela de chat.
- Testar classificação de uma frase de gasto e de uma pergunta geral sem gravar dados reais.
- Verificar compilação e o fluxo existente de imagens.

## Detalhes técnicos
- Reaproveitar `assistant_messages`, já protegida e vinculada ao usuário; como `profiles.telegram_chat_id` é único, o histórico por usuário corresponde ao chat vinculado.
- A chamada à Anthropic continuará somente no servidor, usando a chave já armazenada.
- O endpoint público continuará validando o segredo do Telegram antes de qualquer leitura ou gravação.
