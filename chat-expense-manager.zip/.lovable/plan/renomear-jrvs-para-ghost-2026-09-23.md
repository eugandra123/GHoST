# Renomear JRVS para GHoST

## Alterações
- Trocar o nome visível para **GHoST** na home, navegação, login e demais telas.
- Atualizar títulos e descrições das páginas para a nova marca.
- Instruir o assistente do Telegram a se apresentar e responder como **GHoST**.
- Atualizar a mensagem de ajuda e o reconhecimento de saudações com o novo nome.

## Preservado
- Manter o símbolo, identidade visual, endereço atual do bot no Telegram e toda a lógica existente.
