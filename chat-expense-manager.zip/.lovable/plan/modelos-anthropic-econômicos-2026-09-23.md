# Modelos Anthropic econômicos

## Objetivo
Usar Haiku por padrão em toda chamada direta à Anthropic e reservar Sonnet somente para conversas realmente complexas, sem permitir modelos Opus.

## Alterações
- Centralizar a chamada à Anthropic com uma lista fechada contendo apenas `claude-haiku-4-5-20251001` e `claude-sonnet-5`.
- Mover a extração de gastos por texto e imagem para Haiku, preservando o formato atual e o suporte a múltiplas transações.
- Classificar mensagens gerais por regras simples: comandos, mensagens curtas e perguntas factuais usam Haiku; pedidos abertos, análises, opiniões elaboradas e textos complexos usam Sonnet.
- Limitar respostas simples a 150 tokens, extrações ao mínimo adequado ao JSON solicitado e respostas complexas do Sonnet a 800 tokens.
- Manter confirmações de gastos como texto local, sem chamada de IA e sem custo adicional.
- Verificar que não exista nenhuma referência a Opus ou a modelos Anthropic antigos e validar o fluxo sem alterar o dashboard.

## Detalhes técnicos
- As credenciais continuam exclusivamente no servidor.
- A decisão do modelo será determinística e não exigirá uma chamada extra de classificação.
- O histórico recente e a consulta aos gastos existentes serão preservados.
