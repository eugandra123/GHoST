# iPhone Tela de Início

- [ ] Refinar áreas seguras, transições internas e abertura inicial no iPhone
- [x] Revisar configuração PWA existente e preparar manifesto standalone
- [x] Adicionar ícones, ajustes iOS e tela de abertura com a identidade GHoST
- [x] Validar metadados e carregamento no navegador
- [ ] Testar instalação real no iPhone (aguarda dispositivo iOS)

# Telegram

- [x] Concluir vinculação e status nos Ajustes
- [x] Tornar o webhook idempotente e resiliente
- [x] Registrar e confirmar o webhook no bot
- [x] Validar tela e fluxos de texto e imagem
- [x] Extrair e registrar múltiplas transações de uma imagem sem duplicar itens
- [x] Registrar novos gastos por texto sem confirmação prévia

# Assistente com IA no Telegram

- [x] Criar histórico de conversa por usuário
- [x] Remover o Chat do site e abrir a Planilha de Gastos após o login
- [x] Conectar conversas do Telegram à Anthropic e aos gastos existentes
- [x] Usar Haiku por padrão e Sonnet apenas em pedidos complexos, sem modelos Opus
- [x] Buscar, editar e excluir gastos pelo JRVS com confirmação obrigatória
- [x] Centralizar gasto, lembrete e chat na classificação por IA e deixar a IA decidir sobre ferramentas

# Identidade JRVS

- [x] Reposicionar JRVS como produto central e Gastos como módulo
- [x] Aplicar identidade premium escura, anel gradiente e nova navegação
- [x] Manter Chat somente no Telegram e reservar módulos futuros
- [x] Validar visual, navegação e fluxos existentes

# Uso da IA

- [x] Registrar tokens e custo estimado em todas as chamadas Anthropic
- [x] Exibir custo por modelo, custo diário e mensagens por tipo
- [x] Filtrar entre mês atual e últimos 30 dias

# Ferramentas gerais de dados

- [x] Consultar tabelas autorizadas com filtros, contagem e soma
- [x] Confirmar antes de inserir ou atualizar qualquer registro
- [x] Isolar todas as operações pela conta vinculada ao Chat ID
- [x] Preservar exclusão de gastos com confirmação e bloquear operações em massa
- [x] Disponibilizar ferramentas em todo chat geral e adicionar exclusão genérica com confirmação
- [x] Ensinar ao GHoST a estrutura e os nomes dos módulos do app

# Lembretes

- [x] Criar lembretes pelo Telegram com confirmação obrigatória
- [x] Enviar arquivo universal .ics pelo Telegram após a confirmação
- [x] Manter o fluxo sem OAuth ou credenciais do Google
- [x] Preparar pedidos claros de lembrete antes do “sim” do usuário
- [x] Reconhecer horários como “14 horas” e “duas da tarde” sem confirmação falsa
- [x] Enviar a confirmação curta como legenda do arquivo .ics
- [x] Classificar intenções de gastos, lembretes e chat em um único ponto com IA

# Identidade do assistente

- [x] Tratar o JRVS como assistente pessoal geral e acionar módulos apenas quando necessários
- [x] Reduzir histórico e contexto enviados à IA para economizar créditos
- [x] Renomear o app e a identidade do assistente para GHoST
- [x] Verificar persistência e envio do histórico recente em cada conversa com a Anthropic

# Parâmetros pessoais

- [x] Salvar parâmetros quando a mensagem do Telegram terminar com *
- [x] Extrair chave e valor com Haiku e confirmar após salvar
- [x] Criar tela para consultar e editar parâmetros manualmente
- [x] Preservar o histórico recente em 8 mensagens

# Agenda

- [x] Criar página Agenda com lista cronológica e criação, edição e exclusão
- [x] Extrair lembretes do Telegram com Haiku em ISO 8601 e salvar diretamente
- [x] Remover geração e envio de arquivos .ics
- [x] Validar Agenda e fluxo de lembretes sem alterar gastos ou chat
- [x] Enviar uma única mensagem no Telegram duas horas antes de cada compromisso

# Tarefas

- [x] Criar tabela privada de tarefas simples sem data
- [x] Criar página para adicionar, editar, concluir e excluir tarefas
- [x] Disponibilizar tarefas nas ferramentas genéricas do Telegram
- [x] Diferenciar Tarefas e Agenda nas instruções do GHoST

# Automação e controle de dados

- [x] Separar tarefa e lembrete na classificação por IA
- [x] Confirmar exclusões em massa com contagem e filtros
- [x] Configurar antecedência individual dos avisos
- [x] Limpar compromissos vencidos diariamente
- [x] Enviar boletim diário no Telegram às 6h
- [x] Ajustar o boletim das 6h com saudação, data completa, compromissos dos próximos 7 dias e tarefas pendentes
