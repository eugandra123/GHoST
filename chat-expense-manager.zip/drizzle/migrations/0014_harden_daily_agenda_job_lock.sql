ALTER TABLE public.scheduled_job_state
  ADD COLUMN consecutive_rate_limits INTEGER NOT NULL DEFAULT 0;

CREATE OR REPLACE FUNCTION public.claim_scheduled_job(
  _job_name TEXT,
  _lease_minutes INTEGER DEFAULT 20
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  claimed BOOLEAN := FALSE;
BEGIN
  INSERT INTO public.scheduled_job_state (
    job_name,
    status,
    lease_expires_at,
    paused_reason,
    last_started_at,
    updated_at
  ) VALUES (
    _job_name,
    'running',
    now() + make_interval(mins => LEAST(GREATEST(_lease_minutes, 1), 60)),
    NULL,
    now(),
    now()
  )
  ON CONFLICT (job_name) DO UPDATE
  SET status = 'running',
      lease_expires_at = EXCLUDED.lease_expires_at,
      paused_reason = NULL,
      last_started_at = now(),
      updated_at = now()
  WHERE public.scheduled_job_state.status <> 'paused'
    AND (
      public.scheduled_job_state.status <> 'running'
      OR public.scheduled_job_state.lease_expires_at IS NULL
      OR public.scheduled_job_state.lease_expires_at <= now()
    )
  RETURNING TRUE INTO claimed;

  RETURN COALESCE(claimed, FALSE);
END;
$$;

REVOKE ALL ON FUNCTION public.claim_scheduled_job(TEXT, INTEGER) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.claim_scheduled_job(TEXT, INTEGER) TO service_role;