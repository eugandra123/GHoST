CREATE TABLE public.ai_usage (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  model TEXT NOT NULL,
  model_family TEXT NOT NULL CHECK (model_family IN ('haiku', 'sonnet')),
  input_tokens BIGINT NOT NULL CHECK (input_tokens >= 0),
  output_tokens BIGINT NOT NULL CHECK (output_tokens >= 0),
  estimated_cost_usd NUMERIC(18,10) NOT NULL CHECK (estimated_cost_usd >= 0),
  origin TEXT NOT NULL CHECK (origin IN ('extracao_gasto', 'chat_geral', 'gerenciamento_gasto')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT ON public.ai_usage TO authenticated;
GRANT ALL ON public.ai_usage TO service_role;

ALTER TABLE public.ai_usage ENABLE ROW LEVEL SECURITY;

CREATE POLICY "own ai usage select"
ON public.ai_usage
FOR SELECT
TO authenticated
USING (auth.uid() = user_id);

CREATE INDEX ai_usage_user_created_idx
ON public.ai_usage (user_id, created_at DESC);

COMMENT ON TABLE public.ai_usage IS 'Estimated Anthropic usage based on provider-reported input and output tokens.';