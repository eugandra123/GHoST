ALTER TABLE public.pending_data_actions
  DROP CONSTRAINT pending_data_actions_action_type_check;

ALTER TABLE public.pending_data_actions
  ADD CONSTRAINT pending_data_actions_action_type_check
  CHECK (action_type IN ('insert', 'update', 'delete', 'bulk_delete'));