CREATE TABLE public.pending_expense_actions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  expense_id UUID NOT NULL REFERENCES public.expenses(id) ON DELETE CASCADE,
  action_type TEXT NOT NULL CHECK (action_type IN ('edit', 'delete')),
  proposed_changes JSONB,
  expense_snapshot JSONB NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.pending_expense_actions TO authenticated;
GRANT ALL ON public.pending_expense_actions TO service_role;

ALTER TABLE public.pending_expense_actions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "own pending expense actions"
ON public.pending_expense_actions
FOR ALL
TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

CREATE INDEX pending_expense_actions_expiry_idx
ON public.pending_expense_actions (expires_at);