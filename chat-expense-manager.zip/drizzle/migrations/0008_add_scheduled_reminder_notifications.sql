ALTER TABLE public.reminders
  ADD COLUMN notification_sent_at TIMESTAMPTZ,
  ADD COLUMN notification_claimed_at TIMESTAMPTZ;

CREATE INDEX reminders_pending_notification_idx
ON public.reminders (starts_at)
WHERE notification_sent_at IS NULL;

CREATE OR REPLACE FUNCTION public.claim_due_reminder_notifications(
  _limit INTEGER DEFAULT 20,
  _lease_minutes INTEGER DEFAULT 10
)
RETURNS TABLE (
  id UUID,
  title TEXT,
  starts_at TIMESTAMPTZ,
  telegram_chat_id BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  WITH due AS (
    SELECT r.id
    FROM public.reminders r
    JOIN public.profiles p ON p.id = r.user_id
    WHERE r.notification_sent_at IS NULL
      AND p.telegram_chat_id IS NOT NULL
      AND r.starts_at > now()
      AND r.starts_at <= now() + interval '2 hours'
      AND (
        r.notification_claimed_at IS NULL
        OR r.notification_claimed_at < now() - make_interval(mins => _lease_minutes)
      )
    ORDER BY r.starts_at ASC
    FOR UPDATE OF r SKIP LOCKED
    LIMIT LEAST(GREATEST(_limit, 1), 50)
  )
  UPDATE public.reminders r
  SET notification_claimed_at = now()
  FROM due
  JOIN public.profiles p ON p.id = (
    SELECT rr.user_id FROM public.reminders rr WHERE rr.id = due.id
  )
  WHERE r.id = due.id
  RETURNING r.id, r.title, r.starts_at, p.telegram_chat_id;
END;
$$;

REVOKE ALL ON FUNCTION public.claim_due_reminder_notifications(INTEGER, INTEGER) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.claim_due_reminder_notifications(INTEGER, INTEGER) TO service_role;