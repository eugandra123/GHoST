ALTER TABLE public.reminders
  ADD COLUMN aviso_antecedencia_minutos INTEGER NOT NULL DEFAULT 120;

ALTER TABLE public.reminders
  ADD CONSTRAINT reminders_valid_notice_lead
  CHECK (aviso_antecedencia_minutos BETWEEN 0 AND 43200);

COMMENT ON COLUMN public.reminders.aviso_antecedencia_minutos IS
  'Antecedência do aviso do Telegram, em minutos.';

CREATE TABLE public.pending_reminder_setups (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE,
  title TEXT NOT NULL,
  starts_at TIMESTAMPTZ NOT NULL,
  ends_at TIMESTAMPTZ NOT NULL,
  details TEXT,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.pending_reminder_setups TO authenticated;
GRANT ALL ON public.pending_reminder_setups TO service_role;

ALTER TABLE public.pending_reminder_setups ENABLE ROW LEVEL SECURITY;

CREATE POLICY "own pending reminder setups"
ON public.pending_reminder_setups
FOR ALL
TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

CREATE INDEX pending_reminder_setups_expiry_idx
ON public.pending_reminder_setups (expires_at);

CREATE TABLE public.scheduled_job_state (
  job_name TEXT PRIMARY KEY,
  status TEXT NOT NULL DEFAULT 'ready',
  lease_expires_at TIMESTAMPTZ,
  paused_reason TEXT,
  last_started_at TIMESTAMPTZ,
  last_completed_at TIMESTAMPTZ,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT scheduled_job_state_valid_status CHECK (status IN ('ready', 'running', 'paused'))
);

GRANT ALL ON public.scheduled_job_state TO service_role;

ALTER TABLE public.scheduled_job_state ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.daily_digest_deliveries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  digest_date DATE NOT NULL,
  sent_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, digest_date)
);

GRANT ALL ON public.daily_digest_deliveries TO service_role;

ALTER TABLE public.daily_digest_deliveries ENABLE ROW LEVEL SECURITY;

CREATE INDEX daily_digest_deliveries_date_idx
ON public.daily_digest_deliveries (digest_date);

CREATE OR REPLACE FUNCTION public.claim_due_reminder_notifications(
  _limit INTEGER DEFAULT 20,
  _lease_minutes INTEGER DEFAULT 10
)
RETURNS TABLE (
  id UUID,
  title TEXT,
  starts_at TIMESTAMPTZ,
  telegram_chat_id BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  WITH due AS (
    SELECT r.id
    FROM public.reminders r
    JOIN public.profiles p ON p.id = r.user_id
    WHERE r.notification_sent_at IS NULL
      AND p.telegram_chat_id IS NOT NULL
      AND r.starts_at > now()
      AND r.starts_at <= now() + make_interval(mins => r.aviso_antecedencia_minutos)
      AND (
        r.notification_claimed_at IS NULL
        OR r.notification_claimed_at < now() - make_interval(mins => _lease_minutes)
      )
    ORDER BY r.starts_at ASC
    FOR UPDATE OF r SKIP LOCKED
    LIMIT LEAST(GREATEST(_limit, 1), 50)
  )
  UPDATE public.reminders r
  SET notification_claimed_at = now()
  FROM due
  JOIN public.profiles p ON p.id = (
    SELECT rr.user_id FROM public.reminders rr WHERE rr.id = due.id
  )
  WHERE r.id = due.id
  RETURNING r.id, r.title, r.starts_at, p.telegram_chat_id;
END;
$$;

REVOKE ALL ON FUNCTION public.claim_due_reminder_notifications(INTEGER, INTEGER) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.claim_due_reminder_notifications(INTEGER, INTEGER) TO service_role;

CREATE OR REPLACE FUNCTION public.reset_reminder_notification_on_schedule_change()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  IF NEW.starts_at IS DISTINCT FROM OLD.starts_at
     OR NEW.aviso_antecedencia_minutos IS DISTINCT FROM OLD.aviso_antecedencia_minutos THEN
    NEW.notification_sent_at = NULL;
    NEW.notification_claimed_at = NULL;
  END IF;
  RETURN NEW;
END;
$$;