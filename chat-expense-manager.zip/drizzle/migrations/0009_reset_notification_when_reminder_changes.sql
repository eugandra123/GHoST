CREATE OR REPLACE FUNCTION public.reset_reminder_notification_on_schedule_change()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  IF NEW.starts_at IS DISTINCT FROM OLD.starts_at THEN
    NEW.notification_sent_at = NULL;
    NEW.notification_claimed_at = NULL;
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER reminders_reset_notification_on_schedule_change
BEFORE UPDATE OF starts_at ON public.reminders
FOR EACH ROW
EXECUTE FUNCTION public.reset_reminder_notification_on_schedule_change();