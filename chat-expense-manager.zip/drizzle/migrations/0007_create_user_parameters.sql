CREATE TABLE public.user_parameters (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  key text NOT NULL,
  value text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT user_parameters_user_key_unique UNIQUE (user_id, key),
  CONSTRAINT user_parameters_key_not_blank CHECK (btrim(key) <> ''),
  CONSTRAINT user_parameters_value_not_blank CHECK (btrim(value) <> '')
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.user_parameters TO authenticated;
GRANT ALL ON public.user_parameters TO service_role;

ALTER TABLE public.user_parameters ENABLE ROW LEVEL SECURITY;

CREATE POLICY "own parameters select"
ON public.user_parameters
FOR SELECT
TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "own parameters insert"
ON public.user_parameters
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "own parameters update"
ON public.user_parameters
FOR UPDATE
TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "own parameters delete"
ON public.user_parameters
FOR DELETE
TO authenticated
USING (auth.uid() = user_id);

CREATE INDEX user_parameters_user_updated_idx
ON public.user_parameters (user_id, updated_at DESC);

CREATE TRIGGER user_parameters_touch_updated_at
BEFORE UPDATE ON public.user_parameters
FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();