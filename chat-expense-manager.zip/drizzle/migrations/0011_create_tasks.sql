CREATE TABLE public.tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  description text NOT NULL CHECK (char_length(btrim(description)) BETWEEN 1 AND 500),
  status text NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente', 'concluída')),
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.tasks TO authenticated;
GRANT ALL ON public.tasks TO service_role;

ALTER TABLE public.tasks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "own tasks select"
ON public.tasks FOR SELECT TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "own tasks insert"
ON public.tasks FOR INSERT TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "own tasks update"
ON public.tasks FOR UPDATE TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "own tasks delete"
ON public.tasks FOR DELETE TO authenticated
USING (auth.uid() = user_id);

CREATE INDEX tasks_user_status_created_idx
ON public.tasks (user_id, status, created_at DESC);