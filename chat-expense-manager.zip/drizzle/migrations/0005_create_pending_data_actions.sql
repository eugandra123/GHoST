CREATE TABLE public.pending_data_actions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  target_table TEXT NOT NULL,
  target_id TEXT,
  action_type TEXT NOT NULL CHECK (action_type IN ('insert', 'update', 'delete')),
  proposed_values JSONB NOT NULL DEFAULT '{}'::jsonb,
  record_snapshot JSONB,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.pending_data_actions TO authenticated;
GRANT ALL ON public.pending_data_actions TO service_role;

ALTER TABLE public.pending_data_actions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "own pending data actions"
ON public.pending_data_actions
FOR ALL
TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

CREATE INDEX pending_data_actions_expiry_idx
ON public.pending_data_actions (expires_at);