import type { Json } from "@/integrations/supabase/types";
import { z } from "zod";

import {
  ANTHROPIC_MODELS,
  callAnthropic,
  callAnthropicWithTools,
  type AnthropicContent,
  type AnthropicMessage,
  type AnthropicTool,
} from "./anthropic.server";
import { formatBRL } from "./categories";
import {
  applyPendingDataAction,
  countUserRecordsForBulkDelete,
  compactRecord,
  createPendingBulkDelete,
  createPendingDataAction,
  describeDataCatalog,
  findSingleUserRecord,
  prepareDelete,
  prepareInsert,
  prepareUpdate,
  queryUserData,
  type PendingDataAction,
} from "./telegram-data-tools.server";

type AssistantRole = "user" | "assistant";

type StoredMessage = {
  role: string;
  content: string;
};

type ExpenseRow = {
  id: string;
  occurred_at: string;
  merchant: string;
  amount: number;
  category: string;
  city: string | null;
};

type PendingChanges = {
  merchant?: string;
  amount?: number;
  category?: string;
};

const EXPENSE_TOOLS: AnthropicTool[] = [
  {
    name: "buscar_gastos",
    description:
      "Busca lançamentos do usuário por descrição aproximada, valor e/ou intervalo de datas. Use antes de preparar edição ou exclusão.",
    input_schema: {
      type: "object",
      properties: {
        descricao: { type: ["string", "null"] },
        valor: { type: ["number", "null"] },
        data_inicio: { type: ["string", "null"], description: "ISO 8601" },
        data_fim: { type: ["string", "null"], description: "ISO 8601" },
      },
      required: ["descricao", "valor", "data_inicio", "data_fim"],
      additionalProperties: false,
    },
  },
  {
    name: "preparar_exclusao_gasto",
    description:
      "Prepara uma exclusão para confirmação. Só use quando a busca desta conversa encontrou exatamente um lançamento.",
    input_schema: {
      type: "object",
      properties: { expense_id: { type: "string" } },
      required: ["expense_id"],
      additionalProperties: false,
    },
  },
];

const GENERIC_DATA_TOOLS: AnthropicTool[] = [
  {
    name: "consultar_dados",
    description: "Consulta dados reais do usuário em uma tabela autorizada. Pode listar, contar ou somar uma coluna.",
    input_schema: {
      type: "object",
      properties: {
        tabela: { type: "string" },
        operacao: { type: "string", enum: ["listar", "contar", "somar"] },
        colunas: { type: "array", items: { type: "string" } },
        filtros: {
          type: "array",
          items: {
            type: "object",
            properties: {
              column: { type: "string" },
              operator: { type: "string", enum: ["eq", "gte", "lte", "ilike"] },
              value: { type: ["string", "number", "boolean"] },
            },
            required: ["column", "operator", "value"],
            additionalProperties: false,
          },
        },
        coluna_agregacao: { type: ["string", "null"] },
        ordenar_por: { type: ["string", "null"] },
        ordem: { type: "string", enum: ["asc", "desc"] },
        limite: { type: "number" },
      },
      required: ["tabela", "operacao", "colunas", "filtros", "coluna_agregacao", "ordenar_por", "ordem", "limite"],
      additionalProperties: false,
    },
  },
  {
    name: "inserir_dados",
    description: "Prepara um novo registro em uma tabela autorizada. Só será inserido após confirmação explícita.",
    input_schema: {
      type: "object",
      properties: {
        tabela: { type: "string" },
        valores: { type: "object", additionalProperties: true },
      },
      required: ["tabela", "valores"],
      additionalProperties: false,
    },
  },
  {
    name: "atualizar_dados",
    description: "Prepara mudanças em exatamente um registro de uma tabela autorizada. Exige confirmação explícita.",
    input_schema: {
      type: "object",
      properties: {
        tabela: { type: "string" },
        filtros: {
          type: "array",
          items: {
            type: "object",
            properties: {
              column: { type: "string" },
              operator: { type: "string", enum: ["eq", "gte", "lte", "ilike"] },
              value: { type: ["string", "number", "boolean"] },
            },
            required: ["column", "operator", "value"],
            additionalProperties: false,
          },
        },
        valores: { type: "object", additionalProperties: true },
      },
      required: ["tabela", "filtros", "valores"],
      additionalProperties: false,
    },
  },
  {
    name: "excluir_dados",
    description: "Prepara a exclusão de exatamente um registro de uma tabela autorizada. Exige confirmação explícita.",
    input_schema: {
      type: "object",
      properties: {
        tabela: { type: "string" },
        filtros: {
          type: "array",
          items: {
            type: "object",
            properties: {
              column: { type: "string" },
              operator: { type: "string", enum: ["eq", "gte", "lte", "ilike"] },
              value: { type: ["string", "number", "boolean"] },
            },
            required: ["column", "operator", "value"],
            additionalProperties: false,
          },
        },
      },
      required: ["tabela", "filtros"],
      additionalProperties: false,
    },
  },
  {
    name: "excluir_dados_em_massa",
    description: "Prepara a exclusão de vários registros com filtros obrigatórios. Sempre informa a quantidade e exige confirmação explícita.",
    input_schema: {
      type: "object",
      properties: {
        tabela: { type: "string" },
        filtros: {
          type: "array",
          items: {
            type: "object",
            properties: {
              column: { type: "string" },
              operator: { type: "string", enum: ["eq", "gte", "lte", "ilike"] },
              value: { type: ["string", "number", "boolean"] },
            },
            required: ["column", "operator", "value"],
            additionalProperties: false,
          },
        },
        todos: { type: "boolean", description: "Use true somente quando o usuário pedir explicitamente todos os registros da tabela." },
      },
      required: ["tabela", "filtros", "todos"],
      additionalProperties: false,
    },
  },
];

const ASSISTANT_TOOLS = [...GENERIC_DATA_TOOLS, ...EXPENSE_TOOLS];

function formatExpense(expense: ExpenseRow) {
  const date = new Date(expense.occurred_at).toLocaleDateString("pt-BR", {
    timeZone: "America/Sao_Paulo",
  });
  return `${date} — ${expense.merchant} — ${formatBRL(Number(expense.amount))} — ${expense.category}`;
}

function asNullableString(value: unknown) {
  return typeof value === "string" && value.trim() ? value.trim() : null;
}

function asNullableNumber(value: unknown) {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}

const extractedReminderSchema = z
  .object({
    title: z.string().trim().min(1).max(160),
    starts_at: z.string().datetime({ offset: true }),
    ends_at: z.string().datetime({ offset: true }),
    details: z.string().trim().max(1000),
    aviso_antecedencia_minutos: z.number().int().min(0).max(43200).nullable(),
  })
  .refine((value) => Date.parse(value.ends_at) > Date.parse(value.starts_at), {
    message: "O término precisa ser posterior ao início.",
  });

const reminderLeadMinutesSchema = z.object({ aviso_antecedencia_minutos: z.number().int().min(0).max(43200) });

function currentSaoPauloDateTime() {
  const value = new Intl.DateTimeFormat("sv-SE", {
    timeZone: "America/Sao_Paulo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hourCycle: "h23",
  }).format(new Date());
  return `${value.replace(" ", "T")}-03:00`;
}

function parseReminderJson(text: string) {
  const start = text.indexOf("{");
  const end = text.lastIndexOf("}");
  if (start < 0 || end <= start) return null;
  try {
    return extractedReminderSchema.safeParse(JSON.parse(text.slice(start, end + 1)));
  } catch {
    return null;
  }
}

export async function createTelegramReminder(userId: string, message: string) {
  const now = currentSaoPauloDateTime();
  const response = await callAnthropic({
    userId,
    origin: "lembrete",
    model: ANTHROPIC_MODELS.haiku,
    maxTokens: 160,
    system:
      `Extraia um compromisso da mensagem em português. Agora em America/Sao_Paulo é ${now}. ` +
      "Interprete datas em qualquer formato, incluindo hoje, amanhã, dia da semana, DD/MM e DD/MM/AAAA. " +
      "Para DD/MM sem ano, escolha a próxima ocorrência futura. Se faltar horário, use 09:00. Se faltar duração, use 30 minutos. " +
      "Também extraia aviso_antecedencia_minutos somente se o usuário informar explicitamente quanto tempo antes deseja ser avisado; caso contrário use null. " +
      "Responda somente JSON com title, starts_at, ends_at, details e aviso_antecedencia_minutos. starts_at e ends_at devem ser ISO 8601 completos com segundos e offset -03:00, por exemplo 2026-09-28T14:00:00-03:00. Não use markdown.",
    messages: [{ role: "user", content: message }],
  });
  const parsed = parseReminderJson(response);
  if (!parsed?.success) {
    const answer = "Não consegui identificar uma data e hora válidas. Informe o compromisso e quando ele deve acontecer.";
    await saveAssistantExchange(userId, message, answer);
    return answer;
  }

  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const reminder = parsed.data;
  if (reminder.aviso_antecedencia_minutos !== null) {
    const { error } = await supabaseAdmin.from("reminders").insert({
      ...reminder,
      user_id: userId,
      aviso_antecedencia_minutos: reminder.aviso_antecedencia_minutos,
    });
    if (error) throw error;
    const startLabel = new Date(reminder.starts_at).toLocaleString("pt-BR", {
      timeZone: "America/Sao_Paulo",
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
    const answer = `Lembrete criado: ${reminder.title} — ${startLabel}. Avisarei ${reminder.aviso_antecedencia_minutos} min antes.`;
    await saveAssistantExchange(userId, message, answer);
    return answer;
  }
  const { error } = await supabaseAdmin.from("pending_reminder_setups").upsert(
    {
      title: reminder.title,
      starts_at: reminder.starts_at,
      ends_at: reminder.ends_at,
      details: reminder.details,
      user_id: userId,
      expires_at: new Date(Date.now() + 15 * 60 * 1000).toISOString(),
    },
    { onConflict: "user_id" },
  );
  if (error) throw error;

  const startLabel = new Date(reminder.starts_at).toLocaleString("pt-BR", {
    timeZone: "America/Sao_Paulo",
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
  const answer = `Compromisso preparado: ${reminder.title} — ${startLabel}. Quer ser avisado com quanto de antecedência? 30 min, 1h, 2h ou 1 dia?`;
  await saveAssistantExchange(userId, message, answer);
  return answer;
}

export async function handlePendingReminderLeadTime(userId: string, message: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data: pending, error } = await supabaseAdmin
    .from("pending_reminder_setups")
    .select("id,title,starts_at,ends_at,details,expires_at")
    .eq("user_id", userId)
    .maybeSingle();
  if (error) throw error;
  if (!pending) return null;
  if (Date.parse(pending.expires_at) <= Date.now()) {
    await supabaseAdmin.from("pending_reminder_setups").delete().eq("id", pending.id).eq("user_id", userId);
    return null;
  }

  const response = await callAnthropic({
    userId,
    origin: "lembrete",
    model: ANTHROPIC_MODELS.haiku,
    maxTokens: 40,
    system: "Extraia apenas a antecedência pedida em minutos. Exemplos: 30 min=30, 1h=60, 2h=120, 1 dia=1440. Responda somente JSON com aviso_antecedencia_minutos. Se não houver uma duração válida, responda {}.",
    messages: [{ role: "user", content: message }],
  });
  const start = response.indexOf("{");
  const end = response.lastIndexOf("}");
  let parsed: ReturnType<typeof reminderLeadMinutesSchema.safeParse> | null = null;
  if (start >= 0 && end > start) {
    try {
      parsed = reminderLeadMinutesSchema.safeParse(JSON.parse(response.slice(start, end + 1)));
    } catch {
      parsed = null;
    }
  }
  if (!parsed?.success) {
    const answer = "Informe a antecedência do aviso, por exemplo: 30 min, 1h, 2h ou 1 dia.";
    await saveAssistantExchange(userId, message, answer);
    return answer;
  }

  const { error: insertError } = await supabaseAdmin.from("reminders").insert({
    user_id: userId,
    title: pending.title,
    starts_at: pending.starts_at,
    ends_at: pending.ends_at,
    details: pending.details,
    aviso_antecedencia_minutos: parsed.data.aviso_antecedencia_minutos,
  });
  if (insertError) throw insertError;
  await supabaseAdmin.from("pending_reminder_setups").delete().eq("id", pending.id).eq("user_id", userId);
  const answer = `Lembrete criado: ${pending.title}. Avisarei ${message.trim()} antes.`;
  await saveAssistantExchange(userId, message, answer);
  return answer;
}

async function saveAssistantExchange(userId: string, userMessage: string, answer: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { error } = await supabaseAdmin.from("assistant_messages").insert([
    { user_id: userId, role: "user", content: userMessage },
    { user_id: userId, role: "assistant", content: answer },
  ]);
  if (error) throw error;
}

export async function handlePendingDataConfirmation(userId: string, message: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin
    .from("pending_data_actions")
    .select("id,target_table,target_id,action_type,proposed_values,record_snapshot,expires_at")
    .eq("user_id", userId)
    .maybeSingle();
  if (error) throw error;
  if (!data) return null;
  const pending = data as PendingDataAction;
  const normalized = message.trim().toLocaleLowerCase("pt-BR");
  const confirms = /^(?:sim|confirmo|confirmar|pode|pode sim|ok|isso)$/i.test(normalized);
  const cancels = /^(?:não|nao|cancelar|cancela|não quero|nao quero)$/i.test(normalized);
  const expired = new Date(pending.expires_at).getTime() <= Date.now();

  if (expired) {
    await supabaseAdmin.from("pending_data_actions").delete().eq("id", pending.id).eq("user_id", userId);
    if (!confirms) return null;
    const answer = "Essa confirmação expirou. Peça novamente para eu preparar a alteração.";
    await saveAssistantExchange(userId, message, answer);
    return { message: answer };
  }
  if (cancels) {
    await supabaseAdmin.from("pending_data_actions").delete().eq("id", pending.id).eq("user_id", userId);
    const answer = "Certo, a operação foi cancelada e nenhum dado foi alterado.";
    await saveAssistantExchange(userId, message, answer);
    return { message: answer };
  }
  if (!confirms) {
    const actionLabel = pending.action_type === "insert" ? "inserção" : pending.action_type === "delete" || pending.action_type === "bulk_delete" ? "exclusão" : "atualização";
    const answer = `Há uma ${actionLabel} pendente em ${pending.target_table}. Responda somente “sim” para confirmar ou “cancelar”.`;
    await saveAssistantExchange(userId, message, answer);
    return { message: answer };
  }

  const applied = await applyPendingDataAction(supabaseAdmin, userId, pending);
  await supabaseAdmin.from("pending_data_actions").delete().eq("id", pending.id).eq("user_id", userId);
  const answer = pending.action_type === "insert"
    ? `Registro adicionado em ${pending.target_table}: ${compactRecord(applied)}.`
    : pending.action_type === "bulk_delete"
      ? `${Number((applied as { deleted_count?: number }).deleted_count ?? 0)} registros foram excluídos de ${pending.target_table}.`
    : pending.action_type === "delete"
      ? `Registro excluído de ${pending.target_table}: ${compactRecord(applied)}.`
      : `Registro atualizado em ${pending.target_table}: ${compactRecord(applied)}.`;
  if (pending.target_table === "reminders") {
    const confirmation = `Lembrete confirmado: ${compactRecord(applied)}.`;
    await saveAssistantExchange(userId, message, confirmation);
    return { message: confirmation };
  }
  await saveAssistantExchange(userId, message, answer);
  return { message: answer };
}

export async function handlePendingExpenseConfirmation(userId: string, message: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data: pending, error } = await supabaseAdmin
    .from("pending_expense_actions")
    .select("id,expense_id,action_type,proposed_changes,expense_snapshot,expires_at")
    .eq("user_id", userId)
    .maybeSingle();
  if (error) throw error;
  if (!pending) return null;

  const normalized = message.trim().toLocaleLowerCase("pt-BR");
  const confirms = /^(?:sim|confirmo|confirmar|pode|pode sim|ok|isso)$/i.test(normalized);
  const cancels = /^(?:não|nao|cancelar|cancela|não quero|nao quero)$/i.test(normalized);
  const expired = new Date(pending.expires_at).getTime() <= Date.now();

  if (expired) {
    await supabaseAdmin.from("pending_expense_actions").delete().eq("id", pending.id);
    if (!confirms) return null;
    const answer =
      "Essa confirmação expirou. Peça novamente a edição ou exclusão para eu localizar o lançamento certo.";
    await saveAssistantExchange(userId, message, answer);
    return answer;
  }

  if (cancels) {
    await supabaseAdmin.from("pending_expense_actions").delete().eq("id", pending.id);
    const answer = "Certo, a alteração foi cancelada e nenhum gasto foi modificado.";
    await saveAssistantExchange(userId, message, answer);
    return answer;
  }

  if (!confirms) {
    const snapshot = pending.expense_snapshot as unknown as ExpenseRow;
    const answer = `Há uma ${pending.action_type === "delete" ? "exclusão" : "edição"} pendente para ${formatExpense(snapshot)}. Responda somente “sim” para confirmar ou “cancelar”.`;
    await saveAssistantExchange(userId, message, answer);
    return answer;
  }

  const { data: expense, error: expenseError } = await supabaseAdmin
    .from("expenses")
    .select("id,occurred_at,merchant,amount,category,city")
    .eq("id", pending.expense_id)
    .eq("user_id", userId)
    .maybeSingle();
  if (expenseError) throw expenseError;
  if (!expense) {
    await supabaseAdmin.from("pending_expense_actions").delete().eq("id", pending.id);
    const answer = "Esse lançamento não existe mais. Nenhuma alteração foi feita.";
    await saveAssistantExchange(userId, message, answer);
    return answer;
  }

  if (pending.action_type === "delete") {
    const { error: deleteError } = await supabaseAdmin
      .from("expenses")
      .delete()
      .eq("id", expense.id)
      .eq("user_id", userId);
    if (deleteError) throw deleteError;
  } else {
    const changes = (pending.proposed_changes ?? {}) as PendingChanges;
    const { error: updateError } = await supabaseAdmin
      .from("expenses")
      .update(changes)
      .eq("id", expense.id)
      .eq("user_id", userId);
    if (updateError) throw updateError;
  }

  await supabaseAdmin.from("pending_expense_actions").delete().eq("id", pending.id);
  const answer =
    pending.action_type === "delete"
      ? `Excluído: ${formatExpense(expense)}.`
      : `Gasto atualizado: ${formatExpense({ ...expense, ...((pending.proposed_changes ?? {}) as PendingChanges) })}.`;
  await saveAssistantExchange(userId, message, answer);
  return answer;
}

export async function classifyMessageIntent(userId: string, message: string): Promise<"gasto" | "lembrete" | "tarefa" | "chat"> {
  const now = currentSaoPauloDateTime();
  const system =
    `Agora em America/Sao_Paulo é ${now}. Classifique a mensagem em uma única palavra, sem explicações: ` +
    '"gasto" apenas se registrar uma compra/pagamento com valor em dinheiro; ' +
    '"lembrete" apenas se pedir para lembrar, marcar, agendar ou adicionar algo com data ou horário específico; ' +
    '"tarefa" se pedir para criar, anotar, listar, concluir ou excluir uma tarefa sem data e sem horário; ' +
    '"chat" para qualquer outra coisa (pergunta, conversa, consulta de dados, edição ou exclusão). ' +
    "Responda apenas com a palavra, nada mais.";
  const answer = await callAnthropic({
    userId,
    origin: "classificacao_intencao",
    model: ANTHROPIC_MODELS.haiku,
    maxTokens: 5,
    system,
    messages: [{ role: "user", content: message }],
  });
  const normalizedAnswer = answer.trim().toLocaleLowerCase("pt-BR");
  if (normalizedAnswer.startsWith("gasto")) return "gasto";
  if (normalizedAnswer.startsWith("lembrete")) return "lembrete";
  if (normalizedAnswer.startsWith("tarefa")) return "tarefa";
  return "chat";
}

export async function answerTelegramAssistant(userId: string, message: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const [{ data: recent, error: historyError }, { data: categoryRows, error: categoriesError }] = await Promise.all([
    supabaseAdmin
      .from("assistant_messages")
      .select("role,content")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })
      .limit(8),
    supabaseAdmin.from("categories").select("name").eq("user_id", userId),
  ]);

  if (historyError) throw historyError;
  if (categoriesError) throw categoriesError;

  const history = [...(recent ?? [])]
    .reverse()
    .filter(
      (item: StoredMessage): item is StoredMessage & { role: AssistantRole } =>
        item.role === "user" || item.role === "assistant",
    )
    .map((item) => ({ role: item.role, content: item.content }));

  const { error: userMessageError } = await supabaseAdmin.from("assistant_messages").insert({
    user_id: userId,
    role: "user",
    content: message,
  });
  if (userMessageError) throw userMessageError;

  const categories = categoryRows?.map((row) => row.name) ?? [];
  const now = currentSaoPauloDateTime();
  const system =
    "Seu nome é GHoST. Você é o assistente pessoal geral do usuário no Telegram, não um assistente de gastos. Quando perguntarem seu nome ou quem você é, apresente-se como GHoST. Responda em português do Brasil, de forma direta, natural e útil sobre qualquer assunto. " +
    `A data e hora atual real em America/Sao_Paulo é ${now}. ` +
    "Acione cada módulo somente quando o pedido realmente precisar dele: gastos para finanças; tarefa é sempre um item simples sem data e sem horário; lembrete/Agenda é sempre um compromisso com data ou horário específico. Nunca trate algo com data/hora como tarefa e nunca crie lembrete sem data/hora. Não force assuntos gerais para o módulo de gastos. " +
    "As ferramentas de consulta e dados estão sempre disponíveis. Decida por conta própria, em toda mensagem, se precisa usá-las. Quando o pedido depender de dados reais, use as ferramentas; quando não depender, responda diretamente sem chamar ferramentas. Não invente dados nem diga que não tem acesso. Inserções, atualizações e exclusões apenas preparam a operação e sempre exigem confirmação posterior. Exclusões em massa só podem usar excluir_dados_em_massa, com filtros e contagem explícita. " +
    "Estrutura do app: Início apresenta os módulos; Dashboard de Gastos mostra resumo, gráficos, filtros e a Planilha de Gastos; Tarefas lista e gerencia itens simples sem data; Agenda lista e gerencia compromissos e lembretes com data ou hora; Parâmetros guarda informações pessoais salvas pelo usuário; Uso da IA mostra tokens e custos estimados; Configurações reúne conta e vínculo com o Telegram. O assistente geral funciona somente neste chat do Telegram. Ao orientar o usuário, use exatamente esses nomes e indique o módulo correto. Para criar, listar, concluir, reabrir ou excluir tarefas, use as ferramentas genéricas na tabela tasks. " +
    `Categorias válidas: ${categories.join(", ") || "Outros"}. Catálogo: ${JSON.stringify(describeDataCatalog())}. ` +
    "Nunca afirme que criou, adicionou, editou ou excluiu algo sem receber o resultado real da ferramenta correspondente. Se uma confirmação como 'sim' chegar sem uma operação pendente, diga que não há ação preparada e peça o pedido novamente. " +
    "Nunca use asteriscos nas respostas, nem para destaque, listas ou qualquer formatação. Quando precisar organizar a mensagem, use emojis e texto simples. Seja conciso para economizar tokens. Datas e horários usam America/Sao_Paulo.";
  const toolMessages: AnthropicMessage[] = [...history, { role: "user", content: message }];
  const model = ANTHROPIC_MODELS.haiku;
  const maxTokens = 150;
  let answer = "";
  let uniquelyMatchedExpenseId: string | null = null;

  for (let step = 0; step < 4; step += 1) {
    const response = await callAnthropicWithTools({
      userId,
      origin: "chat_geral",
      model,
      maxTokens,
      system,
      messages: toolMessages,
      tools: ASSISTANT_TOOLS,
    });
    const content = response.content ?? [];
    const text = content
      .filter((part): part is Extract<AnthropicContent, { type: "text" }> => part.type === "text")
      .map((part) => part.text)
      .join("\n")
      .trim();
    const toolUses = content.filter(
      (part): part is Extract<AnthropicContent, { type: "tool_use" }> => part.type === "tool_use",
    );

    if (toolUses.length === 0) {
      answer = text || "Não encontrei uma resposta para isso.";
      break;
    }

    toolMessages.push({ role: "assistant", content });
    const results: AnthropicContent[] = [];

    for (const toolUse of toolUses) {
      try {
        if (toolUse.name === "consultar_dados") {
          const result = await queryUserData(supabaseAdmin, userId, toolUse.input);
          results.push({ type: "tool_result", tool_use_id: toolUse.id, content: JSON.stringify(result) });
          continue;
        }

        if (toolUse.name === "inserir_dados") {
          const table = asNullableString(toolUse.input["tabela"]);
          if (!table) throw new Error("Tabela ausente.");
          const values = prepareInsert(table, toolUse.input["valores"]);
          await createPendingDataAction(supabaseAdmin, userId, {
            table,
            type: "insert",
            values,
          });
          answer = `Confirma adicionar este registro em ${table}? Valores: ${compactRecord(values)}. Responda somente “sim” para confirmar ou “cancelar”.`;
          break;
        }

        if (toolUse.name === "atualizar_dados") {
          const table = asNullableString(toolUse.input["tabela"]);
          if (!table) throw new Error("Tabela ausente.");
          const snapshot = await findSingleUserRecord(supabaseAdmin, userId, table, toolUse.input["filtros"]);
          const values = prepareUpdate(table, toolUse.input["valores"]);
          const targetId = table === "profiles" ? userId : String(snapshot["id"] ?? "");
          if (!targetId) throw new Error("O registro não possui um identificador válido.");
          await createPendingDataAction(supabaseAdmin, userId, {
            table,
            type: "update",
            targetId,
            values,
            snapshot,
          });
          answer = `Confirma atualizar este registro em ${table}? Antes: ${compactRecord(snapshot)}. Depois: ${compactRecord({ ...snapshot, ...values })}. Responda somente “sim” para confirmar ou “cancelar”.`;
          break;
        }

        if (toolUse.name === "excluir_dados") {
          const table = asNullableString(toolUse.input["tabela"]);
          if (!table) throw new Error("Tabela ausente.");
          prepareDelete(table);
          const snapshot = await findSingleUserRecord(supabaseAdmin, userId, table, toolUse.input["filtros"]);
          const targetId = table === "profiles" ? userId : String(snapshot["id"] ?? "");
          if (!targetId) throw new Error("O registro não possui um identificador válido.");
          await createPendingDataAction(supabaseAdmin, userId, {
            table,
            type: "delete",
            targetId,
            values: {},
            snapshot,
          });
          answer = `Confirma excluir este registro de ${table}? Registro: ${compactRecord(snapshot)}. Responda somente “sim” para confirmar ou “cancelar”.`;
          break;
        }

        if (toolUse.name === "excluir_dados_em_massa") {
          const table = asNullableString(toolUse.input["tabela"]);
          if (!table) throw new Error("Tabela ausente.");
          const result = await countUserRecordsForBulkDelete(
            supabaseAdmin,
            userId,
            table,
            toolUse.input["filtros"],
            toolUse.input["todos"] === true,
          );
          if (result.count === 0) throw new Error("Nenhum registro corresponde aos filtros informados.");
          await createPendingBulkDelete(
            supabaseAdmin,
            userId,
            table,
            result.filters,
            result.count,
            toolUse.input["todos"] === true,
          );
          answer = `Isso vai excluir ${result.count} ${result.count === 1 ? "registro" : "registros"} de ${table}. Confirma? Responda somente “sim” para confirmar ou “cancelar”.`;
          break;
        }

        if (toolUse.name === "buscar_gastos") {
          const description = asNullableString(toolUse.input["descricao"]);
          const amount = asNullableNumber(toolUse.input["valor"]);
          const startDate = asNullableString(toolUse.input["data_inicio"]);
          const endDate = asNullableString(toolUse.input["data_fim"]);
          let query = supabaseAdmin
            .from("expenses")
            .select("id,occurred_at,merchant,amount,category,city")
            .eq("user_id", userId)
            .order("occurred_at", { ascending: false })
            .limit(6);
          if (description) query = query.ilike("merchant", `%${description.replace(/[%_]/g, "")}%`);
          if (amount !== null) query = query.eq("amount", amount);
          if (startDate && !Number.isNaN(Date.parse(startDate))) query = query.gte("occurred_at", startDate);
          if (endDate && !Number.isNaN(Date.parse(endDate))) query = query.lte("occurred_at", endDate);
          const { data: matches, error: searchError } = await query;
          if (searchError) throw searchError;
          uniquelyMatchedExpenseId = matches?.length === 1 ? (matches[0]?.id ?? null) : null;
          results.push({
            type: "tool_result",
            tool_use_id: toolUse.id,
            content: JSON.stringify({
              count: matches?.length ?? 0,
              expenses: (matches ?? []).map((expense) => ({
                ...expense,
                amount: Number(expense.amount),
                display: formatExpense(expense),
              })),
            }),
          });
          continue;
        }

        const expenseId = asNullableString(toolUse.input["expense_id"]);
        if (!expenseId) throw new Error("expense_id ausente");
        if (expenseId !== uniquelyMatchedExpenseId) {
          throw new Error("A edição ou exclusão exige uma busca imediatamente anterior com exatamente um resultado.");
        }
        const { data: expense, error: expenseError } = await supabaseAdmin
          .from("expenses")
          .select("id,occurred_at,merchant,amount,category,city")
          .eq("id", expenseId)
          .eq("user_id", userId)
          .maybeSingle();
        if (expenseError) throw expenseError;
        if (!expense) throw new Error("Lançamento não encontrado para este usuário.");

        const actionType = "delete";
        const changes: PendingChanges = {};

        const expiresAt = new Date(Date.now() + 15 * 60 * 1000).toISOString();
        const { error: pendingError } = await supabaseAdmin.from("pending_expense_actions").upsert(
          {
            user_id: userId,
            expense_id: expense.id,
            action_type: actionType,
            proposed_changes: null,
            expense_snapshot: expense as unknown as Json,
            expires_at: expiresAt,
          },
          { onConflict: "user_id" },
        );
        if (pendingError) throw pendingError;

        answer = `Confirma excluir este gasto? ${formatExpense(expense)}. Responda somente “sim” para confirmar ou “cancelar”.`;
        break;
      } catch (error) {
        results.push({
          type: "tool_result",
          tool_use_id: toolUse.id,
          content: error instanceof Error ? error.message : "Erro ao executar ferramenta.",
          is_error: true,
        });
      }
    }

    if (answer) break;
    toolMessages.push({ role: "user", content: results });
  }

  if (!answer) answer = "Não consegui concluir esse pedido com segurança. Pode reformular o que deseja fazer?";

  const { error: assistantMessageError } = await supabaseAdmin
    .from("assistant_messages")
    .insert({ user_id: userId, role: "assistant", content: answer });
  if (assistantMessageError) throw assistantMessageError;

  return answer;
}
