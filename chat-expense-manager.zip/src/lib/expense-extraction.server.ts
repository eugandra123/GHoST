import { ANTHROPIC_MODELS, callAnthropic, type AnthropicContent } from "./anthropic.server";

export type ExtractedExpense = {
  merchant: string;
  amount: number;
  occurred_at: string | null;
  category: string;
  city: string | null;
};

const SYSTEM = (categories: string[]) => `Você é um extrator de gastos de cartão de crédito brasileiro.
Extraia os dados do gasto e responda APENAS com um objeto JSON válido, sem markdown, no formato:
{"merchant": string, "amount": number, "occurred_at": string|null, "category": string, "city": string|null}

Regras:
- "merchant" é o nome do estabelecimento ou a descrição curta do gasto.
- "amount" é o valor em reais como número (ex: 70.8). Nunca inclua "R$" nem separador de milhar.
- "occurred_at" é a data/hora em ISO 8601 se estiver visível; caso contrário null.
- "category" deve ser exatamente uma destas: ${categories.join(", ")}.
- "city" é a cidade se aparecer; caso contrário null.
- Se houver várias transações na imagem, use a mais destacada/primeira.`;

const IMAGE_LIST_SYSTEM = (categories: string[], now: Date) => {
  const saoPauloNow = new Intl.DateTimeFormat("pt-BR", {
    timeZone: "America/Sao_Paulo",
    dateStyle: "full",
    timeStyle: "long",
  }).format(now);

  return `Você é um extrator de gastos de cartão de crédito brasileiro.
Analise a imagem inteira e extraia TODAS as linhas de transações visíveis. Responda APENAS com um objeto JSON válido, sem markdown, no formato:
{"expenses":[{"merchant":string,"amount":number,"occurred_at":string|null,"category":string,"city":string|null}]}

Regras:
- Cada linha visualmente distinta de transação deve ser um item separado em "expenses", inclusive em listas como “Transações recentes” da carteira do iPhone.
- Não inclua saldo, limite, total da fatura, cabeçalhos ou outros valores que não sejam uma transação.
- "merchant" é o nome do estabelecimento ou a descrição curta do gasto.
- "amount" é o valor em reais como número positivo (ex: 70.8). Nunca inclua "R$" nem separador de milhar.
- Agora é ${now.toISOString()} (${saoPauloNow}, fuso America/Sao_Paulo).
- Converta referências relativas como “há 9 horas”, “ontem” e dias da semana para uma data/hora ISO 8601 aproximada. Para “ontem” sem horário, use 12:00 no fuso America/Sao_Paulo. Se não houver referência temporal, use null.
- "category" deve ser exatamente uma destas: ${categories.join(", ")}.
- "city" é a cidade se aparecer; caso contrário null.
- Preserve a ordem em que as transações aparecem na imagem.
- Se nenhuma transação completa com estabelecimento e valor estiver visível, responda {"expenses":[]}.`;
};

function parseJson(text: string, categories: string[]): ExtractedExpense | null {
  const match = text.match(/\{[\s\S]*\}/);
  if (!match) return null;
  try {
    const raw = JSON.parse(match[0]) as Record<string, unknown>;
    const amount =
      typeof raw["amount"] === "number"
        ? raw["amount"]
        : Number(String(raw["amount"] ?? "").replace(/\./g, "").replace(",", "."));
    if (!Number.isFinite(amount)) return null;
    const category = String(raw["category"] ?? "Outros");
    return {
      merchant: String(raw["merchant"] ?? "Gasto"),
      amount: Math.abs(Number(amount)),
      occurred_at: raw["occurred_at"] ? String(raw["occurred_at"]) : null,
      category: categories.includes(category) ? category : "Outros",
      city: raw["city"] ? String(raw["city"]) : null,
    };
  } catch {
    return null;
  }
}

function normalizeExpense(raw: unknown, categories: string[]): ExtractedExpense | null {
  if (!raw || typeof raw !== "object") return null;
  const record = raw as Record<string, unknown>;
  const merchant = String(record["merchant"] ?? "").trim();
  const amount =
    typeof record["amount"] === "number"
      ? record["amount"]
      : Number(String(record["amount"] ?? "").replace(/\./g, "").replace(",", "."));
  if (!merchant || !Number.isFinite(amount) || Number(amount) <= 0) return null;

  const rawDate = record["occurred_at"] ? String(record["occurred_at"]) : null;
  const occurredAt = rawDate && !Number.isNaN(Date.parse(rawDate)) ? rawDate : null;
  const category = String(record["category"] ?? "Outros");

  return {
    merchant,
    amount: Math.abs(Number(amount)),
    occurred_at: occurredAt,
    category: categories.includes(category) ? category : "Outros",
    city: record["city"] ? String(record["city"]) : null,
  };
}

function parseExpenseList(text: string, categories: string[]): ExtractedExpense[] {
  const match = text.match(/\{[\s\S]*\}/);
  if (!match) return [];
  try {
    const raw = JSON.parse(match[0]) as Record<string, unknown>;
    if (!Array.isArray(raw["expenses"])) return [];
    return raw["expenses"]
      .map((item) => normalizeExpense(item, categories))
      .filter((item): item is ExtractedExpense => item !== null);
  } catch {
    return [];
  }
}

export async function extractFromText(
  text: string,
  categories: string[],
  userId: string,
): Promise<ExtractedExpense | null> {
  const textResult = await callAnthropic({
    userId,
    origin: "extracao_gasto",
    model: ANTHROPIC_MODELS.haiku,
    maxTokens: 200,
    system: SYSTEM(categories),
    messages: [{ role: "user", content: [{ type: "text", text }] }],
  });
  return parseJson(textResult, categories);
}

export async function extractFromImage(
  imageUrl: string,
  categories: string[],
  userId: string,
  caption?: string,
): Promise<ExtractedExpense | null> {
  const response = await fetch(imageUrl);
  if (!response.ok) throw new Error("Não foi possível baixar a imagem do gasto.");
  const mediaType = response.headers.get("content-type")?.split(";")[0] || "image/jpeg";
  return extractFromImageSource(
    new Uint8Array(await response.arrayBuffer()),
    categories,
    userId,
    caption,
    mediaType,
  );
}

export async function extractFromImageBytes(
  bytes: Uint8Array,
  mediaType: string,
  categories: string[],
  userId: string,
  caption?: string,
): Promise<ExtractedExpense | null> {
  return extractFromImageSource(bytes, categories, userId, caption, mediaType);
}

export async function extractExpensesFromImageBytes(
  bytes: Uint8Array,
  mediaType: string,
  categories: string[],
  userId: string,
  caption?: string,
): Promise<ExtractedExpense[]> {
  const now = new Date();
  const textResult = await callAnthropic({
    userId,
    origin: "extracao_gasto",
    model: ANTHROPIC_MODELS.haiku,
    maxTokens: 700,
    system: IMAGE_LIST_SYSTEM(categories, now),
    messages: [
      {
        role: "user",
        content: [
          {
            type: "text",
            text:
              caption?.trim() ||
              "Extraia todas as transações mostradas neste print, uma por item.",
          },
          imageContent(bytes, mediaType),
        ],
      },
    ],
  });
  return parseExpenseList(textResult, categories);
}

function imageContent(bytes: Uint8Array, mediaType: string): AnthropicContent {
  return {
    type: "image",
    source: {
      type: "base64",
      media_type: mediaType,
      data: Buffer.from(bytes).toString("base64"),
    },
  };
}

async function extractFromImageSource(
  image: Uint8Array,
  categories: string[],
  userId: string,
  caption?: string,
  mediaType = "image/jpeg",
): Promise<ExtractedExpense | null> {
  const textResult = await callAnthropic({
    userId,
    origin: "extracao_gasto",
    model: ANTHROPIC_MODELS.haiku,
    maxTokens: 250,
    system: SYSTEM(categories),
    messages: [
      {
        role: "user",
        content: [
          {
            type: "text",
            text:
              caption?.trim() ||
              "Extraia o gasto mostrado neste print de transação de cartão de crédito.",
          },
          imageContent(image, mediaType),
        ],
      },
    ],
  });
  return parseJson(textResult, categories);
}
