import type { SupabaseClient } from "@supabase/supabase-js";

import type { Json } from "@/integrations/supabase/types";

type FilterOperator = "eq" | "gte" | "lte" | "ilike";

export type DataFilter = {
  column: string;
  operator: FilterOperator;
  value: string | number | boolean;
};

type TablePolicy = {
  ownerColumn: "user_id" | "id";
  readable: readonly string[];
  insertable: readonly string[];
  updatable: readonly string[];
  deletable: boolean;
  requiredOnInsert: readonly string[];
  defaultOrder?: string;
};

export const DATA_TABLES = {
  expenses: {
    ownerColumn: "user_id",
    readable: ["id", "occurred_at", "merchant", "amount", "category", "city", "source", "created_at", "updated_at"],
    insertable: ["occurred_at", "merchant", "amount", "category", "city", "source", "raw_input"],
    updatable: ["occurred_at", "merchant", "amount", "category", "city"],
    deletable: true,
    requiredOnInsert: ["merchant", "amount"],
    defaultOrder: "occurred_at",
  },
  categories: {
    ownerColumn: "user_id",
    readable: ["id", "name", "color", "created_at"],
    insertable: ["name", "color"],
    updatable: ["name", "color"],
    deletable: true,
    requiredOnInsert: ["name"],
    defaultOrder: "created_at",
  },
  assistant_messages: {
    ownerColumn: "user_id",
    readable: ["id", "role", "content", "created_at"],
    insertable: [],
    updatable: [],
    deletable: false,
    requiredOnInsert: [],
    defaultOrder: "created_at",
  },
  ai_usage: {
    ownerColumn: "user_id",
    readable: ["id", "model", "model_family", "input_tokens", "output_tokens", "estimated_cost_usd", "origin", "created_at"],
    insertable: [],
    updatable: [],
    deletable: false,
    requiredOnInsert: [],
    defaultOrder: "created_at",
  },
  whatsapp_messages: {
    ownerColumn: "user_id",
    readable: ["id", "channel", "kind", "body", "status", "error", "expense_id", "created_at"],
    insertable: [],
    updatable: [],
    deletable: false,
    requiredOnInsert: [],
    defaultOrder: "created_at",
  },
  profiles: {
    ownerColumn: "id",
    readable: ["id", "display_name", "whatsapp_phone", "telegram_username", "created_at"],
    insertable: [],
    updatable: ["display_name", "whatsapp_phone"],
    deletable: false,
    requiredOnInsert: [],
    defaultOrder: "created_at",
  },
  reminders: {
    ownerColumn: "user_id",
    readable: ["id", "title", "starts_at", "ends_at", "details", "created_at", "updated_at"],
    insertable: ["title", "starts_at", "ends_at", "details", "aviso_antecedencia_minutos"],
    updatable: ["title", "starts_at", "ends_at", "details", "aviso_antecedencia_minutos"],
    deletable: true,
    requiredOnInsert: ["title", "starts_at", "ends_at"],
    defaultOrder: "starts_at",
  },
  tasks: {
    ownerColumn: "user_id",
    readable: ["id", "description", "status", "created_at"],
    insertable: ["description", "status"],
    updatable: ["description", "status"],
    deletable: true,
    requiredOnInsert: ["description"],
    defaultOrder: "created_at",
  },
  user_parameters: {
    ownerColumn: "user_id",
    readable: ["id", "key", "value", "created_at", "updated_at"],
    insertable: ["key", "value"],
    updatable: ["key", "value"],
    deletable: true,
    requiredOnInsert: ["key", "value"],
    defaultOrder: "updated_at",
  },
} as const satisfies Record<string, TablePolicy>;

export type DataTable = keyof typeof DATA_TABLES;

export type PendingDataAction = {
  id: string;
  target_table: string;
  target_id: string | null;
  action_type: string;
  proposed_values: Json;
  record_snapshot: Json | null;
  expires_at: string;
};

type BulkDeletePayload = {
  filters: DataFilter[];
  expected_count: number;
  all_records: boolean;
};

function database(client: unknown) {
  return client as SupabaseClient;
}

function policyFor(table: string): TablePolicy {
  const policy = DATA_TABLES[table as DataTable];
  if (!policy) throw new Error("Tabela não autorizada para o assistente.");
  return policy;
}

function cleanObject(values: unknown, allowed: readonly string[]) {
  if (!values || typeof values !== "object" || Array.isArray(values)) {
    throw new Error("Os valores precisam ser um objeto.");
  }
  const source = values as Record<string, unknown>;
  const cleaned: Record<string, Json> = {};
  for (const [key, value] of Object.entries(source)) {
    if (!allowed.includes(key)) throw new Error(`Campo não autorizado: ${key}.`);
    if (
      value === null ||
      typeof value === "string" ||
      typeof value === "number" ||
      typeof value === "boolean"
    ) cleaned[key] = value;
    else throw new Error(`Valor inválido para ${key}.`);
  }
  return cleaned;
}

function cleanColumns(columns: unknown, allowed: readonly string[]) {
  if (!Array.isArray(columns) || columns.length === 0) return [...allowed];
  const cleaned = columns.filter((column): column is string => typeof column === "string");
  if (cleaned.some((column) => !allowed.includes(column))) {
    throw new Error("A consulta contém uma coluna não autorizada.");
  }
  return [...new Set(cleaned)];
}

function cleanFilters(filters: unknown, allowed: readonly string[]) {
  if (!Array.isArray(filters)) return [];
  return filters.map((raw) => {
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) throw new Error("Filtro inválido.");
    const filter = raw as Partial<DataFilter>;
    if (typeof filter.column !== "string" || !allowed.includes(filter.column)) {
      throw new Error("O filtro usa uma coluna não autorizada.");
    }
    if (!filter.operator || !(["eq", "gte", "lte", "ilike"] as const).includes(filter.operator)) {
      throw new Error("Operador de filtro não autorizado.");
    }
    if (!["string", "number", "boolean"].includes(typeof filter.value)) {
      throw new Error("Valor de filtro inválido.");
    }
    return filter as DataFilter;
  });
}

function applyFilters(query: any, filters: DataFilter[]) {
  let filtered = query;
  for (const filter of filters) {
    if (filter.operator === "eq") filtered = filtered.eq(filter.column, filter.value);
    if (filter.operator === "gte") filtered = filtered.gte(filter.column, filter.value);
    if (filter.operator === "lte") filtered = filtered.lte(filter.column, filter.value);
    if (filter.operator === "ilike") {
      const safe = String(filter.value).replace(/[%_]/g, "");
      filtered = filtered.ilike(filter.column, `%${safe}%`);
    }
  }
  return filtered;
}

export function describeDataCatalog() {
  return Object.entries(DATA_TABLES).map(([table, policy]) => ({
    table,
    readable_columns: policy.readable,
    insertable_columns: policy.insertable,
    updatable_columns: policy.updatable,
    deletable: policy.deletable,
    required_on_insert: policy.requiredOnInsert,
  }));
}

export async function queryUserData(
  client: unknown,
  userId: string,
  input: Record<string, unknown>,
) {
  const table = typeof input["tabela"] === "string" ? input["tabela"] : "";
  const policy = policyFor(table);
  const columns = cleanColumns(input["colunas"], policy.readable);
  const filters = cleanFilters(input["filtros"], policy.readable);
  const operation = input["operacao"] === "contar" || input["operacao"] === "somar"
    ? input["operacao"]
    : "listar";
  const aggregateColumn = typeof input["coluna_agregacao"] === "string"
    ? input["coluna_agregacao"]
    : null;
  if (operation === "somar" && (!aggregateColumn || !policy.readable.includes(aggregateColumn))) {
    throw new Error("Informe uma coluna autorizada para somar.");
  }
  const limit = Math.min(200, Math.max(1, Math.trunc(Number(input["limite"]) || 20)));
  const orderBy = typeof input["ordenar_por"] === "string" && policy.readable.includes(input["ordenar_por"])
    ? input["ordenar_por"]
    : policy.defaultOrder;
  const selectColumns = operation === "somar" && aggregateColumn
    ? [...new Set([aggregateColumn, ...columns])]
    : columns;

  let query = database(client)
    .from(table)
    .select(selectColumns.join(","))
    .eq(policy.ownerColumn, userId)
    .limit(operation === "listar" ? limit : 1000);
  for (const filter of filters) {
    if (filter.operator === "eq") query = query.eq(filter.column, filter.value);
    if (filter.operator === "gte") query = query.gte(filter.column, filter.value);
    if (filter.operator === "lte") query = query.lte(filter.column, filter.value);
    if (filter.operator === "ilike") {
      const safe = String(filter.value).replace(/[%_]/g, "");
      query = query.ilike(filter.column, `%${safe}%`);
    }
  }
  if (orderBy) query = query.order(orderBy, { ascending: input["ordem"] === "asc" });
  const { data, error } = await query;
  if (error) throw error;
  const rows = (data ?? []) as unknown as Array<Record<string, Json>>;
  if (operation === "contar") return { table, count: rows.length };
  if (operation === "somar" && aggregateColumn) {
    const total = rows.reduce((sum, row) => sum + Number(row[aggregateColumn] ?? 0), 0);
    return { table, column: aggregateColumn, total, matched_rows: rows.length };
  }
  return { table, count: rows.length, rows };
}

export async function findSingleUserRecord(
  client: unknown,
  userId: string,
  table: string,
  filtersInput: unknown,
  allowAll = false,
) {
  const policy = policyFor(table);
  const filters = cleanFilters(filtersInput, policy.readable);
  if (filters.length === 0) throw new Error("A atualização exige filtros que identifiquem um registro.");
  let query = database(client)
    .from(table)
    .select(policy.readable.join(","))
    .eq(policy.ownerColumn, userId)
    .limit(2);
  for (const filter of filters) {
    if (filter.operator === "eq") query = query.eq(filter.column, filter.value);
    if (filter.operator === "gte") query = query.gte(filter.column, filter.value);
    if (filter.operator === "lte") query = query.lte(filter.column, filter.value);
    if (filter.operator === "ilike") {
      const safe = String(filter.value).replace(/[%_]/g, "");
      query = query.ilike(filter.column, `%${safe}%`);
    }
  }
  const { data, error } = await query;
  if (error) throw error;
  if (!data?.length) throw new Error("Nenhum registro foi encontrado.");
  if (data.length !== 1) throw new Error("A atualização afetaria mais de um registro. Refine a consulta e confirme qual item deseja alterar.");
  return data[0] as unknown as Record<string, Json>;
}

export function prepareInsert(table: string, values: unknown) {
  const policy = policyFor(table);
  if (policy.insertable.length === 0) throw new Error("Inserções não são permitidas nessa tabela.");
  const cleaned = cleanObject(values, policy.insertable);
  for (const required of policy.requiredOnInsert) {
    if (cleaned[required] === undefined || cleaned[required] === null || cleaned[required] === "") {
      throw new Error(`Campo obrigatório ausente: ${required}.`);
    }
  }
  if (table === "reminders") validateReminderDates(cleaned);
  if (table === "tasks") validateTaskValues(cleaned);
  return cleaned;
}

export function prepareUpdate(table: string, values: unknown) {
  const policy = policyFor(table);
  if (policy.updatable.length === 0) throw new Error("Atualizações não são permitidas nessa tabela.");
  const cleaned = cleanObject(values, policy.updatable);
  if (Object.keys(cleaned).length === 0) throw new Error("Nenhuma alteração válida foi informada.");
  if (table === "reminders") validateReminderDates(cleaned, false);
  if (table === "tasks") validateTaskValues(cleaned);
  return cleaned;
}

export function prepareDelete(table: string) {
  const policy = policyFor(table);
  if (!policy.deletable) throw new Error("Exclusões não são permitidas nessa tabela.");
}

export async function countUserRecordsForBulkDelete(
  client: unknown,
  userId: string,
  table: string,
  filtersInput: unknown,
  allowAll = false,
) {
  const policy = policyFor(table);
  prepareDelete(table);
  const filters = cleanFilters(filtersInput, policy.readable);
  if (filters.length === 0 && !allowAll) {
    throw new Error("Para excluir todos os registros, confirme explicitamente a opção todos.");
  }
  let query = database(client)
    .from(table)
    .select("id", { count: "exact", head: true })
    .eq(policy.ownerColumn, userId);
  query = applyFilters(query, filters);
  const { count, error } = await query;
  if (error) throw error;
  return { filters, count: count ?? 0 };
}

function validateReminderDates(values: Record<string, Json>, requireBoth = true) {
  const startsAt = values["starts_at"];
  const endsAt = values["ends_at"];
  if (requireBoth && (typeof startsAt !== "string" || typeof endsAt !== "string")) {
    throw new Error("O lembrete precisa de data e hora de início e fim.");
  }
  if (startsAt !== undefined && (typeof startsAt !== "string" || Number.isNaN(Date.parse(startsAt)))) {
    throw new Error("A data de início do lembrete é inválida.");
  }
  if (endsAt !== undefined && (typeof endsAt !== "string" || Number.isNaN(Date.parse(endsAt)))) {
    throw new Error("A data de fim do lembrete é inválida.");
  }
  if (typeof startsAt === "string" && typeof endsAt === "string" && Date.parse(endsAt) <= Date.parse(startsAt)) {
    throw new Error("A data de fim do lembrete deve ser posterior ao início.");
  }
  const leadMinutes = values["aviso_antecedencia_minutos"];
  if (
    leadMinutes !== undefined &&
    (typeof leadMinutes !== "number" || !Number.isInteger(leadMinutes) || leadMinutes < 0 || leadMinutes > 43200)
  ) {
    throw new Error("A antecedência do aviso deve ser um número inteiro de minutos entre 0 e 43200.");
  }
}

function validateTaskValues(values: Record<string, Json>) {
  const description = values["description"];
  const status = values["status"];
  if (description !== undefined && (typeof description !== "string" || !description.trim() || description.length > 500)) {
    throw new Error("A descrição da tarefa deve ter entre 1 e 500 caracteres.");
  }
  if (status !== undefined && status !== "pendente" && status !== "concluída") {
    throw new Error('O status da tarefa deve ser "pendente" ou "concluída".');
  }
}

export async function createPendingDataAction(
  client: unknown,
  userId: string,
  action: {
    table: string;
    type: "insert" | "update" | "delete" | "bulk_delete";
    targetId?: string | null;
    values: Record<string, Json>;
    snapshot?: Record<string, Json> | null;
  },
) {
  const { error } = await database(client).from("pending_data_actions").upsert(
    {
      user_id: userId,
      target_table: action.table,
      target_id: action.targetId ?? null,
      action_type: action.type,
      proposed_values: action.values,
      record_snapshot: action.snapshot ?? null,
      expires_at: new Date(Date.now() + 15 * 60 * 1000).toISOString(),
    },
    { onConflict: "user_id" },
  );
  if (error) throw error;
}

export async function createPendingBulkDelete(
  client: unknown,
  userId: string,
  table: string,
  filters: DataFilter[],
  expectedCount: number,
  allRecords: boolean,
) {
  const payload: BulkDeletePayload = { filters, expected_count: expectedCount, all_records: allRecords };
  const { error } = await database(client).from("pending_data_actions").upsert(
    {
      user_id: userId,
      target_table: table,
      target_id: null,
      action_type: "bulk_delete",
      proposed_values: payload as unknown as Json,
      record_snapshot: null,
      expires_at: new Date(Date.now() + 15 * 60 * 1000).toISOString(),
    },
    { onConflict: "user_id" },
  );
  if (error) throw error;
}

export async function applyPendingDataAction(client: unknown, userId: string, pending: PendingDataAction) {
  const policy = policyFor(pending.target_table);
  const values = pending.proposed_values as Record<string, Json>;
  if (pending.action_type === "insert") {
    const safeValues = prepareInsert(pending.target_table, values);
    const row = policy.ownerColumn === "user_id"
      ? { ...safeValues, user_id: userId }
      : { ...safeValues, id: userId };
    const { data, error } = await database(client)
      .from(pending.target_table)
      .insert(row as never)
      .select(policy.readable.join(","))
      .single();
    if (error) throw error;
    return data as unknown as Record<string, Json>;
  }

  if (pending.action_type === "bulk_delete") {
    prepareDelete(pending.target_table);
    const payload = values as unknown as Partial<BulkDeletePayload>;
    const filters = cleanFilters(payload.filters, policy.readable);
    if (filters.length === 0 && payload.all_records !== true) {
      throw new Error("A exclusão em massa perdeu seus filtros e foi cancelada.");
    }
    let countQuery = database(client)
      .from(pending.target_table)
      .select("id", { count: "exact", head: true })
      .eq(policy.ownerColumn, userId);
    countQuery = applyFilters(countQuery, filters);
    const { count, error: countError } = await countQuery;
    if (countError) throw countError;
    if ((count ?? 0) !== payload.expected_count) {
      throw new Error("A quantidade de registros mudou desde a confirmação. Peça a exclusão novamente.");
    }
    let query = database(client)
      .from(pending.target_table)
      .delete()
      .eq(policy.ownerColumn, userId);
    query = applyFilters(query, filters);
    const { data, error } = await query.select("id");
    if (error) throw error;
    return { deleted_count: data?.length ?? 0 };
  }

  if (!pending.target_id) {
    throw new Error("Ação pendente inválida.");
  }
  if (pending.action_type === "delete") {
    prepareDelete(pending.target_table);
    let query = database(client)
      .from(pending.target_table)
      .delete()
      .eq(policy.ownerColumn, userId);
    query = policy.ownerColumn === "id"
      ? query.eq("id", userId)
      : query.eq("id", pending.target_id);
    const { data, error } = await query.select(policy.readable.join(",")).single();
    if (error) throw error;
    return data as unknown as Record<string, Json>;
  }
  if (pending.action_type !== "update") throw new Error("Ação pendente inválida.");
  const safeValues = prepareUpdate(pending.target_table, values);
  let query = database(client)
    .from(pending.target_table)
    .update(safeValues)
    .eq(policy.ownerColumn, userId);
  query = policy.ownerColumn === "id"
    ? query.eq("id", userId)
    : query.eq("id", pending.target_id);
  const { data, error } = await query.select(policy.readable.join(",")).single();
  if (error) throw error;
  return data as unknown as Record<string, Json>;
}

export function compactRecord(value: unknown) {
  return JSON.stringify(value, null, 0);
}