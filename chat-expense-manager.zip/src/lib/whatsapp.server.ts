/**
 * Envio de mensagens de volta para o WhatsApp.
 * Suporta Z-API e Whapi.Cloud. Enquanto os segredos não estiverem
 * configurados, a função apenas registra a mensagem no log do servidor.
 */
export async function sendWhatsAppMessage(phone: string, message: string) {
  const zapiInstance = process.env["ZAPI_INSTANCE_ID"];
  const zapiToken = process.env["ZAPI_TOKEN"];
  const zapiClientToken = process.env["ZAPI_CLIENT_TOKEN"];
  const whapiToken = process.env["WHAPI_TOKEN"];

  try {
    if (zapiInstance && zapiToken) {
      const res = await fetch(
        `https://api.z-api.io/instances/${zapiInstance}/token/${zapiToken}/send-text`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            ...(zapiClientToken ? { "Client-Token": zapiClientToken } : {}),
          },
          body: JSON.stringify({ phone, message }),
        },
      );
      return { sent: res.ok, provider: "z-api" as const };
    }

    if (whapiToken) {
      const res = await fetch("https://gate.whapi.cloud/messages/text", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${whapiToken}`,
        },
        body: JSON.stringify({ to: phone, body: message }),
      });
      return { sent: res.ok, provider: "whapi" as const };
    }
  } catch (error) {
    console.error("Falha ao enviar WhatsApp:", error);
    return { sent: false, provider: "none" as const };
  }

  console.log(`[whatsapp:dry-run] -> ${phone}: ${message}`);
  return { sent: false, provider: "none" as const };
}
