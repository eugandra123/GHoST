const GATEWAY_URL = "https://connector-gateway.lovable.dev/telegram";

function creds() {
  const lovableKey = process.env["LOVABLE_API_KEY"];
  const telegramKey = process.env["TELEGRAM_API_KEY"];
  if (!lovableKey || !telegramKey) return null;
  return { lovableKey, telegramKey };
}

async function callTelegram(method: string, body: Record<string, unknown>) {
  const c = creds();
  if (!c) {
    console.warn(`[telegram:dry-run] ${method}`, body);
    return null;
  }
  const res = await fetch(`${GATEWAY_URL}/${method}`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${c.lovableKey}`,
      "X-Connection-Api-Key": c.telegramKey,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
  });
  const text = await res.text();
  if (!res.ok) {
    console.error(`Telegram ${method} falhou [${res.status}]: ${text}`);
    throw new Error(`Telegram ${method} falhou [${res.status}]: ${text}`);
  }
  const json = JSON.parse(text) as { ok: boolean; result?: unknown; description?: string };
  if (!json.ok) {
    console.error(`Telegram ${method} retornou erro: ${json.description}`);
    throw new Error(`Telegram ${method} retornou erro: ${json.description}`);
  }
  return json.result;
}

export async function sendTelegramMessage(chatId: number | string, text: string) {
  await callTelegram("sendMessage", { chat_id: chatId, text });
}

/** Baixa um arquivo do Telegram (foto/documento) e devolve os bytes. */
export async function downloadTelegramFile(
  fileId: string,
): Promise<{ bytes: Uint8Array; mediaType: string } | null> {
  const c = creds();
  if (!c) return null;

  const result = (await callTelegram("getFile", { file_id: fileId })) as {
    file_path?: string;
  } | null;
  const filePath = result?.file_path;
  if (!filePath) return null;

  const res = await fetch(`${GATEWAY_URL}/file/${filePath}`, {
    headers: {
      Authorization: `Bearer ${c.lovableKey}`,
      "X-Connection-Api-Key": c.telegramKey,
    },
  });
  if (!res.ok) {
    const body = await res.text();
    console.error(`Download do arquivo do Telegram falhou [${res.status}]: ${body}`);
    throw new Error(`Download do arquivo do Telegram falhou [${res.status}]`);
  }
  const buffer = await res.arrayBuffer();
  const ext = filePath.split(".").pop()?.toLowerCase();
  const mediaType =
    ext === "png" ? "image/png" : ext === "webp" ? "image/webp" : "image/jpeg";
  return { bytes: new Uint8Array(buffer), mediaType };
}

/** SHA-256 base64url de `telegram-webhook:<key>` — mesmo valor usado no setWebhook. */
export async function deriveTelegramWebhookSecret(telegramApiKey: string): Promise<string> {
  const data = new TextEncoder().encode(`telegram-webhook:${telegramApiKey}`);
  const digest = await crypto.subtle.digest("SHA-256", data);
  let binary = "";
  for (const byte of new Uint8Array(digest)) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

export function timingSafeEqualStr(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}
