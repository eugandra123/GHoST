import { ANTHROPIC_MODELS, callAnthropic } from "./anthropic.server";

type ExtractedParameter = {
  key: string;
  value: string;
};

function parseParameterJson(text: string): ExtractedParameter | null {
  const match = text.match(/\{[\s\S]*\}/);
  if (!match) return null;
  try {
    const parsed = JSON.parse(match[0]) as Record<string, unknown>;
    const key = typeof parsed["key"] === "string"
      ? parsed["key"].trim().toLocaleLowerCase("pt-BR").slice(0, 120)
      : "";
    const value = typeof parsed["value"] === "string" ? parsed["value"].trim().slice(0, 1000) : "";
    return key && value ? { key, value } : null;
  } catch {
    return null;
  }
}

export async function saveTriggeredParameter(userId: string, content: string) {
  const cleanContent = content.trim();
  if (!cleanContent) throw new Error("Informe algo antes do * para salvar.");

  const response = await callAnthropic({
    userId,
    origin: "chat_geral",
    model: ANTHROPIC_MODELS.haiku,
    maxTokens: 80,
    system:
      "Extraia um parâmetro pessoal do texto em português. Responda somente JSON no formato {\"key\":\"chave curta\",\"value\":\"valor\"}. Normalize a chave para um substantivo curto, sem inventar ou alterar o valor informado.",
    messages: [{ role: "user", content: cleanContent }],
  });
  const parameter = parseParameterJson(response);
  if (!parameter) throw new Error("Não consegui identificar a chave e o valor para salvar.");

  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin
    .from("user_parameters")
    .upsert(
      { user_id: userId, key: parameter.key, value: parameter.value },
      { onConflict: "user_id,key" },
    )
    .select("key,value")
    .single();
  if (error) throw error;
  return data;
}