export const ANTHROPIC_MODELS = {
  haiku: "claude-haiku-4-5-20251001",
  sonnet: "claude-sonnet-5",
} as const;

// Keep Anthropic credentials server-only and read them at request time.

export type AnthropicModel = (typeof ANTHROPIC_MODELS)[keyof typeof ANTHROPIC_MODELS];

export type AnthropicUsageOrigin =
  | "extracao_gasto"
  | "chat_geral"
  | "gerenciamento_gasto"
  | "classificacao_intencao"
  | "lembrete"
  | "boletim_diario";

export class AnthropicRequestError extends Error {
  constructor(
    public readonly status: number,
    public readonly safeMessage: string,
  ) {
    super(`Anthropic respondeu com status ${status}: ${safeMessage}`);
    this.name = "AnthropicRequestError";
  }
}

export type AnthropicContent =
  | { type: "text"; text: string }
  | {
      type: "image";
      source: {
        type: "base64";
        media_type: string;
        data: string;
      };
    }
  | { type: "tool_use"; id: string; name: string; input: Record<string, unknown> }
  | { type: "tool_result"; tool_use_id: string; content: string; is_error?: boolean };

export type AnthropicMessage = {
  role: "user" | "assistant";
  content: string | AnthropicContent[];
};

type AnthropicRequest = {
  userId: string;
  origin: AnthropicUsageOrigin;
  model: AnthropicModel;
  maxTokens: number;
  system: string;
  messages: AnthropicMessage[];
};

export type AnthropicTool = {
  name: string;
  description: string;
  input_schema: Record<string, unknown>;
};

type AnthropicToolRequest = AnthropicRequest & {
  tools: AnthropicTool[];
};

type AnthropicResponse = {
  stop_reason?: string;
  content?: AnthropicContent[];
  usage?: {
    input_tokens?: number;
    output_tokens?: number;
  };
};

const TOKEN_PRICES = {
  haiku: { input: 1, output: 5 },
  sonnet: { input: 3, output: 15 },
} as const;

function getModelFamily(model: AnthropicModel) {
  return model === ANTHROPIC_MODELS.sonnet ? "sonnet" : "haiku";
}

async function recordUsage(
  userId: string,
  origin: AnthropicUsageOrigin,
  model: AnthropicModel,
  usage: AnthropicResponse["usage"],
) {
  const inputTokens = Math.max(0, Math.trunc(usage?.input_tokens ?? 0));
  const outputTokens = Math.max(0, Math.trunc(usage?.output_tokens ?? 0));
  const family = getModelFamily(model);
  const prices = TOKEN_PRICES[family];
  const estimatedCost = (inputTokens * prices.input + outputTokens * prices.output) / 1_000_000;

  try {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("ai_usage").insert({
      user_id: userId,
      model,
      model_family: family,
      input_tokens: inputTokens,
      output_tokens: outputTokens,
      estimated_cost_usd: estimatedCost,
      origin,
    });
    if (error) throw error;
  } catch (error) {
    console.error("Não foi possível registrar o uso da Anthropic:", error);
  }
}

async function requestAnthropic(
  body: Record<string, unknown>,
  tracking: Pick<AnthropicRequest, "userId" | "origin" | "model">,
) {
  const apiKey = process.env["ANTHROPIC_API_KEY"];
  if (!apiKey) throw new Error("A chave da Anthropic não está configurada.");

  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify(body),
  });

  if (!response.ok) {
    const detail = await response.text();
    console.error(`Anthropic request failed [${response.status}]: ${detail}`);
    let safeMessage = "Não foi possível gerar a resposta.";
    try {
      const parsed = JSON.parse(detail) as { error?: { message?: string } };
      safeMessage = parsed.error?.message ?? safeMessage;
    } catch {
      // Keep the safe fallback when the provider does not return JSON.
    }
    throw new AnthropicRequestError(response.status, safeMessage);
  }

  const payload = (await response.json()) as AnthropicResponse;
  await recordUsage(tracking.userId, tracking.origin, tracking.model, payload.usage);
  return payload;
}

export async function callAnthropic({
  model,
  maxTokens,
  system,
  messages,
  userId,
  origin,
}: AnthropicRequest) {
  const payload = await requestAnthropic(
    { model, max_tokens: maxTokens, system, messages },
    { userId, origin, model },
  );
  const text = payload.content
    ?.filter((part): part is Extract<AnthropicContent, { type: "text" }> => part.type === "text")
    .map((part) => part.text)
    .join("\n")
    .trim();

  if (!text) throw new Error("A IA não retornou uma resposta.");
  return text;
}

export async function callAnthropicWithTools({
  model,
  maxTokens,
  system,
  messages,
  tools,
  userId,
  origin,
}: AnthropicToolRequest) {
  return requestAnthropic(
    {
      model,
      max_tokens: maxTokens,
      system,
      messages,
      tools,
    },
    { userId, origin, model },
  );
}