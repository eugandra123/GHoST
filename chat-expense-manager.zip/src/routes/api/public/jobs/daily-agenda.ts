import { createFileRoute } from "@tanstack/react-router";

import { authenticateCronRequest } from "@/integrations/supabase/cron-auth";
import { ANTHROPIC_MODELS, AnthropicRequestError, callAnthropic } from "@/lib/anthropic.server";
import { sendTelegramMessage } from "@/lib/telegram.server";

const JOB_NAME = "daily-agenda";
const USER_LIMIT = 20;
const TIME_ZONE = "America/Sao_Paulo";

async function authenticateScheduledRequest(request: Request) {
  const provided = request.headers.get("apikey") ?? "";
  if (provided) {
    const expected = process.env["REMINDER_JOB_API_KEY"] ?? "";
    if (expected && provided.length === expected.length) {
      let difference = 0;
      for (let index = 0; index < provided.length; index += 1) {
        difference |= provided.charCodeAt(index) ^ expected.charCodeAt(index);
      }
      if (difference === 0) return null;
    }
  }
  return authenticateCronRequest(request);
}

function localDateParts(date: Date) {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: TIME_ZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(date);
  const value = (type: Intl.DateTimeFormatPartTypes) => parts.find((part) => part.type === type)?.value ?? "";
  return `${value("year")}-${value("month")}-${value("day")}`;
}

function formatCurrentDateTime() {
  return new Intl.DateTimeFormat("pt-BR", {
    timeZone: TIME_ZONE,
    dateStyle: "full",
    timeStyle: "short",
  }).format(new Date());
}

export const Route = createFileRoute("/api/public/jobs/daily-agenda")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const authError = await authenticateScheduledRequest(request);
        if (authError) return authError;

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const now = new Date();
        const { data: claimed, error: claimError } = await supabaseAdmin.rpc("claim_scheduled_job", {
          _job_name: JOB_NAME,
          _lease_minutes: 20,
        });
        if (claimError) throw claimError;
        if (!claimed) return Response.json({ ok: true, skipped: "locked_or_paused" });

        try {
          const { data: expired, error: expiredError } = await supabaseAdmin
            .from("reminders")
            .select("id")
            .lt("ends_at", now.toISOString())
            .order("ends_at", { ascending: true })
            .limit(500);
          if (expiredError) throw expiredError;
          if (expired?.length) {
            const { error: cleanupError } = await supabaseAdmin
              .from("reminders")
              .delete()
              .in("id", expired.map((item) => item.id));
            if (cleanupError) throw cleanupError;
          }

          const digestDate = localDateParts(now);
          const horizon = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000).toISOString();
          const { data: profiles, error: profilesError } = await supabaseAdmin
            .from("profiles")
            .select("id,telegram_chat_id")
            .not("telegram_chat_id", "is", null)
            .order("id", { ascending: true })
            .limit(100);
          if (profilesError) throw profilesError;

          let sent = 0;
          for (const profile of profiles ?? []) {
            if (sent >= USER_LIMIT) break;
            const { data: delivered, error: deliveredError } = await supabaseAdmin
              .from("daily_digest_deliveries")
              .select("id")
              .eq("user_id", profile.id)
              .eq("digest_date", digestDate)
              .maybeSingle();
            if (deliveredError) throw deliveredError;
            if (delivered) continue;

            const { data: reminders, error: remindersError } = await supabaseAdmin
              .from("reminders")
              .select("title,starts_at,ends_at,details")
              .eq("user_id", profile.id)
              .gte("starts_at", now.toISOString())
              .lt("starts_at", horizon)
              .order("starts_at", { ascending: true })
              .limit(30);
            if (remindersError) throw remindersError;

            const { data: tasks, error: tasksError } = await supabaseAdmin
              .from("tasks")
              .select("description")
              .eq("user_id", profile.id)
              .eq("status", "pendente")
              .order("created_at", { ascending: true })
              .limit(50);
            if (tasksError) throw tasksError;

            const summary = await callAnthropic({
              userId: profile.id,
              origin: "boletim_diario",
              model: ANTHROPIC_MODELS.haiku,
              maxTokens: 600,
              system:
                `Agora em ${TIME_ZONE} é ${formatCurrentDateTime()}. Gere apenas o corpo de um boletim curto em pt-BR, sem saudação nem data de hoje no início. ` +
                "Crie duas seções: Compromissos dos próximos 7 dias e Tarefas pendentes. Liste cada compromisso com data e horário de início no fuso America/Sao_Paulo e cada tarefa pendente por descrição. Se uma seção estiver vazia, diga que não há itens. Nunca use asteriscos, nem para destaque ou listas; organize a mensagem apenas com emojis e texto simples. Não invente dados.",
              messages: [{ role: "user", content: JSON.stringify({ reminders: reminders ?? [], tasks: tasks ?? [] }) }],
            });
            await sendTelegramMessage(profile.telegram_chat_id, `Bom dia, Sr. Gandra!\n${formatCurrentDateTime()}\n\n${summary}`);
            const { error: deliveryError } = await supabaseAdmin.from("daily_digest_deliveries").insert({
              user_id: profile.id,
              digest_date: digestDate,
            });
            if (deliveryError) throw deliveryError;
            sent += 1;
          }

          await supabaseAdmin.from("scheduled_job_state").update({
            status: "ready",
            lease_expires_at: null,
            consecutive_rate_limits: 0,
            last_completed_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          }).eq("job_name", JOB_NAME);
          return Response.json({ ok: true, sent });
        } catch (error) {
          const status = error instanceof AnthropicRequestError ? error.status : 0;
          const { data: failedState } = await supabaseAdmin
            .from("scheduled_job_state")
            .select("consecutive_rate_limits")
            .eq("job_name", JOB_NAME)
            .maybeSingle();
          const rateLimits = status === 429 ? (failedState?.consecutive_rate_limits ?? 0) + 1 : 0;
          const blocked = status === 402 || status === 403 || (status === 429 && rateLimits >= 3);
          await supabaseAdmin.from("scheduled_job_state").update({
            status: blocked ? "paused" : "ready",
            lease_expires_at: null,
            consecutive_rate_limits: rateLimits,
            paused_reason: blocked && error instanceof AnthropicRequestError ? error.safeMessage : null,
            updated_at: new Date().toISOString(),
          }).eq("job_name", JOB_NAME);
          throw error;
        }
      },
    },
  },
});