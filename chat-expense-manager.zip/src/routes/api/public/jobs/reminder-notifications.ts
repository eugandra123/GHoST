import { createFileRoute } from "@tanstack/react-router";

import { authenticateCronRequest } from "@/integrations/supabase/cron-auth";
import { sendTelegramMessage } from "@/lib/telegram.server";

const BATCH_SIZE = 20;
const LEASE_MINUTES = 10;

async function authenticateScheduledRequest(request: Request) {
  const provided = request.headers.get("apikey") ?? "";
  if (provided) {
    const expected = process.env["REMINDER_JOB_API_KEY"] ?? "";
    if (expected && provided.length === expected.length) {
      let difference = 0;
      for (let index = 0; index < provided.length; index += 1) {
        difference |= provided.charCodeAt(index) ^ expected.charCodeAt(index);
      }
      if (difference === 0) return null;
    }
  }

  return authenticateCronRequest(request);
}

function formatReminderTime(startsAt: string) {
  return new Date(startsAt).toLocaleTimeString("pt-BR", {
    timeZone: "America/Sao_Paulo",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export const Route = createFileRoute("/api/public/jobs/reminder-notifications")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const authError = await authenticateScheduledRequest(request);
        if (authError) return authError;

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const { data, error } = await supabaseAdmin.rpc("claim_due_reminder_notifications", {
          _limit: BATCH_SIZE,
          _lease_minutes: LEASE_MINUTES,
        });
        if (error) {
          console.error("Erro ao reservar avisos da Agenda:", error);
          return Response.json({ error: "Não foi possível buscar os avisos." }, { status: 500 });
        }

        let sent = 0;
        let failed = 0;
        for (const reminder of data ?? []) {
          try {
            const time = formatReminderTime(reminder.starts_at);
            await sendTelegramMessage(
              reminder.telegram_chat_id,
              `Lembrete: ${reminder.title} começa às ${time}.`,
            );
            const { error: markError } = await supabaseAdmin
              .from("reminders")
              .update({ notification_sent_at: new Date().toISOString() })
              .eq("id", reminder.id)
              .is("notification_sent_at", null);
            if (markError) throw markError;
            sent += 1;
          } catch (sendError) {
            failed += 1;
            console.error(`Erro ao enviar aviso do compromisso ${reminder.id}:`, sendError);
            const { error: releaseError } = await supabaseAdmin
              .from("reminders")
              .update({ notification_claimed_at: null })
              .eq("id", reminder.id)
              .is("notification_sent_at", null);
            if (releaseError) {
              console.error(`Erro ao liberar compromisso ${reminder.id}:`, releaseError);
            }
          }
        }

        return Response.json({ ok: true, claimed: data?.length ?? 0, sent, failed });
      },
    },
  },
});