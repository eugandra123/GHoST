import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";

import { DEFAULT_CATEGORIES, formatBRL } from "@/lib/categories";
import { extractExpensesFromImageBytes, extractFromText } from "@/lib/expense-extraction.server";
import {
  deriveTelegramWebhookSecret,
  downloadTelegramFile,
  sendTelegramMessage,
  timingSafeEqualStr,
} from "@/lib/telegram.server";
import {
  answerTelegramAssistant,
  classifyMessageIntent,
  createTelegramReminder,
  handlePendingDataConfirmation,
  handlePendingExpenseConfirmation,
  handlePendingReminderLeadTime,
} from "@/lib/telegram-assistant.server";
import { saveTriggeredParameter } from "@/lib/user-parameters.server";

const telegramUpdateSchema = z.object({
  update_id: z.number().int(),
  message: z
    .object({
      message_id: z.number().int(),
      chat: z.object({ id: z.number().int() }),
      from: z.object({ username: z.string().optional() }).optional(),
      text: z.string().optional(),
      caption: z.string().optional(),
      photo: z.array(z.object({ file_id: z.string() })).optional(),
      document: z.object({ file_id: z.string(), mime_type: z.string().optional() }).optional(),
    })
    .optional(),
  edited_message: z
    .object({
      message_id: z.number().int(),
      chat: z.object({ id: z.number().int() }),
      from: z.object({ username: z.string().optional() }).optional(),
      text: z.string().optional(),
      caption: z.string().optional(),
      photo: z.array(z.object({ file_id: z.string() })).optional(),
      document: z.object({ file_id: z.string(), mime_type: z.string().optional() }).optional(),
    })
    .optional(),
});

const HELP =
  "Oi! Eu sou o GHoST, seu assistente pessoal no Telegram.\n\n" +
  "• Mande um texto como “gastei 50 reais no mercado”.\n" +
  "• Ou mande o print da compra (Apple Wallet, recibo, fatura).\n" +
  "• Peça para eu agendar um compromisso informando quando ele acontecerá.\n\n" +
  "Também posso responder perguntas gerais, consultar seus gastos e ajudar a corrigir ou excluir um lançamento com sua confirmação. Termine uma informação com * para salvá-la como parâmetro.\n\n" +
  "Para vincular sua conta, abra os Ajustes do app e envie aqui o código que aparece lá.";

async function reply(chatId: number, text: string) {
  try {
    await sendTelegramMessage(chatId, text);
  } catch (error) {
    console.error("Erro ao responder no Telegram:", error);
  }
}

function normalizeMerchant(value: string) {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .toLocaleLowerCase("pt-BR");
}

function saoPauloDayBounds(iso: string) {
  const day = new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/Sao_Paulo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date(iso));
  const start = new Date(`${day}T00:00:00-03:00`);
  const end = new Date(start.getTime() + 24 * 60 * 60 * 1000);
  return { start: start.toISOString(), end: end.toISOString() };
}

export const Route = createFileRoute("/api/public/telegram/webhook")({
  server: {
    handlers: {
      GET: async () => Response.json({ status: "ready" }),
      POST: async ({ request }) => {
        const telegramKey = process.env["TELEGRAM_API_KEY"];
        if (!telegramKey) {
          return Response.json({ error: "telegram não configurado" }, { status: 503 });
        }

        const expected = await deriveTelegramWebhookSecret(telegramKey);
        const provided = request.headers.get("x-telegram-bot-api-secret-token") ?? "";
        if (!timingSafeEqualStr(provided, expected)) {
          return new Response("Unauthorized", { status: 401 });
        }

        let rawUpdate: unknown;
        try {
          rawUpdate = await request.json();
        } catch {
          return Response.json({ error: "json inválido" }, { status: 400 });
        }

        const parsedUpdate = telegramUpdateSchema.safeParse(rawUpdate);
        if (!parsedUpdate.success) {
          return Response.json({ error: "atualização inválida" }, { status: 400 });
        }
        const update = parsedUpdate.data;
        const message = update.message ?? update.edited_message;
        const chatId = message?.chat?.id;
        if (!message || !chatId) return Response.json({ ok: true, ignored: true });

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

        const photo = message.photo?.at(-1)
          ? message.photo.at(-1)
          : message.document?.mime_type?.startsWith("image/")
            ? { file_id: message.document.file_id }
            : null;
        const text = message.text ?? message.caption ?? null;
        const kind: "text" | "image" | "unsupported" = photo ? "image" : text ? "text" : "unsupported";

        // Identifica o dono do chat
        const { data: byChat } = await supabaseAdmin
          .from("profiles")
          .select("id")
          .eq("telegram_chat_id", chatId)
          .maybeSingle();
        let userId: string | null = byChat?.id ?? null;

        // Vinculação por código enviado no chat
        const code = text
          ?.trim()
          .toUpperCase()
          .replace(/^\/START\s+/, "");
        if (!userId && code && /^[A-Z0-9]{8}$/.test(code)) {
          const { data: byCode } = await supabaseAdmin
            .from("profiles")
            .select("id")
            .eq("telegram_link_code", code)
            .maybeSingle();
          if (byCode?.id) {
            await supabaseAdmin
              .from("profiles")
              .update({
                telegram_chat_id: chatId,
                telegram_username: message.from?.username ?? null,
                telegram_link_code: null,
              })
              .eq("id", byCode.id);
            await reply(chatId, "Conta vinculada! Agora é só mandar o gasto por texto ou print.");
            return Response.json({ ok: true, linked: true });
          }
        }

        const logBase = {
          user_id: userId,
          channel: "telegram",
          external_id: String(update.update_id),
          phone: String(chatId),
          kind,
          body: text,
          media_url: null as string | null,
          payload: update as never,
        };

        if (!userId) {
          await supabaseAdmin.from("whatsapp_messages").upsert(
            { ...logBase, status: "ignored", error: "chat não vinculado" },
            {
              onConflict: "channel,external_id",
            },
          );
          await reply(
            chatId,
            "Ainda não sei de quem é esse chat. Abra os Ajustes do app e me envie o código de vinculação.",
          );
          return Response.json({ ok: true, ignored: true });
        }

        if (text && /^\/(start|help|ajuda)\b/i.test(text.trim())) {
          await reply(chatId, HELP);
          return Response.json({ ok: true, help: true });
        }

        if (kind === "unsupported") {
          await supabaseAdmin.from("whatsapp_messages").upsert(
            { ...logBase, status: "ignored", error: "tipo não suportado" },
            {
              onConflict: "channel,external_id",
            },
          );
          await reply(chatId, "Só entendo texto ou imagem por enquanto.");
          return Response.json({ ok: true, ignored: true });
        }

        const { error: reservationError } = await supabaseAdmin
          .from("whatsapp_messages")
          .insert({ ...logBase, status: "processing", error: null });
        if (reservationError?.code === "23505") {
          return Response.json({ ok: true, duplicate: true });
        }
        if (reservationError) {
          console.error("Erro ao reservar atualização do Telegram:", reservationError);
          return Response.json({ ok: true, error: "log_error" });
        }

        const { data: cats } = await supabaseAdmin.from("categories").select("name").eq("user_id", userId);
        const categories = cats?.length ? cats.map((c) => c.name) : [...DEFAULT_CATEGORIES];

        try {
          if (photo) {
            const file = await downloadTelegramFile(photo.file_id);
            const extractedItems = file
              ? await extractExpensesFromImageBytes(file.bytes, file.mediaType, categories, userId, text ?? undefined)
              : [];

            if (extractedItems.length === 0) {
              await supabaseAdmin
                .from("whatsapp_messages")
                .update({ status: "failed", error: "não foi possível extrair o gasto" })
                .eq("channel", "telegram")
                .eq("external_id", logBase.external_id);
              await reply(chatId, "Não consegui identificar gastos na imagem. Pode reenviar um print mais nítido?");
              return Response.json({ ok: false, reason: "extraction_failed" });
            }

            const now = new Date().toISOString();
            const newExpenses: Array<{
              user_id: string;
              merchant: string;
              amount: number;
              category: string;
              city: string | null;
              occurred_at: string;
              source: string;
              raw_input: string | null;
            }> = [];
            const seenInImage = new Set<string>();
            let duplicateCount = 0;

            for (const item of extractedItems) {
              const occurredAt = item.occurred_at ?? now;
              const { start, end } = saoPauloDayBounds(occurredAt);
              const dedupeKey = `${normalizeMerchant(item.merchant)}|${item.amount.toFixed(2)}|${start}`;
              if (seenInImage.has(dedupeKey)) {
                duplicateCount += 1;
                continue;
              }
              seenInImage.add(dedupeKey);

              const { data: possibleDuplicates, error: duplicateLookupError } = await supabaseAdmin
                .from("expenses")
                .select("merchant,amount")
                .eq("user_id", userId)
                .gte("occurred_at", start)
                .lt("occurred_at", end);
              if (duplicateLookupError) throw duplicateLookupError;

              const duplicate = possibleDuplicates?.some(
                (candidate) =>
                  normalizeMerchant(candidate.merchant) === normalizeMerchant(item.merchant) &&
                  Math.round(Number(candidate.amount) * 100) === Math.round(item.amount * 100),
              );
              if (duplicate) {
                duplicateCount += 1;
                continue;
              }

              newExpenses.push({
                user_id: userId,
                merchant: item.merchant,
                amount: item.amount,
                category: item.category,
                city: item.city,
                occurred_at: occurredAt,
                source: "image",
                raw_input: text,
              });
            }

            if (newExpenses.length === 0) {
              await supabaseAdmin
                .from("whatsapp_messages")
                .update({ status: "processed", error: null })
                .eq("channel", "telegram")
                .eq("external_id", logBase.external_id);
              await reply(
                chatId,
                `Nenhum gasto novo foi registrado: ${duplicateCount} ${duplicateCount === 1 ? "item já existia" : "itens já existiam"}.`,
              );
              return Response.json({ ok: true, expense_ids: [], skipped_duplicates: duplicateCount });
            }

            const { data: insertedExpenses, error: insertError } = await supabaseAdmin
              .from("expenses")
              .insert(newExpenses)
              .select("id,merchant,amount");
            if (insertError) throw insertError;

            await supabaseAdmin
              .from("whatsapp_messages")
              .update({ status: "processed", expense_id: insertedExpenses[0]?.id ?? null, error: null })
              .eq("channel", "telegram")
              .eq("external_id", logBase.external_id);

            const summary = insertedExpenses
              .map((expense) => `${expense.merchant} - ${formatBRL(Number(expense.amount))}`)
              .join(", ");
            const duplicateNote = duplicateCount
              ? ` ${duplicateCount} ${duplicateCount === 1 ? "duplicado foi ignorado" : "duplicados foram ignorados"}.`
              : "";
            await reply(
              chatId,
              `${insertedExpenses.length === 1 ? "Registrado 1 gasto" : `Registrados ${insertedExpenses.length} gastos`}: ${summary}.${duplicateNote}`,
            );

            return Response.json({
              ok: true,
              expense_ids: insertedExpenses.map((expense) => expense.id),
              skipped_duplicates: duplicateCount,
            });
          }

          const messageText = text ?? "";
          if (/\*\s*$/.test(messageText)) {
            const content = messageText.replace(/\*\s*$/, "").trim();
            const parameter = await saveTriggeredParameter(userId, content);
            await supabaseAdmin
              .from("whatsapp_messages")
              .update({ status: "processed", expense_id: null, error: null })
              .eq("channel", "telegram")
              .eq("external_id", logBase.external_id);
            const confirmation = `Salvo: ${parameter.key} = ${parameter.value}`;
            await reply(chatId, confirmation);
            return Response.json({ ok: true, parameter: true });
          }
          const pendingReminderAnswer = await handlePendingReminderLeadTime(userId, messageText);
          if (pendingReminderAnswer) {
            await supabaseAdmin
              .from("whatsapp_messages")
              .update({ status: "processed", expense_id: null, error: null })
              .eq("channel", "telegram")
              .eq("external_id", logBase.external_id);
            await reply(chatId, pendingReminderAnswer);
            return Response.json({ ok: true, reminder: true });
          }
          const pendingDataAnswer = await handlePendingDataConfirmation(userId, messageText);
          if (pendingDataAnswer) {
            await supabaseAdmin
              .from("whatsapp_messages")
              .update({ status: "processed", expense_id: null, error: null })
              .eq("channel", "telegram")
              .eq("external_id", logBase.external_id);
            await reply(chatId, pendingDataAnswer.message);
            return Response.json({ ok: true, data_action: true });
          }
          const pendingAnswer = await handlePendingExpenseConfirmation(userId, messageText);
          if (pendingAnswer) {
            await supabaseAdmin
              .from("whatsapp_messages")
              .update({ status: "processed", expense_id: null, error: null })
              .eq("channel", "telegram")
              .eq("external_id", logBase.external_id);
            await reply(chatId, pendingAnswer);
            return Response.json({ ok: true, expense_action: true });
          }

          const intent = await classifyMessageIntent(userId, messageText);
          if (intent === "lembrete") {
            const answer = await createTelegramReminder(userId, messageText);
            await supabaseAdmin
              .from("whatsapp_messages")
              .update({ status: "processed", expense_id: null, error: null })
              .eq("channel", "telegram")
              .eq("external_id", logBase.external_id);
            await reply(chatId, answer);
            return Response.json({ ok: true, reminder: true });
          }
          if (intent === "tarefa" || intent === "chat") {
            const answer = await answerTelegramAssistant(userId, messageText);
            await supabaseAdmin
              .from("whatsapp_messages")
              .update({ status: "processed", expense_id: null, error: null })
              .eq("channel", "telegram")
              .eq("external_id", logBase.external_id);
            await reply(chatId, answer);
            return Response.json({ ok: true, assistant: true });
          }

          const extracted = await extractFromText(messageText, categories, userId);

          if (!extracted || !extracted.amount) {
            await supabaseAdmin
              .from("whatsapp_messages")
              .update({ status: "failed", error: "não foi possível extrair o gasto" })
              .eq("channel", "telegram")
              .eq("external_id", logBase.external_id);
            await reply(chatId, "Não consegui identificar esse gasto. Pode informar o valor e o estabelecimento?");
            return Response.json({ ok: false, reason: "extraction_failed" });
          }

          const { data: expense, error } = await supabaseAdmin
            .from("expenses")
            .insert({
              user_id: userId,
              merchant: extracted.merchant,
              amount: extracted.amount,
              category: extracted.category,
              city: extracted.city,
              occurred_at: extracted.occurred_at ?? new Date().toISOString(),
              source: photo ? "image" : "text",
              raw_input: text,
            })
            .select("id")
            .single();

          if (error) throw error;

          await supabaseAdmin
            .from("whatsapp_messages")
            .update({ status: "processed", expense_id: expense.id, error: null })
            .eq("channel", "telegram")
            .eq("external_id", logBase.external_id);

          await reply(
            chatId,
            `Registrado: ${extracted.merchant} - ${formatBRL(extracted.amount)} - ${extracted.category}`,
          );

          return Response.json({ ok: true, expense_id: expense.id });
        } catch (err) {
          console.error("Erro no webhook do Telegram:", err);
          await supabaseAdmin
            .from("whatsapp_messages")
            .update({
              status: "failed",
              error: err instanceof Error ? err.message : "erro desconhecido",
            })
            .eq("channel", "telegram")
            .eq("external_id", logBase.external_id);
          await reply(chatId, "Tive um problema ao processar sua mensagem. Pode tentar de novo?");
          return Response.json({ ok: true, error: "processing_error" });
        }
      },
    },
  },
});
