import { createFileRoute } from "@tanstack/react-router";

import { DEFAULT_CATEGORIES, formatBRL } from "@/lib/categories";
import { extractFromImage, extractFromText } from "@/lib/expense-extraction.server";
import { sendWhatsAppMessage } from "@/lib/whatsapp.server";

type Parsed = {
  phone: string | null;
  kind: "text" | "image" | "unsupported";
  text: string | null;
  mediaUrl: string | null;
  fromMe: boolean;
};

function onlyDigits(value: string) {
  return value.replace(/\D/g, "");
}

/** Normaliza payloads da Z-API e da Whapi.Cloud num formato único. */
function parsePayload(payload: Record<string, any>): Parsed {
  // Whapi.Cloud
  if (Array.isArray(payload["messages"]) && payload["messages"].length > 0) {
    const m = payload["messages"][0] ?? {};
    const image = m.image ?? m.document ?? null;
    return {
      phone: m.from ? onlyDigits(String(m.from)) : null,
      kind: image ? "image" : m.text?.body ? "text" : "unsupported",
      text: m.text?.body ?? image?.caption ?? null,
      mediaUrl: image?.link ?? image?.url ?? null,
      fromMe: Boolean(m.from_me),
    };
  }

  // Z-API
  const image = payload["image"] ?? null;
  const text = payload["text"]?.message ?? payload["message"] ?? null;
  return {
    phone: payload["phone"] ? onlyDigits(String(payload["phone"])) : null,
    kind: image ? "image" : text ? "text" : "unsupported",
    text: text ?? image?.caption ?? null,
    mediaUrl: image?.imageUrl ?? image?.url ?? null,
    fromMe: Boolean(payload["fromMe"]),
  };
}

async function handle(request: Request) {
  const secret = process.env["WHATSAPP_WEBHOOK_SECRET"];
  if (secret) {
    const url = new URL(request.url);
    const provided = request.headers.get("x-webhook-secret") ?? url.searchParams.get("secret");
    if (provided !== secret) {
      return Response.json({ error: "unauthorized" }, { status: 401 });
    }
  }

  let payload: Record<string, any> = {};
  try {
    payload = (await request.json()) as Record<string, any>;
  } catch {
    return Response.json({ error: "invalid json" }, { status: 400 });
  }

  const parsed = parsePayload(payload);
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

  if (parsed.fromMe) return Response.json({ ignored: "fromMe" });

  // Descobre a quem pertence o número. Se houver apenas um usuário no app,
  // usa esse usuário como destino padrão.
  let userId: string | null = null;
  if (parsed.phone) {
    const { data } = await supabaseAdmin
      .from("profiles")
      .select("id, whatsapp_phone")
      .not("whatsapp_phone", "is", null);
    const match = (data ?? []).find(
      (p) => p.whatsapp_phone && onlyDigits(p.whatsapp_phone).endsWith(onlyDigits(parsed.phone!).slice(-8)),
    );
    userId = match?.id ?? null;
  }
  if (!userId) {
    const { data } = await supabaseAdmin.from("profiles").select("id").limit(2);
    if (data && data.length === 1) userId = data[0]!.id;
  }

  const logBase = {
    user_id: userId,
    phone: parsed.phone,
    kind: parsed.kind,
    body: parsed.text,
    media_url: parsed.mediaUrl,
    payload: payload as never,
  };

  if (!userId || parsed.kind === "unsupported") {
    await supabaseAdmin.from("whatsapp_messages").insert({
      ...logBase,
      status: "ignored",
      error: userId ? "tipo de mensagem não suportado" : "número não vinculado a um usuário",
    });
    return Response.json({ ok: true, ignored: true });
  }

  const { data: cats } = await supabaseAdmin
    .from("categories")
    .select("name")
    .eq("user_id", userId);
  const categories = cats?.length ? cats.map((c) => c.name) : [...DEFAULT_CATEGORIES];

  try {
    const extracted =
      parsed.kind === "image" && parsed.mediaUrl
        ? await extractFromImage(parsed.mediaUrl, categories, userId, parsed.text ?? undefined)
        : await extractFromText(parsed.text ?? "", categories, userId);

    if (!extracted) {
      await supabaseAdmin.from("whatsapp_messages").insert({
        ...logBase,
        status: "failed",
        error: "não foi possível extrair o gasto",
      });
      if (parsed.phone) {
        await sendWhatsAppMessage(
          parsed.phone,
          "Não consegui identificar o gasto nessa mensagem. Pode reenviar com o valor e o estabelecimento?",
        );
      }
      return Response.json({ ok: false, reason: "extraction_failed" });
    }

    const { data: expense, error } = await supabaseAdmin
      .from("expenses")
      .insert({
        user_id: userId,
        merchant: extracted.merchant,
        amount: extracted.amount,
        category: extracted.category,
        city: extracted.city,
        occurred_at: extracted.occurred_at ?? new Date().toISOString(),
        source: parsed.kind === "image" ? "image" : "text",
        raw_input: parsed.text ?? parsed.mediaUrl,
      })
      .select("id")
      .single();

    if (error) throw error;

    await supabaseAdmin.from("whatsapp_messages").insert({
      ...logBase,
      status: "processed",
      expense_id: expense.id,
    });

    if (parsed.phone) {
      await sendWhatsAppMessage(
        parsed.phone,
        `Registrado: ${extracted.merchant} - ${formatBRL(extracted.amount)} - ${extracted.category}`,
      );
    }

    return Response.json({ ok: true, expense_id: expense.id });
  } catch (err) {
    console.error("Erro no webhook do WhatsApp:", err);
    await supabaseAdmin.from("whatsapp_messages").insert({
      ...logBase,
      status: "failed",
      error: err instanceof Error ? err.message : "erro desconhecido",
    });
    return Response.json({ ok: false, error: "processing_error" }, { status: 500 });
  }
}

export const Route = createFileRoute("/api/public/whatsapp/webhook")({
  server: {
    handlers: {
      GET: async () => Response.json({ status: "ready" }),
      POST: async ({ request }) => handle(request),
    },
  },
});
