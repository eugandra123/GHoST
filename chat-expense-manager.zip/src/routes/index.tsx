import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";

import { Button } from "@/components/ui/button";
import { JrvsMark } from "@/components/jrvs-mark";
import { supabase } from "@/integrations/supabase/client";
import openingMark from "@/assets/ghost-ring-thick-reference.png";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "GHoST — seu assistente pessoal" },
      {
        name: "description",
        content:
          "GHoST é seu assistente pessoal de IA para organizar sua rotina, informações e finanças.",
      },
      { property: "og:title", content: "GHoST — seu assistente pessoal" },
      {
        property: "og:description",
        content: "Uma experiência pessoal de IA simples, conectada e feita para você.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Landing,
});

function Landing() {
  const navigate = useNavigate();
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    let active = true;
    supabase.auth.getSession().then(({ data }) => {
      if (!active) return;
      if (data.session) navigate({ to: "/inicio" });
      else setChecking(false);
    });
    return () => {
      active = false;
    };
  }, [navigate]);

  if (checking) {
    return (
      <div className="app-screen flex min-h-screen items-center justify-center bg-background">
        <div className="app-opening-enter flex flex-col items-center gap-6" role="status" aria-label="Abrindo GHoST">
          <img src={openingMark} alt="" aria-hidden="true" className="h-36 w-36 object-contain" />
          <span className="font-display text-xl font-medium text-foreground">GHoST</span>
        </div>
      </div>
    );
  }

  return (
    <main className="app-screen flex min-h-screen items-center justify-center bg-background px-6 py-16">
      <div className="jrvs-home-enter flex flex-col items-center text-center">
        <JrvsMark className="h-28 w-28 sm:h-32 sm:w-32" />
        <h1 className="mt-8 font-display text-4xl font-medium tracking-[0.28em] text-foreground sm:text-5xl">
          GHoST
        </h1>
        <p className="mt-3 text-xs tracking-[0.18em] text-muted-foreground">seu assistente pessoal</p>
        <Button variant="ghost" className="mt-12 text-muted-foreground hover:text-foreground" onClick={() => navigate({ to: "/auth" })}>
          Entrar
        </Button>
      </div>
    </main>
  );
}
