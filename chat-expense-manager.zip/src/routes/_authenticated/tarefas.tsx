import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { CheckCircle2, Circle, ListTodo, Pencil, Plus, Save, Trash2, X } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/tarefas")({
  head: () => ({
    meta: [
      { title: "Tarefas — GHoST" },
      { name: "description", content: "Organize e acompanhe suas tarefas simples no GHoST." },
      { property: "og:title", content: "Tarefas — GHoST" },
      { property: "og:description", content: "Sua lista de tarefas simples no GHoST." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: TasksPage,
});

type Task = {
  id: string;
  description: string;
  status: "pendente" | "concluída";
  created_at: string;
};

function TasksPage() {
  const queryClient = useQueryClient();
  const [newDescription, setNewDescription] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingDescription, setEditingDescription] = useState("");
  const [deleting, setDeleting] = useState<Task | null>(null);

  const tasksQuery = useQuery({
    queryKey: ["tasks"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("tasks")
        .select("id,description,status,created_at")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as Task[];
    },
  });

  const refreshTasks = () => queryClient.invalidateQueries({ queryKey: ["tasks"] });

  const addTask = useMutation({
    mutationFn: async () => {
      const description = newDescription.trim();
      if (!description) throw new Error("Descreva a tarefa.");
      const { data } = await supabase.auth.getUser();
      if (!data.user) throw new Error("Sessão expirada.");
      const { error } = await supabase.from("tasks").insert({
        user_id: data.user.id,
        description,
        status: "pendente",
      });
      if (error) throw error;
    },
    onSuccess: () => {
      setNewDescription("");
      void refreshTasks();
      toast.success("Tarefa adicionada.");
    },
    onError: (error) => toast.error(error instanceof Error ? error.message : "Não foi possível adicionar."),
  });

  const updateTask = useMutation({
    mutationFn: async ({ id, values }: { id: string; values: Partial<Pick<Task, "description" | "status">> }) => {
      if (values.description !== undefined && !values.description.trim()) throw new Error("Descreva a tarefa.");
      const payload = values.description === undefined ? values : { ...values, description: values.description.trim() };
      const { error } = await supabase.from("tasks").update(payload).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      setEditingId(null);
      void refreshTasks();
      toast.success("Tarefa atualizada.");
    },
    onError: (error) => toast.error(error instanceof Error ? error.message : "Não foi possível atualizar."),
  });

  const deleteTask = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("tasks").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      setDeleting(null);
      void refreshTasks();
      toast.success("Tarefa excluída.");
    },
    onError: () => toast.error("Não foi possível excluir a tarefa."),
  });

  const pending = tasksQuery.data?.filter((task) => task.status === "pendente") ?? [];
  const completed = tasksQuery.data?.filter((task) => task.status === "concluída") ?? [];

  return (
    <div className="space-y-8">
      <div>
        <p className="mb-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-primary">Organização</p>
        <h1 className="text-3xl font-semibold">Tarefas</h1>
        <p className="mt-1 text-sm text-muted-foreground">Itens simples sem data ou horário.</p>
      </div>

      <form
        className="panel flex flex-col gap-3 p-5 sm:flex-row"
        onSubmit={(event) => {
          event.preventDefault();
          addTask.mutate();
        }}
      >
        <Input
          aria-label="Nova tarefa"
          value={newDescription}
          maxLength={500}
          onChange={(event) => setNewDescription(event.target.value)}
          placeholder="O que precisa ser feito?"
        />
        <Button type="submit" disabled={addTask.isPending} className="shrink-0">
          <Plus className="h-4 w-4" /> Adicionar
        </Button>
      </form>

      <section className="space-y-3">
        {tasksQuery.isLoading ? (
          <p className="text-sm text-muted-foreground">Carregando tarefas…</p>
        ) : tasksQuery.isError ? (
          <div className="panel p-6 text-sm text-destructive">Não foi possível carregar as tarefas.</div>
        ) : tasksQuery.data?.length ? (
          <>
            {[...pending, ...completed].map((task) => {
              const isEditing = editingId === task.id;
              const isComplete = task.status === "concluída";
              return (
                <article key={task.id} className="panel flex min-h-16 items-center gap-3 p-4">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="shrink-0"
                    title={isComplete ? "Marcar como pendente" : "Marcar como concluída"}
                    aria-label={isComplete ? `Reabrir ${task.description}` : `Concluir ${task.description}`}
                    onClick={() => updateTask.mutate({ id: task.id, values: { status: isComplete ? "pendente" : "concluída" } })}
                  >
                    {isComplete ? <CheckCircle2 className="h-5 w-5 text-primary" /> : <Circle className="h-5 w-5 text-muted-foreground" />}
                  </Button>

                  <div className="min-w-0 flex-1">
                    {isEditing ? (
                      <Input
                        aria-label={`Editar ${task.description}`}
                        value={editingDescription}
                        maxLength={500}
                        onChange={(event) => setEditingDescription(event.target.value)}
                        onKeyDown={(event) => {
                          if (event.key === "Enter") updateTask.mutate({ id: task.id, values: { description: editingDescription } });
                          if (event.key === "Escape") setEditingId(null);
                        }}
                      />
                    ) : (
                      <>
                        <p className={isComplete ? "break-words text-muted-foreground line-through" : "break-words font-medium"}>{task.description}</p>
                        <p className="mt-1 text-xs text-muted-foreground">
                          Criada em {new Date(task.created_at).toLocaleDateString("pt-BR", { timeZone: "America/Sao_Paulo" })}
                        </p>
                      </>
                    )}
                  </div>

                  <div className="flex shrink-0 gap-1">
                    {isEditing ? (
                      <>
                        <Button variant="ghost" size="icon" aria-label="Salvar edição" onClick={() => updateTask.mutate({ id: task.id, values: { description: editingDescription } })}>
                          <Save className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" aria-label="Cancelar edição" onClick={() => setEditingId(null)}>
                          <X className="h-4 w-4" />
                        </Button>
                      </>
                    ) : (
                      <Button
                        variant="ghost"
                        size="icon"
                        title="Editar tarefa"
                        aria-label={`Editar ${task.description}`}
                        onClick={() => {
                          setEditingId(task.id);
                          setEditingDescription(task.description);
                        }}
                      >
                        <Pencil className="h-4 w-4" />
                      </Button>
                    )}
                    <Button variant="ghost" size="icon" title="Excluir tarefa" aria-label={`Excluir ${task.description}`} onClick={() => setDeleting(task)}>
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </article>
              );
            })}
          </>
        ) : (
          <div className="panel flex min-h-44 flex-col items-center justify-center p-6 text-center">
            <ListTodo className="mb-3 h-7 w-7 text-primary" />
            <p className="font-medium">Nenhuma tarefa por aqui.</p>
            <p className="mt-1 text-sm text-muted-foreground">Adicione uma tarefa ou peça ao GHoST no Telegram.</p>
          </div>
        )}
      </section>

      <AlertDialog open={Boolean(deleting)} onOpenChange={(open) => !open && setDeleting(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir tarefa?</AlertDialogTitle>
            <AlertDialogDescription>
              {deleting ? `“${deleting.description}” será removida da sua lista.` : "Esta ação não pode ser desfeita."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => deleting && deleteTask.mutate(deleting.id)}
            >
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}