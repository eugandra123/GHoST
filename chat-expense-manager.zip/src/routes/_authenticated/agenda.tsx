import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { CalendarDays, Clock3, Pencil, Plus, Trash2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/agenda")({
  head: () => ({
    meta: [
      { title: "Agenda — GHoST" },
      { name: "description", content: "Consulte e gerencie seus compromissos no GHoST." },
      { property: "og:title", content: "Agenda — GHoST" },
      { property: "og:description", content: "Seus compromissos organizados por data e hora." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AgendaPage,
});

type Reminder = {
  id: string;
  title: string;
  starts_at: string;
  ends_at: string;
  details: string | null;
  aviso_antecedencia_minutos: number;
};

type ReminderDraft = Omit<Reminder, "id">;

function saoPauloInputValue(value: string) {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/Sao_Paulo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  }).formatToParts(new Date(value));
  const part = (type: Intl.DateTimeFormatPartTypes) => parts.find((item) => item.type === type)?.value ?? "";
  return `${part("year")}-${part("month")}-${part("day")}T${part("hour")}:${part("minute")}`;
}

function toIso(value: string) {
  return new Date(`${value}:00-03:00`).toISOString();
}

function defaultDraft(): ReminderDraft {
  const start = new Date(Date.now() + 60 * 60 * 1000);
  start.setMinutes(Math.ceil(start.getMinutes() / 30) * 30, 0, 0);
  const end = new Date(start.getTime() + 30 * 60 * 1000);
  return { title: "", starts_at: start.toISOString(), ends_at: end.toISOString(), details: "", aviso_antecedencia_minutos: 120 };
}

function AgendaPage() {
  const queryClient = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<Reminder | null>(null);
  const [deleting, setDeleting] = useState<Reminder | null>(null);

  const remindersQuery = useQuery({
    queryKey: ["reminders"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("reminders")
        .select("id,title,starts_at,ends_at,details,aviso_antecedencia_minutos")
        .order("starts_at", { ascending: true });
      if (error) throw error;
      return (data ?? []) as Reminder[];
    },
  });

  const saveReminder = useMutation({
    mutationFn: async (draft: ReminderDraft) => {
      if (editing) {
        const { error } = await supabase.from("reminders").update(draft).eq("id", editing.id);
        if (error) throw error;
        return;
      }
      const { data } = await supabase.auth.getUser();
      if (!data.user) throw new Error("Sessão expirada.");
      const { error } = await supabase.from("reminders").insert({ ...draft, user_id: data.user.id });
      if (error) throw error;
    },
    onSuccess: () => {
      setDialogOpen(false);
      setEditing(null);
      void queryClient.invalidateQueries({ queryKey: ["reminders"] });
      toast.success(editing ? "Compromisso atualizado." : "Compromisso adicionado.");
    },
    onError: (error) => toast.error(error instanceof Error ? error.message : "Não foi possível salvar."),
  });

  const deleteReminder = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("reminders").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      setDeleting(null);
      void queryClient.invalidateQueries({ queryKey: ["reminders"] });
      toast.success("Compromisso excluído.");
    },
    onError: () => toast.error("Não foi possível excluir o compromisso."),
  });

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="mb-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-primary">Organização</p>
          <h1 className="text-3xl font-semibold">Agenda</h1>
          <p className="mt-1 text-sm text-muted-foreground">Seus compromissos em ordem cronológica.</p>
        </div>
        <Button
          onClick={() => {
            setEditing(null);
            setDialogOpen(true);
          }}
        >
          <Plus className="h-4 w-4" /> Novo compromisso
        </Button>
      </div>

      <section className="space-y-3">
        {remindersQuery.isLoading ? (
          <p className="text-sm text-muted-foreground">Carregando agenda…</p>
        ) : remindersQuery.isError ? (
          <div className="panel p-6 text-sm text-destructive">Não foi possível carregar a agenda.</div>
        ) : remindersQuery.data?.length ? (
          remindersQuery.data.map((reminder) => {
            const start = new Date(reminder.starts_at);
            return (
              <article key={reminder.id} className="panel grid gap-4 p-5 sm:grid-cols-[5.5rem_minmax(0,1fr)_auto] sm:items-center">
                <div className="border-b border-border pb-3 sm:border-r sm:border-b-0 sm:pb-0 sm:pr-4">
                  <p className="font-display text-2xl font-semibold text-foreground">
                    {start.toLocaleDateString("pt-BR", { timeZone: "America/Sao_Paulo", day: "2-digit" })}
                  </p>
                  <p className="text-xs uppercase text-muted-foreground">
                    {start.toLocaleDateString("pt-BR", { timeZone: "America/Sao_Paulo", month: "short" }).replace(".", "")}
                  </p>
                </div>
                <div className="min-w-0">
                  <h2 className="truncate text-base font-semibold">{reminder.title}</h2>
                  <div className="mt-1 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-muted-foreground">
                    <span className="inline-flex items-center gap-1.5">
                      <CalendarDays className="h-4 w-4 text-primary" />
                      {start.toLocaleDateString("pt-BR", { timeZone: "America/Sao_Paulo", weekday: "long", year: "numeric" })}
                    </span>
                    <span className="inline-flex items-center gap-1.5">
                      <Clock3 className="h-4 w-4 text-primary" />
                      {start.toLocaleTimeString("pt-BR", { timeZone: "America/Sao_Paulo", hour: "2-digit", minute: "2-digit" })}
                    </span>
                  </div>
                  {reminder.details ? <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">{reminder.details}</p> : null}
                  <p className="mt-2 text-xs text-muted-foreground">Aviso {reminder.aviso_antecedencia_minutos} min antes</p>
                </div>
                <div className="flex gap-1 sm:justify-end">
                  <Button
                    variant="ghost"
                    size="icon"
                    title="Editar compromisso"
                    aria-label={`Editar ${reminder.title}`}
                    onClick={() => {
                      setEditing(reminder);
                      setDialogOpen(true);
                    }}
                  >
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    title="Excluir compromisso"
                    aria-label={`Excluir ${reminder.title}`}
                    onClick={() => setDeleting(reminder)}
                  >
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              </article>
            );
          })
        ) : (
          <div className="panel flex min-h-44 flex-col items-center justify-center p-6 text-center">
            <CalendarDays className="mb-3 h-7 w-7 text-primary" />
            <p className="font-medium">Sua agenda está livre.</p>
            <p className="mt-1 text-sm text-muted-foreground">Crie um compromisso aqui ou peça ao GHoST no Telegram.</p>
          </div>
        )}
      </section>

      <ReminderDialog
        key={`${editing?.id ?? "new"}-${dialogOpen}`}
        open={dialogOpen}
        reminder={editing}
        pending={saveReminder.isPending}
        onOpenChange={(open) => {
          setDialogOpen(open);
          if (!open) setEditing(null);
        }}
        onSave={(draft) => saveReminder.mutate(draft)}
      />

      <AlertDialog open={Boolean(deleting)} onOpenChange={(open) => !open && setDeleting(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir compromisso?</AlertDialogTitle>
            <AlertDialogDescription>
              {deleting ? `“${deleting.title}” será removido da sua agenda.` : "Esta ação não pode ser desfeita."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => deleting && deleteReminder.mutate(deleting.id)}
            >
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function ReminderDialog({
  open,
  reminder,
  pending,
  onOpenChange,
  onSave,
}: {
  open: boolean;
  reminder: Reminder | null;
  pending: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (draft: ReminderDraft) => void;
}) {
  const initial = reminder ?? defaultDraft();
  const [title, setTitle] = useState(initial.title);
  const [startsAt, setStartsAt] = useState(saoPauloInputValue(initial.starts_at));
  const [endsAt, setEndsAt] = useState(saoPauloInputValue(initial.ends_at));
  const [details, setDetails] = useState(initial.details ?? "");
  const [leadMinutes, setLeadMinutes] = useState(String(initial.aviso_antecedencia_minutos));
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-xl">
        <DialogHeader>
          <DialogTitle>{reminder ? "Editar compromisso" : "Novo compromisso"}</DialogTitle>
          <DialogDescription>Informe o título e o horário do compromisso.</DialogDescription>
        </DialogHeader>
        <form
          className="grid gap-4"
          onSubmit={(event) => {
            event.preventDefault();
            const cleanTitle = title.trim();
            if (!cleanTitle || !startsAt || !endsAt) {
              toast.error("Preencha o título, o início e o fim.");
              return;
            }
            const startIso = toIso(startsAt);
            const endIso = toIso(endsAt);
            if (Date.parse(endIso) <= Date.parse(startIso)) {
              toast.error("O término deve ser posterior ao início.");
              return;
            }
            const noticeLead = Number.parseInt(leadMinutes, 10);
            if (!Number.isInteger(noticeLead) || noticeLead < 0 || noticeLead > 43200) {
              toast.error("Informe uma antecedência válida em minutos.");
              return;
            }
            onSave({ title: cleanTitle, starts_at: startIso, ends_at: endIso, details: details.trim() || null, aviso_antecedencia_minutos: noticeLead });
          }}
        >
          <label className="space-y-2 text-sm">
            <span className="text-muted-foreground">Título</span>
            <Input value={title} onChange={(event) => setTitle(event.target.value)} maxLength={160} autoFocus />
          </label>
          <div className="grid gap-4 sm:grid-cols-2">
            <label className="space-y-2 text-sm">
              <span className="text-muted-foreground">Início</span>
              <Input type="datetime-local" value={startsAt} onChange={(event) => setStartsAt(event.target.value)} />
            </label>
            <label className="space-y-2 text-sm">
              <span className="text-muted-foreground">Término</span>
              <Input type="datetime-local" value={endsAt} onChange={(event) => setEndsAt(event.target.value)} />
            </label>
          </div>
          <label className="space-y-2 text-sm">
            <span className="text-muted-foreground">Detalhes</span>
            <Textarea value={details} onChange={(event) => setDetails(event.target.value)} maxLength={1000} rows={4} />
          </label>
          <label className="space-y-2 text-sm">
            <span className="text-muted-foreground">Avisar com antecedência (minutos)</span>
            <Input type="number" min="0" max="43200" step="1" value={leadMinutes} onChange={(event) => setLeadMinutes(event.target.value)} />
          </label>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
            <Button type="submit" disabled={pending}>Salvar</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}