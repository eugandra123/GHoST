import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { CheckCircle2, Copy, ExternalLink, Link2, Plus, Send, Trash2, Unlink } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { DEFAULT_CATEGORIES } from "@/lib/categories";

export const Route = createFileRoute("/_authenticated/configuracoes")({
  head: () => ({
    meta: [
      { title: "Ajustes — GHoST" },
      {
        name: "description",
        content: "Vincule seu número de WhatsApp e gerencie as categorias de gastos.",
      },
      { property: "og:title", content: "Ajustes — GHoST" },
      { property: "og:description", content: "Conecte Telegram e WhatsApp e gerencie categorias." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ConfigPage,
});

function ConfigPage() {
  const queryClient = useQueryClient();
  const [phone, setPhone] = useState("");
  const [newCategory, setNewCategory] = useState("");
  const [webhookUrl, setWebhookUrl] = useState("");
  const [telegramWebhookUrl, setTelegramWebhookUrl] = useState("");

  useEffect(() => {
    setWebhookUrl(`${window.location.origin}/api/public/whatsapp/webhook`);
    setTelegramWebhookUrl(`${window.location.origin}/api/public/telegram/webhook`);
  }, []);

  const profileQuery = useQuery({
    queryKey: ["profile"],
    queryFn: async () => {
      const { data: userData } = await supabase.auth.getUser();
      if (!userData.user) throw new Error("Sessão expirada");
      const { data, error } = await supabase
        .from("profiles")
        .select("id, whatsapp_phone, telegram_chat_id, telegram_username, telegram_link_code")
        .eq("id", userData.user.id)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });

  useEffect(() => {
    if (profileQuery.data?.whatsapp_phone) setPhone(profileQuery.data.whatsapp_phone);
  }, [profileQuery.data]);

  const generateCode = useMutation({
    mutationFn: async () => {
      const { data: userData } = await supabase.auth.getUser();
      if (!userData.user) throw new Error("Sessão expirada");
      const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
      const values = crypto.getRandomValues(new Uint8Array(8));
      const code = Array.from(values, (value) => alphabet.charAt(value % alphabet.length)).join("");
      const { error } = await supabase
        .from("profiles")
        .upsert({ id: userData.user.id, telegram_link_code: code });
      if (error) throw error;
      return code;
    },
    onSuccess: () => {
      toast.success("Código gerado.");
      queryClient.invalidateQueries({ queryKey: ["profile"] });
    },
    onError: () => toast.error("Não foi possível gerar o código."),
  });

  const unlinkTelegram = useMutation({
    mutationFn: async () => {
      const { data: userData } = await supabase.auth.getUser();
      if (!userData.user) throw new Error("Sessão expirada");
      const { error } = await supabase
        .from("profiles")
        .update({ telegram_chat_id: null, telegram_username: null, telegram_link_code: null })
        .eq("id", userData.user.id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Telegram desvinculado.");
      queryClient.invalidateQueries({ queryKey: ["profile"] });
    },
  });

  const categoriesQuery = useQuery({
    queryKey: ["categories"],
    queryFn: async () => {
      const { data, error } = await supabase.from("categories").select("id, name").order("name");
      if (error) throw error;
      return data ?? [];
    },
  });

  const savePhone = useMutation({
    mutationFn: async () => {
      const { data: userData } = await supabase.auth.getUser();
      if (!userData.user) throw new Error("Sessão expirada");
      const { error } = await supabase
        .from("profiles")
        .upsert({ id: userData.user.id, whatsapp_phone: phone.replace(/\D/g, "") || null });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Número salvo.");
      queryClient.invalidateQueries({ queryKey: ["profile"] });
    },
    onError: () => toast.error("Não foi possível salvar o número."),
  });

  const addCategory = useMutation({
    mutationFn: async (name: string) => {
      const { data: userData } = await supabase.auth.getUser();
      if (!userData.user) throw new Error("Sessão expirada");
      const { error } = await supabase
        .from("categories")
        .insert({ name, user_id: userData.user.id });
      if (error) throw error;
    },
    onSuccess: () => {
      setNewCategory("");
      queryClient.invalidateQueries({ queryKey: ["categories"] });
    },
    onError: () => toast.error("Essa categoria já existe."),
  });

  const removeCategory = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("categories").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["categories"] }),
  });

  const seedDefaults = useMutation({
    mutationFn: async () => {
      const { data: userData } = await supabase.auth.getUser();
      if (!userData.user) throw new Error("Sessão expirada");
      const { error } = await supabase
        .from("categories")
        .upsert(
          DEFAULT_CATEGORIES.map((name) => ({ name, user_id: userData.user.id })),
          { onConflict: "user_id,name", ignoreDuplicates: true },
        );
      if (error) throw error;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["categories"] }),
  });

  const categories = categoriesQuery.data ?? [];

  return (
    <div className="space-y-8">
      <div>
        <p className="mb-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-primary">Sistema</p>
        <h1 className="text-3xl font-semibold">Ajustes</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Conecte seus canais e gerencie as categorias usadas pela IA.
        </p>
      </div>

      <section className="panel space-y-4 p-5">
        <div>
          <h2 className="text-lg font-semibold">Seu WhatsApp</h2>
          <p className="text-sm text-muted-foreground">
            Informe o número com DDI e DDD (ex: 5531999998888). É por ele que o assistente
            identifica que o gasto é seu.
          </p>
        </div>
        <div className="flex flex-wrap items-end gap-3">
          <div className="min-w-56 flex-1 space-y-2">
            <Label htmlFor="phone">Número</Label>
            <Input
              id="phone"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="5531999998888"
            />
          </div>
          <Button onClick={() => savePhone.mutate()}>Salvar</Button>
        </div>
      </section>

      <section className="panel space-y-4 p-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Send className="h-5 w-5 text-primary" />
              <h2 className="text-lg font-semibold">Telegram</h2>
            </div>
            <p className="text-sm text-muted-foreground">
              Envie textos ou prints ao GHoST para registrar seus gastos.
            </p>
          </div>
          {profileQuery.data?.telegram_chat_id ? (
            <span className="inline-flex items-center gap-1.5 rounded-full border border-primary/40 bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
              <CheckCircle2 className="h-3.5 w-3.5" /> Conectado
            </span>
          ) : (
            <span className="inline-flex items-center gap-1.5 rounded-full border border-border px-3 py-1 text-xs text-muted-foreground">
              Não conectado
            </span>
          )}
        </div>

        {profileQuery.data?.telegram_chat_id ? (
          <div className="flex flex-wrap items-center justify-between gap-3 border-t border-border pt-4">
            <div>
              <p className="text-sm font-medium">
                {profileQuery.data.telegram_username
                  ? `@${profileQuery.data.telegram_username}`
                  : "Chat vinculado"}
              </p>
              <p className="text-xs text-muted-foreground">As próximas mensagens já entram na planilha.</p>
            </div>
            <Button
              variant="outline"
              onClick={() => unlinkTelegram.mutate()}
              disabled={unlinkTelegram.isPending}
            >
              <Unlink className="h-4 w-4" /> Desvincular
            </Button>
          </div>
        ) : (
          <div className="space-y-3 border-t border-border pt-4">
            <ol className="space-y-1 text-sm text-muted-foreground">
              <li>1. Gere um código de vinculação.</li>
              <li>2. Abra o bot GHoST no Telegram.</li>
              <li>3. Envie o código ao bot.</li>
            </ol>
            {profileQuery.data?.telegram_link_code ? (
              <div className="flex flex-wrap items-center gap-2">
                <code className="rounded-md border border-border bg-secondary/40 px-4 py-2 font-mono text-lg font-semibold tracking-widest">
                  {profileQuery.data.telegram_link_code}
                </code>
                <Button
                  variant="outline"
                  size="icon"
                  aria-label="Copiar código"
                  onClick={async () => {
                    await navigator.clipboard.writeText(profileQuery.data?.telegram_link_code ?? "");
                    toast.success("Código copiado.");
                  }}
                >
                  <Copy className="h-4 w-4" />
                </Button>
                <Button asChild>
                  <a
                    href={`https://t.me/JarvisAssistantthebot?start=${profileQuery.data.telegram_link_code}`}
                    target="_blank"
                    rel="noreferrer"
                  >
                    Abrir o GHoST <ExternalLink className="h-4 w-4" />
                  </a>
                </Button>
              </div>
            ) : (
              <Button onClick={() => generateCode.mutate()} disabled={generateCode.isPending}>
                <Link2 className="h-4 w-4" /> Gerar código
              </Button>
            )}
            <p className="text-xs text-muted-foreground">
              O código é exclusivo da sua conta. Gere outro se precisar substituí-lo.
            </p>
          </div>
        )}

        <details className="border-t border-border pt-3 text-xs text-muted-foreground">
          <summary className="cursor-pointer font-medium text-foreground">Endereço técnico</summary>
          <code className="mt-2 block overflow-x-auto rounded-md bg-secondary/40 p-3">
            {telegramWebhookUrl}
          </code>
        </details>
      </section>

      <section className="panel space-y-3 p-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h2 className="text-lg font-semibold">Categorias</h2>
            <p className="text-sm text-muted-foreground">
              A IA classifica cada gasto usando esta lista.
            </p>
          </div>
          {categories.length === 0 && (
            <Button variant="outline" onClick={() => seedDefaults.mutate()}>
              Usar categorias sugeridas
            </Button>
          )}
        </div>
        <div className="flex flex-wrap gap-2">
          {categories.map((c) => (
            <span
              key={c.id}
              className="flex items-center gap-1 rounded-full border border-border bg-secondary/50 py-1 pl-3 pr-1 text-sm"
            >
              {c.name}
              <Button
                type="button"
                variant="ghost"
                size="icon"
                aria-label={`Remover ${c.name}`}
                className="h-6 w-6 rounded-full"
                onClick={() => removeCategory.mutate(c.id)}
              >
                <Trash2 className="h-3.5 w-3.5 text-destructive" />
              </Button>
            </span>
          ))}
          {categories.length === 0 && (
            <p className="text-sm text-muted-foreground">
              Nenhuma categoria própria — as sugeridas serão usadas por padrão.
            </p>
          )}
        </div>
        <form
          className="flex gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            if (newCategory.trim()) addCategory.mutate(newCategory.trim());
          }}
        >
          <Input
            value={newCategory}
            onChange={(e) => setNewCategory(e.target.value)}
            placeholder="Nova categoria"
            className="max-w-xs"
          />
          <Button type="submit" variant="outline">
            <Plus className="mr-1 h-4 w-4" /> Adicionar
          </Button>
        </form>
      </section>

      <section className="panel space-y-3 p-5">
        <h2 className="text-lg font-semibold">Conexão com a Z-API / Whapi</h2>
        <p className="text-sm text-muted-foreground">
          Quando você contratar a integração, cole este endereço no campo de webhook
          (“ao receber mensagem”) do provedor. O app já entende texto e imagem dos dois formatos.
        </p>
        <code className="block overflow-x-auto rounded-lg border border-border bg-secondary/40 p-3 text-xs">
          {webhookUrl}
        </code>
        <p className="text-xs text-muted-foreground">
          Para o assistente responder confirmando o gasto, será preciso cadastrar as credenciais de
          envio do provedor — me avise quando tiver e eu configuro.
        </p>
      </section>
    </div>
  );
}
