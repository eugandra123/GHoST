import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { ArrowDownRight, ArrowUpRight, Pencil, Plus, Trash2 } from "lucide-react";
import { useMemo, useState } from "react";
import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from "recharts";
import { toast } from "sonner";

import { ExpenseDialog, type ExpenseDraft, type ExpenseRow } from "@/components/expense-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { supabase } from "@/integrations/supabase/client";
import { CATEGORY_CHART_COLORS, DEFAULT_CATEGORIES, formatBRL, formatDateBR } from "@/lib/categories";

export const Route = createFileRoute("/_authenticated/gastos")({
  head: () => ({
    meta: [
      { title: "Gastos — GHoST" },
      {
        name: "description",
        content: "Todos os gastos do cartão registrados por WhatsApp, com filtros e painel mensal.",
      },
      { property: "og:title", content: "Gastos — GHoST" },
      { property: "og:description", content: "Gastos do cartão com filtros, painel e edição manual." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: GastosPage,
});

type Period = "mes" | "30dias" | "personalizado" | "tudo";

function startOfMonth(date: Date) {
  return new Date(date.getFullYear(), date.getMonth(), 1);
}

function GastosPage() {
  const queryClient = useQueryClient();
  const [period, setPeriod] = useState<Period>("mes");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("todas");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<ExpenseRow | null>(null);

  const expensesQuery = useQuery({
    queryKey: ["expenses"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("expenses")
        .select("id, occurred_at, merchant, amount, category, city, source")
        .order("occurred_at", { ascending: false });
      if (error) throw error;
      return (data ?? []).map((row) => ({ ...row, amount: Number(row.amount) })) as ExpenseRow[];
    },
  });

  const categoriesQuery = useQuery({
    queryKey: ["categories"],
    queryFn: async () => {
      const { data, error } = await supabase.from("categories").select("name").order("name");
      if (error) throw error;
      return data?.length ? data.map((c) => c.name) : [...DEFAULT_CATEGORIES];
    },
  });

  const categories = categoriesQuery.data ?? [...DEFAULT_CATEGORIES];
  const all = expensesQuery.data ?? [];

  const { rows, monthTotal, prevMonthTotal, byCategory } = useMemo(() => {
    const now = new Date();
    const monthStart = startOfMonth(now);
    const prevStart = startOfMonth(new Date(now.getFullYear(), now.getMonth() - 1, 1));

    let start: Date | null = null;
    let end: Date | null = null;
    if (period === "mes") start = monthStart;
    if (period === "30dias") start = new Date(now.getTime() - 30 * 86400000);
    if (period === "personalizado") {
      start = from ? new Date(`${from}T00:00:00`) : null;
      end = to ? new Date(`${to}T23:59:59`) : null;
    }

    const filtered = all.filter((e) => {
      const d = new Date(e.occurred_at);
      if (start && d < start) return false;
      if (end && d > end) return false;
      if (categoryFilter !== "todas" && e.category !== categoryFilter) return false;
      return true;
    });

    const sum = (list: ExpenseRow[]) => list.reduce((acc, e) => acc + e.amount, 0);
    const byCat = new Map<string, number>();
    filtered.forEach((e) => byCat.set(e.category, (byCat.get(e.category) ?? 0) + e.amount));

    return {
      rows: filtered,
      monthTotal: sum(all.filter((e) => new Date(e.occurred_at) >= monthStart)),
      prevMonthTotal: sum(
        all.filter((e) => {
          const d = new Date(e.occurred_at);
          return d >= prevStart && d < monthStart;
        }),
      ),
      byCategory: [...byCat.entries()]
        .map(([name, value]) => ({ name, value }))
        .sort((a, b) => b.value - a.value),
    };
  }, [all, period, from, to, categoryFilter]);

  const diff = monthTotal - prevMonthTotal;
  const diffPct = prevMonthTotal > 0 ? (diff / prevMonthTotal) * 100 : null;

  const saveMutation = useMutation({
    mutationFn: async (draft: ExpenseDraft) => {
      if (editing) {
        const { error } = await supabase.from("expenses").update(draft).eq("id", editing.id);
        if (error) throw error;
        return;
      }
      const { data: userData } = await supabase.auth.getUser();
      const { error } = await supabase
        .from("expenses")
        .insert({ ...draft, source: "manual", user_id: userData.user!.id });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success(editing ? "Gasto atualizado." : "Gasto adicionado.");
      queryClient.invalidateQueries({ queryKey: ["expenses"] });
    },
    onError: () => toast.error("Não foi possível salvar o gasto."),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("expenses").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Gasto excluído.");
      queryClient.invalidateQueries({ queryKey: ["expenses"] });
    },
    onError: () => toast.error("Não foi possível excluir."),
  });

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="mb-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-primary">Módulo</p>
          <h1 className="text-3xl font-semibold">Gastos</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Tudo que chega pelo Telegram ou WhatsApp aparece aqui automaticamente.
          </p>
        </div>
        <Button
          onClick={() => {
            setEditing(null);
            setDialogOpen(true);
          }}
        >
          <Plus className="mr-1.5 h-4 w-4" /> Novo gasto
        </Button>
      </div>

      {/* Dashboard */}
      <div className="grid gap-4 lg:grid-cols-3">
        <div className="panel relative overflow-hidden p-6">
          <div className="absolute inset-x-0 top-0 h-px bg-[image:var(--gradient-brand)]" />
          <p className="text-xs font-medium uppercase tracking-[0.14em] text-muted-foreground">Total no mês atual</p>
          <p className="mt-3 font-display text-3xl font-semibold">{formatBRL(monthTotal)}</p>
          <p className="mt-2 flex items-center gap-1 text-sm">
            {diff >= 0 ? (
              <ArrowUpRight className="h-4 w-4 text-destructive" />
            ) : (
              <ArrowDownRight className="h-4 w-4 text-primary" />
            )}
            <span className={diff >= 0 ? "text-destructive" : "text-primary"}>
              {formatBRL(Math.abs(diff))}
              {diffPct !== null ? ` (${Math.abs(diffPct).toFixed(0)}%)` : ""}
            </span>
            <span className="text-muted-foreground">vs. mês anterior</span>
          </p>
          <p className="mt-1 text-xs text-muted-foreground">
            Mês anterior: {formatBRL(prevMonthTotal)}
          </p>
        </div>

        <div className="panel p-6 lg:col-span-2">
          <p className="text-xs font-medium uppercase tracking-[0.14em] text-muted-foreground">Gasto por categoria</p>
          {byCategory.length === 0 ? (
            <p className="py-8 text-center text-sm text-muted-foreground">Sem dados no período.</p>
          ) : (
            <div className="mt-2 flex flex-col items-center gap-4 sm:flex-row">
              <div className="h-40 w-40 shrink-0">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={byCategory}
                      dataKey="value"
                      nameKey="name"
                      innerRadius={40}
                      outerRadius={72}
                      stroke="none"
                    >
                      {byCategory.map((entry, i) => (
                        <Cell
                          key={entry.name}
                          fill={CATEGORY_CHART_COLORS[i % CATEGORY_CHART_COLORS.length]}
                        />
                      ))}
                    </Pie>
                    <Tooltip
                      formatter={(value: number) => formatBRL(value)}
                      contentStyle={{
                        background: "var(--color-popover)",
                        border: "1px solid var(--color-border)",
                        borderRadius: "0.6rem",
                        color: "var(--color-popover-foreground)",
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <ul className="grid flex-1 gap-1.5 text-sm">
                {byCategory.map((c, i) => (
                  <li key={c.name} className="flex items-center gap-2">
                    <span
                      className="h-2.5 w-2.5 rounded-full"
                      style={{ background: CATEGORY_CHART_COLORS[i % CATEGORY_CHART_COLORS.length] }}
                    />
                    <span className="flex-1 truncate">{c.name}</span>
                    <span className="font-medium">{formatBRL(c.value)}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>

      {/* Filtros */}
      <div className="panel flex flex-wrap items-end gap-4 p-5">
        <div className="min-w-40 flex-1">
          <label className="mb-1 block text-xs text-muted-foreground">Período</label>
          <Select value={period} onValueChange={(v) => setPeriod(v as Period)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="mes">Mês atual</SelectItem>
              <SelectItem value="30dias">Últimos 30 dias</SelectItem>
              <SelectItem value="personalizado">Personalizado</SelectItem>
              <SelectItem value="tudo">Tudo</SelectItem>
            </SelectContent>
          </Select>
        </div>
        {period === "personalizado" && (
          <>
            <div>
              <label className="mb-1 block text-xs text-muted-foreground">De</label>
              <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
            </div>
            <div>
              <label className="mb-1 block text-xs text-muted-foreground">Até</label>
              <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} />
            </div>
          </>
        )}
        <div className="min-w-40 flex-1">
          <label className="mb-1 block text-xs text-muted-foreground">Categoria</label>
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todas">Todas</SelectItem>
              {categories.map((c) => (
                <SelectItem key={c} value={c}>
                  {c}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="ml-auto text-sm text-muted-foreground">
          {rows.length} lançamento{rows.length === 1 ? "" : "s"} ·{" "}
          <span className="font-semibold text-foreground">
            {formatBRL(rows.reduce((a, e) => a + e.amount, 0))}
          </span>
        </div>
      </div>

      {/* Tabela */}
      <div className="panel overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-24">Data</TableHead>
              <TableHead>Estabelecimento</TableHead>
              <TableHead className="w-32 text-right">Valor</TableHead>
              <TableHead className="w-40">Categoria</TableHead>
              <TableHead className="w-24 text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {expensesQuery.isLoading && (
              <TableRow>
                <TableCell colSpan={5} className="py-10 text-center text-muted-foreground">
                  Carregando…
                </TableCell>
              </TableRow>
            )}
            {!expensesQuery.isLoading && rows.length === 0 && (
              <TableRow>
                <TableCell colSpan={5} className="py-10 text-center text-muted-foreground">
                  Nenhum gasto neste filtro. Mande uma mensagem no Telegram ou adicione manualmente.
                </TableCell>
              </TableRow>
            )}
            {rows.map((row) => (
              <TableRow key={row.id}>
                <TableCell className="text-muted-foreground">
                  {formatDateBR(row.occurred_at)}
                </TableCell>
                <TableCell>
                  <span className="font-medium">{row.merchant}</span>
                  {row.city && (
                    <span className="ml-2 text-xs text-muted-foreground">{row.city}</span>
                  )}
                  {row.source !== "manual" && (
                    <span className="ml-2 rounded bg-secondary px-1.5 py-0.5 text-[10px] uppercase text-muted-foreground">
                      {row.source === "image" ? "print" : "texto"}
                    </span>
                  )}
                </TableCell>
                <TableCell className="text-right font-semibold">{formatBRL(row.amount)}</TableCell>
                <TableCell>
                  <span className="rounded-full border border-border px-2 py-0.5 text-xs">
                    {row.category}
                  </span>
                </TableCell>
                <TableCell className="text-right">
                  <Button
                    variant="ghost"
                    size="icon"
                    aria-label="Editar"
                    onClick={() => {
                      setEditing(row);
                      setDialogOpen(true);
                    }}
                  >
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    aria-label="Excluir"
                    onClick={() => deleteMutation.mutate(row.id)}
                  >
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <ExpenseDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        categories={categories}
        expense={editing}
        onSave={async (draft) => {
          await saveMutation.mutateAsync(draft);
        }}
      />
    </div>
  );
}
