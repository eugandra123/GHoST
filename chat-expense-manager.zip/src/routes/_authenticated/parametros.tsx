import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { Plus, Save, Trash2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/parametros")({
  head: () => ({
    meta: [
      { title: "Parâmetros — GHoST" },
      { name: "description", content: "Consulte e edite os parâmetros pessoais salvos no GHoST." },
      { property: "og:title", content: "Parâmetros — GHoST" },
      { property: "og:description", content: "Gerencie seus parâmetros pessoais no GHoST." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ParametersPage,
});

function ParametersPage() {
  const queryClient = useQueryClient();
  const [newKey, setNewKey] = useState("");
  const [newValue, setNewValue] = useState("");

  const parametersQuery = useQuery({
    queryKey: ["user-parameters"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("user_parameters")
        .select("id,key,value,updated_at")
        .order("updated_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });

  const addParameter = useMutation({
    mutationFn: async () => {
      const { data } = await supabase.auth.getUser();
      if (!data.user) throw new Error("Sessão expirada");
      const key = newKey.trim().toLocaleLowerCase("pt-BR");
      const value = newValue.trim();
      if (!key || !value) throw new Error("Preencha a chave e o valor.");
      const { error } = await supabase
        .from("user_parameters")
        .upsert({ user_id: data.user.id, key, value }, { onConflict: "user_id,key" });
      if (error) throw error;
    },
    onSuccess: () => {
      setNewKey("");
      setNewValue("");
      void queryClient.invalidateQueries({ queryKey: ["user-parameters"] });
      toast.success("Parâmetro salvo.");
    },
    onError: (error) => toast.error(error instanceof Error ? error.message : "Não foi possível salvar."),
  });

  const updateParameter = useMutation({
    mutationFn: async ({ id, key, value }: { id: string; key: string; value: string }) => {
      if (!key.trim() || !value.trim()) throw new Error("Preencha a chave e o valor.");
      const { error } = await supabase
        .from("user_parameters")
        .update({ key: key.trim().toLocaleLowerCase("pt-BR"), value: value.trim() })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["user-parameters"] });
      toast.success("Alterações salvas.");
    },
    onError: () => toast.error("Não foi possível atualizar o parâmetro."),
  });

  const deleteParameter = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("user_parameters").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => void queryClient.invalidateQueries({ queryKey: ["user-parameters"] }),
    onError: () => toast.error("Não foi possível remover o parâmetro."),
  });

  return (
    <div className="space-y-8">
      <div>
        <p className="mb-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-primary">Memória</p>
        <h1 className="text-3xl font-semibold">Parâmetros</h1>
        <p className="mt-1 text-sm text-muted-foreground">Informações pessoais salvas para consulta e edição.</p>
      </div>

      <form
        className="panel grid gap-3 p-5 sm:grid-cols-[minmax(10rem,0.8fr)_minmax(14rem,1.5fr)_auto] sm:items-end"
        onSubmit={(event) => {
          event.preventDefault();
          addParameter.mutate();
        }}
      >
        <label className="space-y-2 text-sm">
          <span className="text-muted-foreground">Chave</span>
          <Input value={newKey} onChange={(event) => setNewKey(event.target.value)} placeholder="aniversário" />
        </label>
        <label className="space-y-2 text-sm">
          <span className="text-muted-foreground">Valor</span>
          <Input value={newValue} onChange={(event) => setNewValue(event.target.value)} placeholder="10/05" />
        </label>
        <Button type="submit" disabled={addParameter.isPending}>
          <Plus className="h-4 w-4" /> Adicionar
        </Button>
      </form>

      <section className="space-y-3">
        {parametersQuery.isLoading ? (
          <p className="text-sm text-muted-foreground">Carregando…</p>
        ) : parametersQuery.data?.length ? (
          parametersQuery.data.map((parameter) => (
            <ParameterRow
              key={parameter.id}
              parameter={parameter}
              onSave={(key, value) => updateParameter.mutate({ id: parameter.id, key, value })}
              onDelete={() => deleteParameter.mutate(parameter.id)}
            />
          ))
        ) : (
          <div className="panel p-6 text-sm text-muted-foreground">Nenhum parâmetro salvo.</div>
        )}
      </section>
    </div>
  );
}

function ParameterRow({
  parameter,
  onSave,
  onDelete,
}: {
  parameter: { id: string; key: string; value: string };
  onSave: (key: string, value: string) => void;
  onDelete: () => void;
}) {
  const [key, setKey] = useState(parameter.key);
  const [value, setValue] = useState(parameter.value);
  return (
    <div className="panel grid gap-3 p-4 sm:grid-cols-[minmax(10rem,0.8fr)_minmax(14rem,1.5fr)_auto_auto] sm:items-center">
      <Input aria-label="Chave" value={key} onChange={(event) => setKey(event.target.value)} />
      <Input aria-label={`Valor de ${parameter.key}`} value={value} onChange={(event) => setValue(event.target.value)} />
      <Button variant="outline" size="icon" aria-label={`Salvar ${parameter.key}`} onClick={() => onSave(key, value)}>
        <Save className="h-4 w-4" />
      </Button>
      <Button variant="ghost" size="icon" aria-label={`Remover ${parameter.key}`} onClick={onDelete}>
        <Trash2 className="h-4 w-4 text-destructive" />
      </Button>
    </div>
  );
}