import { useQuery } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, CalendarDays, CheckCircle2, Circle, Coins, KeyRound, ReceiptText } from "lucide-react";
import { useMemo } from "react";
import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from "recharts";

import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { CATEGORY_CHART_COLORS, formatBRL } from "@/lib/categories";

export const Route = createFileRoute("/_authenticated/inicio")({
  head: () => ({
    meta: [
      { title: "Início — GHoST" },
      { name: "description", content: "Acesse os módulos do seu assistente pessoal GHoST." },
      { property: "og:title", content: "Início — GHoST" },
      { property: "og:description", content: "Seu assistente pessoal e seus módulos em um só lugar." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: InicioPage,
});

function InicioPage() {
  const monthStart = useMemo(() => {
    const now = new Date();
    return new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
  }, []);

  const expensesQuery = useQuery({
    queryKey: ["dashboard-expenses", monthStart],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("expenses")
        .select("amount,category,occurred_at")
        .gte("occurred_at", monthStart)
        .order("occurred_at", { ascending: false });
      if (error) throw error;
      return (data ?? []).map((row) => ({ ...row, amount: Number(row.amount) }));
    },
  });

  const remindersQuery = useQuery({
    queryKey: ["dashboard-reminders"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("reminders")
        .select("id,title,starts_at")
        .gte("starts_at", new Date().toISOString())
        .order("starts_at", { ascending: true })
        .limit(4);
      if (error) throw error;
      return data ?? [];
    },
  });

  const tasksQuery = useQuery({
    queryKey: ["dashboard-tasks"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("tasks")
        .select("id,description,status,created_at")
        .eq("status", "pendente")
        .order("created_at", { ascending: false })
        .limit(5);
      if (error) throw error;
      return data ?? [];
    },
  });

  const usageQuery = useQuery({
    queryKey: ["dashboard-ai-usage", monthStart],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("ai_usage")
        .select("estimated_cost_usd,model_family")
        .gte("created_at", monthStart);
      if (error) throw error;
      return (data ?? []).map((row) => ({ ...row, estimated_cost_usd: Number(row.estimated_cost_usd) }));
    },
  });

  const parametersQuery = useQuery({
    queryKey: ["dashboard-parameters"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("user_parameters")
        .select("id,key,value,updated_at")
        .order("updated_at", { ascending: false })
        .limit(5);
      if (error) throw error;
      return data ?? [];
    },
  });

  const expenseSummary = useMemo(() => {
    const rows = expensesQuery.data ?? [];
    const categories = new Map<string, number>();
    rows.forEach((row) => categories.set(row.category, (categories.get(row.category) ?? 0) + row.amount));
    return {
      total: rows.reduce((sum, row) => sum + row.amount, 0),
      count: rows.length,
      categories: [...categories.entries()]
        .map(([name, value]) => ({ name, value }))
        .sort((a, b) => b.value - a.value),
    };
  }, [expensesQuery.data]);

  const totalAiCost = (usageQuery.data ?? []).reduce((sum, row) => sum + row.estimated_cost_usd, 0);
  const formatUsd = (value: number) => new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 4,
    maximumFractionDigits: 6,
  }).format(value);

  return (
    <div className="dashboard-enter space-y-12">
      <section>
        <p className="text-sm text-muted-foreground">Visão geral</p>
        <h1 className="mt-1 text-3xl font-semibold sm:text-4xl">Seu dia, em um só lugar.</h1>
      </section>

      <DashboardSection title="Gastos" to="/gastos" icon={ReceiptText}>
        <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_15rem] lg:items-center">
          <div>
            <p className="text-sm text-muted-foreground">Total no mês atual</p>
            <p className="mt-2 font-display text-4xl font-semibold sm:text-5xl">{formatBRL(expenseSummary.total)}</p>
            <p className="mt-3 text-sm text-muted-foreground">
              {expenseSummary.count} {expenseSummary.count === 1 ? "lançamento registrado" : "lançamentos registrados"}
            </p>
            <div className="mt-6 grid gap-2 sm:grid-cols-2">
              {expenseSummary.categories.slice(0, 4).map((category, index) => (
                <div key={category.name} className="flex items-center justify-between gap-3 border-b border-border py-2 text-sm">
                  <span className="flex min-w-0 items-center gap-2 text-muted-foreground">
                    <span className="h-2 w-2 shrink-0 rounded-full" style={{ backgroundColor: CATEGORY_CHART_COLORS[index % CATEGORY_CHART_COLORS.length] }} />
                    <span className="truncate">{category.name}</span>
                  </span>
                  <span className="font-medium">{formatBRL(category.value)}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="mx-auto h-52 w-52">
            {expenseSummary.categories.length ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={expenseSummary.categories} dataKey="value" nameKey="name" innerRadius={58} outerRadius={94} paddingAngle={2} stroke="none">
                    {expenseSummary.categories.map((category, index) => (
                      <Cell key={category.name} fill={CATEGORY_CHART_COLORS[index % CATEGORY_CHART_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value: number) => formatBRL(value)} contentStyle={{ background: "var(--color-popover)", border: "1px solid var(--color-border)", borderRadius: "0.5rem", color: "var(--color-popover-foreground)" }} />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="grid h-full place-items-center rounded-full border border-dashed border-border text-center text-xs text-muted-foreground">Sem gastos<br />neste mês</div>
            )}
          </div>
        </div>
      </DashboardSection>

      <div className="grid gap-6 lg:grid-cols-2">
        <DashboardSection title="Agenda" to="/agenda" icon={CalendarDays} compact>
          <div className="space-y-1">
            {remindersQuery.data?.length ? remindersQuery.data.map((reminder) => {
              const startsAt = new Date(reminder.starts_at);
              return (
                <div key={reminder.id} className="flex items-center gap-4 border-b border-border py-3 last:border-0">
                  <div className="w-11 shrink-0 text-center">
                    <p className="font-display text-xl font-semibold">{startsAt.toLocaleDateString("pt-BR", { timeZone: "America/Sao_Paulo", day: "2-digit" })}</p>
                    <p className="text-[10px] uppercase text-muted-foreground">{startsAt.toLocaleDateString("pt-BR", { timeZone: "America/Sao_Paulo", month: "short" }).replace(".", "")}</p>
                  </div>
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium">{reminder.title}</p>
                    <p className="mt-0.5 text-xs text-muted-foreground">{startsAt.toLocaleTimeString("pt-BR", { timeZone: "America/Sao_Paulo", hour: "2-digit", minute: "2-digit" })}</p>
                  </div>
                </div>
              );
            }) : <EmptyState label="Nenhum compromisso próximo." />}
          </div>
        </DashboardSection>

        <DashboardSection title="Tarefas" to="/tarefas" icon={CheckCircle2} compact>
          <div className="space-y-1">
            {tasksQuery.data?.length ? tasksQuery.data.map((task) => (
              <div key={task.id} className="flex items-start gap-3 border-b border-border py-3 last:border-0">
                <Circle className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                <p className="line-clamp-2 text-sm">{task.description}</p>
              </div>
            )) : <EmptyState label="Nenhuma tarefa pendente." />}
          </div>
        </DashboardSection>
      </div>

      <DashboardSection title="Uso da IA" to="/uso-ia" icon={Coins} compact>
        <div className="grid gap-6 sm:grid-cols-3">
          <Metric label="Custo estimado no mês" value={formatUsd(totalAiCost)} />
          <Metric label="Chamadas realizadas" value={String(usageQuery.data?.length ?? 0)} />
          <Metric label="Modelo mais usado" value={(usageQuery.data ?? []).filter((row) => row.model_family === "sonnet").length > (usageQuery.data ?? []).filter((row) => row.model_family === "haiku").length ? "Sonnet" : "Haiku"} />
        </div>
      </DashboardSection>

      <DashboardSection title="Parâmetros" to="/parametros" icon={KeyRound} compact>
        <div className="grid gap-3 sm:grid-cols-2">
          {parametersQuery.data?.length ? parametersQuery.data.map((parameter) => (
            <div key={parameter.id} className="rounded-md border border-border bg-background/40 px-4 py-3">
              <p className="text-xs text-muted-foreground">{parameter.key}</p>
              <p className="mt-1 truncate text-sm font-medium">{parameter.value}</p>
            </div>
          )) : <div className="sm:col-span-2"><EmptyState label="Nenhum parâmetro salvo." /></div>}
        </div>
      </DashboardSection>
    </div>
  );
}

function DashboardSection({ title, to, icon: Icon, compact = false, children }: {
  title: string;
  to: "/gastos" | "/agenda" | "/tarefas" | "/uso-ia" | "/parametros";
  icon: typeof ReceiptText;
  compact?: boolean;
  children: React.ReactNode;
}) {
  return (
    <section className={`dashboard-panel ${compact ? "p-5 sm:p-6" : "p-6 sm:p-8"}`}>
      <div className="mb-6 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <span className="grid h-10 w-10 place-items-center rounded-md bg-accent text-primary"><Icon className="h-5 w-5" /></span>
          <h2 className="text-lg font-semibold">{title}</h2>
        </div>
        <Button asChild variant="ghost" size="sm">
          <Link to={to}>Ver tudo <ArrowRight className="h-4 w-4" /></Link>
        </Button>
      </div>
      {children}
    </section>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="border-b border-border pb-4 last:border-0 sm:border-r sm:border-b-0 sm:pr-6 sm:last:border-r-0">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="mt-2 font-display text-2xl font-semibold">{value}</p>
    </div>
  );
}

function EmptyState({ label }: { label: string }) {
  return <p className="py-7 text-center text-sm text-muted-foreground">{label}</p>;
}