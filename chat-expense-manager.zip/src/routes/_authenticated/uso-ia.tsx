import { useQuery } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { Bot, Coins, MessageSquareText, ReceiptText, Sparkles } from "lucide-react";
import { useMemo, useState } from "react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/uso-ia")({
  head: () => ({
    meta: [
      { title: "Uso da IA — GHoST" },
      {
        name: "description",
        content: "Acompanhe tokens, chamadas e custos estimados da IA no GHoST.",
      },
      { property: "og:title", content: "Uso da IA — GHoST" },
      {
        property: "og:description",
        content: "Visão estimada do uso dos modelos Haiku e Sonnet no GHoST.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AiUsagePage,
});

type Period = "mes" | "30dias";

type UsageRow = {
  id: string;
  model_family: string;
  input_tokens: number;
  output_tokens: number;
  estimated_cost_usd: number;
  origin: string;
  created_at: string;
};

function startDateFor(period: Period) {
  const now = new Date();
  if (period === "30dias") return new Date(now.getTime() - 30 * 86400000);
  return new Date(now.getFullYear(), now.getMonth(), 1);
}

function dayKey(date: Date) {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/Sao_Paulo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(date);
}

function formatDay(date: Date) {
  return new Intl.DateTimeFormat("pt-BR", {
    timeZone: "America/Sao_Paulo",
    day: "2-digit",
    month: "2-digit",
  }).format(date);
}

function formatUsd(value: number, compact = false) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: compact ? 4 : 6,
    maximumFractionDigits: 6,
  }).format(value);
}

function formatNumber(value: number) {
  return new Intl.NumberFormat("pt-BR").format(value);
}

function AiUsagePage() {
  const [period, setPeriod] = useState<Period>("mes");
  const periodStart = useMemo(() => startDateFor(period), [period]);

  const usageQuery = useQuery({
    queryKey: ["ai-usage", period, periodStart.toISOString()],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("ai_usage")
        .select("id,model_family,input_tokens,output_tokens,estimated_cost_usd,origin,created_at")
        .gte("created_at", periodStart.toISOString())
        .order("created_at", { ascending: true });
      if (error) throw error;
      return (data ?? []).map((row) => ({
        ...row,
        input_tokens: Number(row.input_tokens),
        output_tokens: Number(row.output_tokens),
        estimated_cost_usd: Number(row.estimated_cost_usd),
      })) as UsageRow[];
    },
  });

  const expensesQuery = useQuery({
    queryKey: ["ai-usage-expenses", period, periodStart.toISOString()],
    queryFn: async () => {
      const { count, error } = await supabase
        .from("whatsapp_messages")
        .select("id", { count: "exact", head: true })
        .gte("created_at", periodStart.toISOString())
        .eq("status", "processed")
        .not("expense_id", "is", null);
      if (error) throw error;
      return count ?? 0;
    },
  });

  const conversationsQuery = useQuery({
    queryKey: ["ai-usage-conversations", period, periodStart.toISOString()],
    queryFn: async () => {
      const { count, error } = await supabase
        .from("whatsapp_messages")
        .select("id", { count: "exact", head: true })
        .gte("created_at", periodStart.toISOString())
        .eq("status", "processed")
        .is("expense_id", null);
      if (error) throw error;
      return count ?? 0;
    },
  });

  const metrics = useMemo(() => {
    const rows = usageQuery.data ?? [];
    const totalCost = rows.reduce((total, row) => total + row.estimated_cost_usd, 0);
    const totalInput = rows.reduce((total, row) => total + row.input_tokens, 0);
    const totalOutput = rows.reduce((total, row) => total + row.output_tokens, 0);
    const haiku = rows.filter((row) => row.model_family === "haiku");
    const sonnet = rows.filter((row) => row.model_family === "sonnet");
    const modelSummary = [
      {
        name: "Haiku 4.5",
        calls: haiku.length,
        cost: haiku.reduce((total, row) => total + row.estimated_cost_usd, 0),
      },
      {
        name: "Sonnet 5",
        calls: sonnet.length,
        cost: sonnet.reduce((total, row) => total + row.estimated_cost_usd, 0),
      },
    ];

    const byDay = new Map<string, number>();
    rows.forEach((row) => {
      const key = dayKey(new Date(row.created_at));
      byDay.set(key, (byDay.get(key) ?? 0) + row.estimated_cost_usd);
    });
    const chartData: Array<{ date: string; label: string; cost: number }> = [];
    const cursor = new Date(periodStart);
    const today = new Date();
    while (cursor <= today) {
      const key = dayKey(cursor);
      chartData.push({ date: key, label: formatDay(cursor), cost: byDay.get(key) ?? 0 });
      cursor.setDate(cursor.getDate() + 1);
    }

    return { totalCost, totalInput, totalOutput, modelSummary, chartData, calls: rows.length };
  }, [usageQuery.data, periodStart]);

  const expenseMessages = expensesQuery.data ?? 0;
  const conversationMessages = conversationsQuery.data ?? 0;
  const totalMessages = expenseMessages + conversationMessages;

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="mb-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-primary">Módulo</p>
          <h1 className="text-3xl font-semibold">Uso da IA</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Tokens e custo estimado das chamadas à Anthropic.
          </p>
        </div>
        <div className="w-full sm:w-48">
          <label className="mb-1 block text-xs text-muted-foreground">Período</label>
          <Select value={period} onValueChange={(value) => setPeriod(value as Period)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="mes">Mês atual</SelectItem>
              <SelectItem value="30dias">Últimos 30 dias</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <MetricCard icon={Coins} label="Custo estimado" value={formatUsd(metrics.totalCost, true)} detail={`${metrics.calls} chamadas`} />
        <MetricCard icon={Sparkles} label="Tokens de entrada" value={formatNumber(metrics.totalInput)} detail={`${formatNumber(metrics.totalOutput)} tokens de saída`} />
        <MetricCard icon={ReceiptText} label="Mensagens de gastos" value={formatNumber(expenseMessages)} detail="registros processados" />
        <MetricCard icon={MessageSquareText} label="Conversas gerais" value={formatNumber(conversationMessages)} detail={`${formatNumber(totalMessages)} mensagens processadas`} />
      </div>

      <div className="grid gap-4 xl:grid-cols-[minmax(0,1.65fr)_minmax(18rem,0.75fr)]">
        <section className="panel relative overflow-hidden p-5 sm:p-6">
          <div className="absolute inset-x-0 top-0 h-px bg-[image:var(--gradient-brand)]" />
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="text-xs font-medium uppercase tracking-[0.14em] text-muted-foreground">Custo por dia</p>
              <p className="mt-1 text-sm text-muted-foreground">Estimativa em dólar no período selecionado</p>
            </div>
            <Bot className="h-5 w-5 text-primary" />
          </div>
          <div className="mt-6 h-72 w-full">
            {usageQuery.isLoading ? (
              <div className="flex h-full items-center justify-center text-sm text-muted-foreground">Carregando…</div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={metrics.chartData} margin={{ top: 10, right: 8, left: -18, bottom: 0 }}>
                  <defs>
                    <linearGradient id="aiCostFill" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="var(--brand-violet)" stopOpacity={0.42} />
                      <stop offset="100%" stopColor="var(--brand-cyan)" stopOpacity={0.02} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid stroke="var(--color-border)" vertical={false} />
                  <XAxis dataKey="label" tick={{ fill: "var(--color-muted-foreground)", fontSize: 11 }} tickLine={false} axisLine={false} minTickGap={28} />
                  <YAxis
                    domain={[0, (maximum: number) => Math.max(maximum, 0.001)]}
                    tick={{ fill: "var(--color-muted-foreground)", fontSize: 11 }}
                    tickLine={false}
                    axisLine={false}
                    tickFormatter={(value: number) => `$${value.toFixed(4)}`}
                  />
                  <Tooltip
                    formatter={(value: number) => [formatUsd(value), "Custo estimado"]}
                    contentStyle={{
                      background: "var(--color-popover)",
                      border: "1px solid var(--color-border)",
                      borderRadius: "0.5rem",
                      color: "var(--color-popover-foreground)",
                    }}
                  />
                  <Area type="monotone" dataKey="cost" stroke="var(--brand-cyan)" strokeWidth={2} fill="url(#aiCostFill)" />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </div>
        </section>

        <section className="panel relative overflow-hidden p-5 sm:p-6">
          <div className="absolute inset-x-0 top-0 h-px bg-[image:var(--gradient-brand)]" />
          <p className="text-xs font-medium uppercase tracking-[0.14em] text-muted-foreground">Por modelo</p>
          <div className="mt-7 space-y-7">
            {metrics.modelSummary.map((model, index) => {
              const share = metrics.totalCost > 0 ? (model.cost / metrics.totalCost) * 100 : 0;
              return (
                <div key={model.name}>
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <p className="font-medium">{model.name}</p>
                      <p className="mt-1 text-xs text-muted-foreground">{model.calls} chamadas</p>
                    </div>
                    <p className="font-display text-lg font-semibold">{formatUsd(model.cost)}</p>
                  </div>
                  <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-secondary">
                    <div
                      className={index === 0 ? "h-full rounded-full bg-primary" : "h-full rounded-full bg-accent"}
                      style={{ width: `${Math.max(share, model.calls ? 2 : 0)}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      </div>

      <p className="border-l-2 border-primary/50 pl-4 text-xs leading-relaxed text-muted-foreground">
        Esta é uma estimativa calculada com os tokens informados pela própria API. A cobrança oficial e o saldo permanecem no console da Anthropic.
      </p>
    </div>
  );
}

function MetricCard({
  icon: Icon,
  label,
  value,
  detail,
}: {
  icon: typeof Coins;
  label: string;
  value: string;
  detail: string;
}) {
  return (
    <div className="panel relative min-h-36 overflow-hidden p-5">
      <div className="absolute inset-x-0 top-0 h-px bg-[image:var(--gradient-brand)]" />
      <div className="flex items-center justify-between gap-3">
        <p className="text-xs font-medium uppercase tracking-[0.12em] text-muted-foreground">{label}</p>
        <Icon className="h-4 w-4 text-primary" />
      </div>
      <p className="mt-5 font-display text-2xl font-semibold sm:text-3xl">{value}</p>
      <p className="mt-2 text-xs text-muted-foreground">{detail}</p>
    </div>
  );
}