import { Link, Outlet, useLocation, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { LogOut, Send, Settings } from "lucide-react";

import { JrvsMark } from "@/components/jrvs-mark";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";

export function AppShell() {
  const navigate = useNavigate();
  const pathname = useLocation({ select: (location) => location.pathname });

  // Garante que exista um perfil para vincular o número de WhatsApp.
  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      const user = data.user;
      if (!user) return;
      void supabase
        .from("profiles")
        .upsert(
          {
            id: user.id,
            display_name: (user.user_metadata?.["full_name"] as string) ?? user.email ?? null,
          },
          { onConflict: "id", ignoreDuplicates: true },
        )
        .then(() => undefined);
    });
  }, []);

  async function signOut() {
    await supabase.auth.signOut();
    navigate({ to: "/auth" });
  }

  return (
    <div className="min-h-screen">
      <header className="app-header sticky top-0 z-30 border-b border-border bg-background/90 backdrop-blur-xl">
        <div className="mx-auto flex h-17 w-full max-w-5xl items-center justify-between px-4 sm:px-6 lg:px-8">
          <Link to="/inicio" className="flex items-center gap-3" aria-label="Ir para o início">
            <JrvsMark className="h-9 w-9" />
            <span className="font-display text-lg font-semibold">GHoST</span>
          </Link>
          <div className="flex items-center gap-1">
            <Button asChild variant="ghost" size="icon">
              <a href="https://t.me/JarvisAssistantthebot" target="_blank" rel="noreferrer" aria-label="Conversar no Telegram" title="Conversar no Telegram">
                <Send className="h-4 w-4" />
              </a>
            </Button>
            <Button asChild variant="ghost" size="icon">
              <Link to="/configuracoes" aria-label="Abrir ajustes" title="Ajustes">
                <Settings className="h-4 w-4" />
              </Link>
            </Button>
            <Button variant="ghost" size="icon" onClick={signOut} aria-label="Sair" title="Sair">
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </header>
      <main className="mx-auto w-full max-w-5xl px-4 py-10 sm:px-6 sm:py-14 lg:px-8">
        <div key={pathname} className="app-page-enter"><Outlet /></div>
      </main>
    </div>
  );
}
