import { cn } from "@/lib/utils";
import ghostRing from "@/assets/ghost-ring.gif.asset.json";

export function JrvsMark({ className }: { className?: string }) {
  return (
    <img
      src={ghostRing.url}
      alt=""
      aria-hidden="true"
      className={cn("inline-block shrink-0 object-contain", className)}
    />
  );
}
