import { useEffect, useState } from "react";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export type ExpenseRow = {
  id: string;
  occurred_at: string;
  merchant: string;
  amount: number;
  category: string;
  city: string | null;
  source: string;
};

export type ExpenseDraft = {
  occurred_at: string;
  merchant: string;
  amount: number;
  category: string;
  city: string | null;
};

function toLocalInput(iso: string) {
  const d = new Date(iso);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

export function ExpenseDialog({
  open,
  onOpenChange,
  categories,
  expense,
  onSave,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  categories: string[];
  expense: ExpenseRow | null;
  onSave: (draft: ExpenseDraft) => Promise<void>;
}) {
  const [merchant, setMerchant] = useState("");
  const [amount, setAmount] = useState("");
  const [category, setCategory] = useState(categories[0] ?? "Outros");
  const [city, setCity] = useState("");
  const [when, setWhen] = useState(toLocalInput(new Date().toISOString()));
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!open) return;
    setMerchant(expense?.merchant ?? "");
    setAmount(expense ? String(expense.amount) : "");
    setCategory(expense?.category ?? categories[0] ?? "Outros");
    setCity(expense?.city ?? "");
    setWhen(toLocalInput(expense?.occurred_at ?? new Date().toISOString()));
  }, [open, expense, categories]);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setSaving(true);
    try {
      await onSave({
        merchant: merchant.trim(),
        amount: Number(amount.replace(",", ".")),
        category,
        city: city.trim() || null,
        occurred_at: new Date(when).toISOString(),
      });
      onOpenChange(false);
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{expense ? "Editar gasto" : "Novo gasto"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="merchant">Estabelecimento / descrição</Label>
            <Input
              id="merchant"
              required
              value={merchant}
              onChange={(e) => setMerchant(e.target.value)}
              placeholder="Ex: Savassi Padaria"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label htmlFor="amount">Valor (R$)</Label>
              <Input
                id="amount"
                required
                inputMode="decimal"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="70,80"
              />
            </div>
            <div className="space-y-2">
              <Label>Categoria</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((c) => (
                    <SelectItem key={c} value={c}>
                      {c}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label htmlFor="when">Data e hora</Label>
              <Input
                id="when"
                type="datetime-local"
                value={when}
                onChange={(e) => setWhen(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="city">Cidade</Label>
              <Input
                id="city"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                placeholder="Opcional"
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="submit" disabled={saving} className="w-full">
              {expense ? "Salvar alterações" : "Adicionar gasto"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
