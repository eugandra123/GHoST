export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      ai_usage: {
        Row: {
          created_at: string
          estimated_cost_usd: number
          id: string
          input_tokens: number
          model: string
          model_family: string
          origin: string
          output_tokens: number
          user_id: string
        }
        Insert: {
          created_at?: string
          estimated_cost_usd: number
          id?: string
          input_tokens: number
          model: string
          model_family: string
          origin: string
          output_tokens: number
          user_id: string
        }
        Update: {
          created_at?: string
          estimated_cost_usd?: number
          id?: string
          input_tokens?: number
          model?: string
          model_family?: string
          origin?: string
          output_tokens?: number
          user_id?: string
        }
        Relationships: []
      }
      assistant_messages: {
        Row: {
          content: string
          created_at: string
          id: string
          role: string
          user_id: string
        }
        Insert: {
          content: string
          created_at?: string
          id?: string
          role: string
          user_id: string
        }
        Update: {
          content?: string
          created_at?: string
          id?: string
          role?: string
          user_id?: string
        }
        Relationships: []
      }
      categories: {
        Row: {
          color: string
          created_at: string
          id: string
          name: string
          user_id: string
        }
        Insert: {
          color?: string
          created_at?: string
          id?: string
          name: string
          user_id: string
        }
        Update: {
          color?: string
          created_at?: string
          id?: string
          name?: string
          user_id?: string
        }
        Relationships: []
      }
      daily_digest_deliveries: {
        Row: {
          digest_date: string
          id: string
          sent_at: string
          user_id: string
        }
        Insert: {
          digest_date: string
          id?: string
          sent_at?: string
          user_id: string
        }
        Update: {
          digest_date?: string
          id?: string
          sent_at?: string
          user_id?: string
        }
        Relationships: []
      }
      expenses: {
        Row: {
          amount: number
          category: string
          city: string | null
          created_at: string
          id: string
          merchant: string
          occurred_at: string
          raw_input: string | null
          source: string
          updated_at: string
          user_id: string
        }
        Insert: {
          amount: number
          category?: string
          city?: string | null
          created_at?: string
          id?: string
          merchant: string
          occurred_at?: string
          raw_input?: string | null
          source?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          amount?: number
          category?: string
          city?: string | null
          created_at?: string
          id?: string
          merchant?: string
          occurred_at?: string
          raw_input?: string | null
          source?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      pending_data_actions: {
        Row: {
          action_type: string
          created_at: string
          expires_at: string
          id: string
          proposed_values: Json
          record_snapshot: Json | null
          target_id: string | null
          target_table: string
          user_id: string
        }
        Insert: {
          action_type: string
          created_at?: string
          expires_at: string
          id?: string
          proposed_values?: Json
          record_snapshot?: Json | null
          target_id?: string | null
          target_table: string
          user_id: string
        }
        Update: {
          action_type?: string
          created_at?: string
          expires_at?: string
          id?: string
          proposed_values?: Json
          record_snapshot?: Json | null
          target_id?: string | null
          target_table?: string
          user_id?: string
        }
        Relationships: []
      }
      pending_expense_actions: {
        Row: {
          action_type: string
          created_at: string
          expense_id: string
          expense_snapshot: Json
          expires_at: string
          id: string
          proposed_changes: Json | null
          user_id: string
        }
        Insert: {
          action_type: string
          created_at?: string
          expense_id: string
          expense_snapshot: Json
          expires_at: string
          id?: string
          proposed_changes?: Json | null
          user_id: string
        }
        Update: {
          action_type?: string
          created_at?: string
          expense_id?: string
          expense_snapshot?: Json
          expires_at?: string
          id?: string
          proposed_changes?: Json | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "pending_expense_actions_expense_id_fkey"
            columns: ["expense_id"]
            isOneToOne: false
            referencedRelation: "expenses"
            referencedColumns: ["id"]
          },
        ]
      }
      pending_reminder_setups: {
        Row: {
          created_at: string
          details: string | null
          ends_at: string
          expires_at: string
          id: string
          starts_at: string
          title: string
          user_id: string
        }
        Insert: {
          created_at?: string
          details?: string | null
          ends_at: string
          expires_at: string
          id?: string
          starts_at: string
          title: string
          user_id: string
        }
        Update: {
          created_at?: string
          details?: string | null
          ends_at?: string
          expires_at?: string
          id?: string
          starts_at?: string
          title?: string
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string
          display_name: string | null
          id: string
          telegram_chat_id: number | null
          telegram_link_code: string | null
          telegram_username: string | null
          whatsapp_phone: string | null
        }
        Insert: {
          created_at?: string
          display_name?: string | null
          id: string
          telegram_chat_id?: number | null
          telegram_link_code?: string | null
          telegram_username?: string | null
          whatsapp_phone?: string | null
        }
        Update: {
          created_at?: string
          display_name?: string | null
          id?: string
          telegram_chat_id?: number | null
          telegram_link_code?: string | null
          telegram_username?: string | null
          whatsapp_phone?: string | null
        }
        Relationships: []
      }
      reminders: {
        Row: {
          aviso_antecedencia_minutos: number
          created_at: string
          details: string | null
          ends_at: string
          id: string
          notification_claimed_at: string | null
          notification_sent_at: string | null
          starts_at: string
          title: string
          updated_at: string
          user_id: string
        }
        Insert: {
          aviso_antecedencia_minutos?: number
          created_at?: string
          details?: string | null
          ends_at: string
          id?: string
          notification_claimed_at?: string | null
          notification_sent_at?: string | null
          starts_at: string
          title: string
          updated_at?: string
          user_id: string
        }
        Update: {
          aviso_antecedencia_minutos?: number
          created_at?: string
          details?: string | null
          ends_at?: string
          id?: string
          notification_claimed_at?: string | null
          notification_sent_at?: string | null
          starts_at?: string
          title?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      scheduled_job_state: {
        Row: {
          consecutive_rate_limits: number
          job_name: string
          last_completed_at: string | null
          last_started_at: string | null
          lease_expires_at: string | null
          paused_reason: string | null
          status: string
          updated_at: string
        }
        Insert: {
          consecutive_rate_limits?: number
          job_name: string
          last_completed_at?: string | null
          last_started_at?: string | null
          lease_expires_at?: string | null
          paused_reason?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          consecutive_rate_limits?: number
          job_name?: string
          last_completed_at?: string | null
          last_started_at?: string | null
          lease_expires_at?: string | null
          paused_reason?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      tasks: {
        Row: {
          created_at: string
          description: string
          id: string
          status: string
          user_id: string
        }
        Insert: {
          created_at?: string
          description: string
          id?: string
          status?: string
          user_id: string
        }
        Update: {
          created_at?: string
          description?: string
          id?: string
          status?: string
          user_id?: string
        }
        Relationships: []
      }
      user_parameters: {
        Row: {
          created_at: string
          id: string
          key: string
          updated_at: string
          user_id: string
          value: string
        }
        Insert: {
          created_at?: string
          id?: string
          key: string
          updated_at?: string
          user_id: string
          value: string
        }
        Update: {
          created_at?: string
          id?: string
          key?: string
          updated_at?: string
          user_id?: string
          value?: string
        }
        Relationships: []
      }
      whatsapp_messages: {
        Row: {
          body: string | null
          channel: string
          created_at: string
          error: string | null
          expense_id: string | null
          external_id: string | null
          id: string
          kind: string
          media_url: string | null
          payload: Json | null
          phone: string | null
          status: string
          user_id: string | null
        }
        Insert: {
          body?: string | null
          channel?: string
          created_at?: string
          error?: string | null
          expense_id?: string | null
          external_id?: string | null
          id?: string
          kind?: string
          media_url?: string | null
          payload?: Json | null
          phone?: string | null
          status?: string
          user_id?: string | null
        }
        Update: {
          body?: string | null
          channel?: string
          created_at?: string
          error?: string | null
          expense_id?: string | null
          external_id?: string | null
          id?: string
          kind?: string
          media_url?: string | null
          payload?: Json | null
          phone?: string | null
          status?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "whatsapp_messages_expense_id_fkey"
            columns: ["expense_id"]
            isOneToOne: false
            referencedRelation: "expenses"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      claim_due_reminder_notifications: {
        Args: { _lease_minutes?: number; _limit?: number }
        Returns: {
          id: string
          starts_at: string
          telegram_chat_id: number
          title: string
        }[]
      }
      claim_scheduled_job: {
        Args: { _job_name: string; _lease_minutes?: number }
        Returns: boolean
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
